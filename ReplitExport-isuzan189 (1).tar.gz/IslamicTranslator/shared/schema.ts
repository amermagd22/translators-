import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Translation history table
export const translations = pgTable("translations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  sourceText: text("source_text").notNull(),
  translatedText: text("translated_text").notNull(),
  sourceLanguage: text("source_language").notNull(),
  targetLanguage: text("target_language").notNull(),
  translationType: text("translation_type").notNull(), // text, voice, image
  createdAt: timestamp("created_at").defaultNow(),
});

// Language table
export const languages = pgTable("languages", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  nativeName: text("native_name").notNull(),
  direction: text("direction").notNull().default("ltr"),
  flagCode: text("flag_code"),
});

// Settings table
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).unique(),
  preferredSourceLanguage: text("preferred_source_language").notNull().default("ar"),
  preferredTargetLanguage: text("preferred_target_language").notNull().default("en"),
  voiceSpeed: integer("voice_speed").notNull().default(1),
  voiceGender: text("voice_gender").notNull().default("FEMALE"),
  theme: text("theme").notNull().default("light"),
  filterLevel: text("filter_level").notNull().default("moderate"),
});

// Prohibited words for content filtering
export const prohibitedWords = pgTable("prohibited_words", {
  id: serial("id").primaryKey(),
  word: text("word").notNull().unique(),
  language: text("language").notNull(),
  category: text("category").notNull(),
  replacement: text("replacement"),
});

// System stats
export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  date: timestamp("date").defaultNow(),
  textTranslations: integer("text_translations").notNull().default(0),
  voiceTranslations: integer("voice_translations").notNull().default(0),
  imageTranslations: integer("image_translations").notNull().default(0),
  totalCharacters: integer("total_characters").notNull().default(0),
  languageStats: jsonb("language_stats").notNull().default({}),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

export const insertTranslationSchema = createInsertSchema(translations).pick({
  userId: true,
  sourceText: true,
  translatedText: true,
  sourceLanguage: true,
  targetLanguage: true,
  translationType: true,
});

export const insertLanguageSchema = createInsertSchema(languages).pick({
  code: true,
  name: true,
  nativeName: true,
  direction: true,
  flagCode: true,
});

export const insertSettingsSchema = createInsertSchema(settings).pick({
  userId: true,
  preferredSourceLanguage: true,
  preferredTargetLanguage: true,
  voiceSpeed: true,
  voiceGender: true,
  theme: true,
  filterLevel: true,
});

export const insertProhibitedWordSchema = createInsertSchema(prohibitedWords).pick({
  word: true,
  language: true,
  category: true,
  replacement: true,
});

export const insertStatsSchema = createInsertSchema(stats).pick({
  textTranslations: true,
  voiceTranslations: true,
  imageTranslations: true,
  totalCharacters: true,
  languageStats: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Translation = typeof translations.$inferSelect;
export type InsertTranslation = z.infer<typeof insertTranslationSchema>;

export type Language = typeof languages.$inferSelect;
export type InsertLanguage = z.infer<typeof insertLanguageSchema>;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

export type ProhibitedWord = typeof prohibitedWords.$inferSelect;
export type InsertProhibitedWord = z.infer<typeof insertProhibitedWordSchema>;

export type Stat = typeof stats.$inferSelect;
export type InsertStat = z.infer<typeof insertStatsSchema>;

// Validation schemas for API requests
export const translationRequestSchema = z.object({
  sourceText: z.string().min(1).max(5000),
  sourceLanguage: z.string().min(2).max(10),
  targetLanguage: z.string().min(2).max(10),
});

export const speechToTextRequestSchema = z.object({
  audioData: z.string(),
  sourceLanguage: z.string().min(2).max(10),
});

export const textToSpeechRequestSchema = z.object({
  text: z.string().min(1).max(5000),
  language: z.string().min(2).max(10),
  voiceGender: z.enum(["MALE", "FEMALE"]).optional(),
  voiceSpeed: z.number().min(0.25).max(4).optional(),
});

export const imageToTextRequestSchema = z.object({
  imageData: z.string(),
  sourceLanguage: z.string().min(2).max(10),
  targetLanguage: z.string().min(2).max(10),
});

// Learning content schemas
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  bookId: text("book_id").notNull(), // Reference to the book
  title: text("title").notNull(),
  content: text("content").notNull(),
  audioUrl: text("audio_url"),
  duration: integer("duration"), // in seconds
  orderIndex: integer("order_index").notNull(), // Position in the book
  objectives: text("objectives").array(), // Learning objectives
  keywords: text("keywords").array(), // Important concepts
  createdAt: timestamp("created_at").defaultNow()
});

export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").references(() => lessons.id),
  bookId: text("book_id"), // Direct reference to book is optional
  title: text("title").notNull(),
  description: text("description"),
  difficulty: text("difficulty"), // easy, medium, hard
  timeLimit: integer("time_limit"), // in minutes
  passingScore: integer("passing_score"), // percentage
  createdAt: timestamp("created_at").defaultNow()
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  quizId: integer("quiz_id").references(() => quizzes.id),
  lessonId: integer("lesson_id").references(() => lessons.id),
  questionType: text("question_type").notNull(), // multiple-choice, true-false, fill-blank, short-answer
  questionText: text("question_text").notNull(),
  options: text("options").array(), // For multiple choice
  correctAnswers: text("correct_answers").array(), // Allows multiple correct answers
  explanation: text("explanation"), // Explanation of the answer
  points: integer("points").default(1),
  orderIndex: integer("order_index"), // Position in the quiz
  createdAt: timestamp("created_at").defaultNow()
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  bookId: text("book_id"),
  lessonId: integer("lesson_id").references(() => lessons.id),
  quizId: integer("quiz_id").references(() => quizzes.id),
  completed: boolean("completed").default(false),
  score: integer("score"), // For quizzes
  timeSpent: integer("time_spent"), // in seconds
  lastAccessedAt: timestamp("last_accessed_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  answers: text("answers").array(), // User's answers
  createdAt: timestamp("created_at").defaultNow()
});

export const insertLessonSchema = createInsertSchema(lessons).pick({
  bookId: true,
  title: true,
  content: true,
  audioUrl: true,
  duration: true,
  orderIndex: true,
  objectives: true,
  keywords: true
});

export const insertQuizSchema = createInsertSchema(quizzes).pick({
  lessonId: true,
  bookId: true,
  title: true,
  description: true,
  difficulty: true,
  timeLimit: true,
  passingScore: true
});

export const insertQuestionSchema = createInsertSchema(questions).pick({
  quizId: true,
  lessonId: true,
  questionType: true,
  questionText: true,
  options: true,
  correctAnswers: true,
  explanation: true,
  points: true,
  orderIndex: true
});

export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  bookId: true,
  lessonId: true,
  quizId: true,
  completed: true,
  score: true,
  timeSpent: true,
  lastAccessedAt: true,
  completedAt: true,
  answers: true
});

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

// Educational content generation request schemas
export const generateQuizRequestSchema = z.object({
  bookId: z.string(),
  lessonId: z.number().optional(),
  contentText: z.string().optional(), // If providing custom content
  difficulty: z.enum(['easy', 'medium', 'hard']).optional().default('medium'),
  questionTypes: z.array(
    z.enum(['multiple-choice', 'true-false', 'fill-blank', 'short-answer'])
  ).optional().default(['multiple-choice', 'true-false']),
  numberOfQuestions: z.number().optional().default(5)
});

export const generateLessonAudioRequestSchema = z.object({
  lessonId: z.number(),
  voiceType: z.enum(['male', 'female']).optional().default('male'),
  speed: z.number().optional().default(1.0), // 0.8 to 1.5
  includeExplanations: z.boolean().optional().default(true)
});

// Educational media (presentations and videos)
export const educationalMedia = pgTable("educational_media", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").references(() => lessons.id),
  mediaType: text("media_type").notNull(), // presentation, video
  title: text("title").notNull(),
  description: text("description"),
  contentUrl: text("content_url").notNull(), // URL to the media content
  thumbnailUrl: text("thumbnail_url"), // For previews
  duration: integer("duration"), // For videos (seconds)
  slideCount: integer("slide_count"), // For presentations
  orderIndex: integer("order_index").notNull().default(0), // Position in the lesson
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id), // Admin or content creator
});

export const insertEducationalMediaSchema = createInsertSchema(educationalMedia).pick({
  lessonId: true,
  mediaType: true,
  title: true,
  description: true,
  contentUrl: true,
  thumbnailUrl: true,
  duration: true,
  slideCount: true,
  orderIndex: true,
  createdBy: true
});

export type EducationalMedia = typeof educationalMedia.$inferSelect;
export type InsertEducationalMedia = z.infer<typeof insertEducationalMediaSchema>;

// Schema for generating presentation/video content
export const generatePresentationRequestSchema = z.object({
  lessonId: z.number(),
  title: z.string().optional(),
  contentText: z.string().optional(), // If providing custom content
  slideCount: z.number().optional().default(10),
  includeImages: z.boolean().optional().default(true),
  style: z.enum(['academic', 'modern', 'minimal']).optional().default('academic'),
  language: z.string().min(2).max(10).optional().default('ar')
});

export const generateVideoRequestSchema = z.object({
  lessonId: z.number(),
  title: z.string().optional(),
  contentText: z.string().optional(), // If providing custom content
  duration: z.number().optional().default(300), // Default 5 minutes
  style: z.enum(['lecture', 'animation', 'screencast']).optional().default('lecture'),
  language: z.string().min(2).max(10).optional().default('ar')
});
