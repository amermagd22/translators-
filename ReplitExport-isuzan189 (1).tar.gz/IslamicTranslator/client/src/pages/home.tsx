import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { LanguageSelector } from "@/components/language-selector";
import { TranslationInput } from "@/components/translation-input";
import { TranslationOutput } from "@/components/translation-output";
import { FeatureCards } from "@/components/feature-cards";
import { RecentTranslations } from "@/components/recent-translations";
import { IslamicQuestion } from "@/components/islamic-question";
import { useTranslation as useTranslationHook } from "@/hooks/use-translation";
import { fetchLanguages } from "@/lib/translation";

export default function Home() {
  const { t, i18n } = useTranslation();
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState("ar");
  const [targetLanguage, setTargetLanguage] = useState("en");

  // Get languages from API
  const { data: languages } = useQuery({
    queryKey: ["/api/languages"],
    staleTime: Infinity,
  });

  // Translation hook
  const { 
    translateText, 
    isTranslating,
    imageToText
  } = useTranslationHook({
    onSuccess: (data) => {
      if ('translatedText' in data) {
        setTranslatedText(data.translatedText);
      }
    }
  });

  // Set default languages based on user's i18n language
  useEffect(() => {
    if (languages && languages.length > 0) {
      const currentLang = i18n.language;
      
      // If the current language is supported, set it as source
      if (languages.some(lang => lang.code === currentLang)) {
        setSourceLanguage(currentLang);
        
        // Set target language - if source is Arabic, target is English, otherwise Arabic
        setTargetLanguage(currentLang === "ar" ? "en" : "ar");
      }
    }
  }, [languages, i18n.language]);

  // Handle language swap
  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };

  // Handle translate
  const handleTranslate = async () => {
    if (!sourceText.trim()) return;
    
    const response = await translateText(sourceText, sourceLanguage, targetLanguage);
    if (response) {
      setTranslatedText(response.translatedText);
    }
  };

  // Handle text from speech recognition
  const handleMicrophoneCapture = (text: string) => {
    setSourceText(text);
    handleTranslate();
  };

  // Handle image capture and OCR
  const handleCameraCapture = async (imageData: string) => {
    const response = await imageToText(imageData, sourceLanguage, targetLanguage);
    if (response) {
      setSourceText(response.extractedText);
      setTranslatedText(response.translatedText);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        {/* Language Selection */}
        <LanguageSelector
          sourceLanguage={sourceLanguage}
          targetLanguage={targetLanguage}
          onSourceLanguageChange={setSourceLanguage}
          onTargetLanguageChange={setTargetLanguage}
          onSwapLanguages={handleSwapLanguages}
        />

        {/* Translation Area */}
        <div className="translation-container space-y-6">
          {/* Source Text Input */}
          <TranslationInput
            value={sourceText}
            onChange={setSourceText}
            onClear={() => setSourceText("")}
            onTranslate={handleTranslate}
            sourceLanguage={sourceLanguage}
            isTranslating={isTranslating}
            onMicrophoneCapture={handleMicrophoneCapture}
            onCameraCapture={handleCameraCapture}
          />
          
          {/* Translation Output */}
          <TranslationOutput
            translatedText={translatedText}
            targetLanguage={targetLanguage}
            isTranslating={isTranslating}
          />
        </div>

        {/* Islamic Question Component */}
        <IslamicQuestion language={sourceLanguage} />
        
        {/* Feature Cards */}
        <FeatureCards />
        
        {/* Recent Translations */}
        <RecentTranslations />
      </div>
    </Layout>
  );
}
