import { useState, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { UploadDialog, type UploadDetails } from '@/components/upload-dialog';
import { UploadDialogBookImport } from '@/components/upload-dialog-book-import';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import {
  Book,
  BookOpen,
  Camera,
  Download,
  FileText,
  Play,
  Pause,
  RotateCcw,
  Search as SearchIcon,
  SkipBack,
  SkipForward,
  Text,
  Upload,
  Video,
  Volume2,
  VolumeX
} from 'lucide-react';

// Languages available in the system
const languages = [
  { id: 'ar', name: 'العربية', nativeName: 'العربية' },
  { id: 'en', name: 'الإنجليزية', nativeName: 'English' },
  { id: 'fr', name: 'الفرنسية', nativeName: 'Français' },
  { id: 'es', name: 'الإسبانية', nativeName: 'Español' },
  { id: 'de', name: 'الألمانية', nativeName: 'Deutsch' },
  { id: 'id', name: 'الإندونيسية', nativeName: 'Bahasa Indonesia' },
  { id: 'ml', name: 'الملايو', nativeName: 'Bahasa Melayu' },
  { id: 'tr', name: 'التركية', nativeName: 'Türkçe' },
  { id: 'ur', name: 'الأردية', nativeName: 'اردو' },
  { id: 'fa', name: 'الفارسية', nativeName: 'فارسی' },
  { id: 'hi', name: 'الهندية', nativeName: 'हिन्दी' },
  { id: 'bn', name: 'البنغالية', nativeName: 'বাংলা' },
];

// Book categories
const bookCategories = [
  { id: 'quran', name: 'القرآن وعلومه' },
  { id: 'hadith', name: 'الحديث وعلومه' },
  { id: 'fiqh', name: 'الفقه الإسلامي' },
  { id: 'aqeedah', name: 'العقيدة الإسلامية' },
  { id: 'seerah', name: 'السيرة النبوية' },
  { id: 'history', name: 'التاريخ الإسلامي' },
  { id: 'education', name: 'التربية الإسلامية' },
  { id: 'science', name: 'الإعجاز العلمي' },
  { id: 'dawah', name: 'الدعوة الإسلامية' },
  { id: 'spirituality', name: 'التزكية والروحانيات' },
  { id: 'contemporary', name: 'قضايا معاصرة' },
  { id: 'other', name: 'أخرى' },
];

// Helper function to format time in MM:SS
const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

// Main component
const IslamicLibraryPage = () => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  // States for tab management and filtering
  const [activeTab, setActiveTab] = useState<string>('books');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  // States for upload dialog
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState<boolean>(false);
  const [currentFile, setCurrentFile] = useState<File | null>(null);
  const [currentFileType, setCurrentFileType] = useState<string>('');
  const [isMultipleFiles, setIsMultipleFiles] = useState<boolean>(false);
  
  // States for camera interaction
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
  const [cameraMode, setCameraMode] = useState<'search' | 'ocr'>('search');
  const [isImageSearchOpen, setIsImageSearchOpen] = useState<boolean>(false);
  
  // States for book reader
  const [isBookReaderOpen, setIsBookReaderOpen] = useState<boolean>(false);
  const [selectedBook, setSelectedBook] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(80);
  const [progress, setProgress] = useState<number>(0);
  
  // States for video player
  const [isVideoPlayerOpen, setIsVideoPlayerOpen] = useState<boolean>(false);
  const [selectedVideo, setSelectedVideo] = useState<any>(null);
  const [selectedTranslation, setSelectedTranslation] = useState<string>('');
  
  // Mock data for books and videos
  const [books, setBooks] = useState<any[]>([
    {
      id: '1',
      title: 'تفسير القرآن الكريم',
      author: 'ابن كثير',
      language: 'ar',
      category: 'quran',
      coverImage: 'https://via.placeholder.com/200x300?text=تفسير+ابن+كثير',
      description: 'تفسير القرآن العظيم، المعروف باسم تفسير ابن كثير، هو تفسير للقرآن الكريم كتبه الإمام إسماعيل بن عمر بن كثير القرشي الدمشقي، المعروف باسم ابن كثير.',
      pages: 1500,
      audioAvailable: true,
      pdfUrl: '#',
      audioUrl: '#'
    },
    {
      id: '2',
      title: 'صحيح البخاري',
      author: 'محمد بن إسماعيل البخاري',
      language: 'ar',
      category: 'hadith',
      coverImage: 'https://via.placeholder.com/200x300?text=صحيح+البخاري',
      description: 'صحيح البخاري هو أحد أهم كتب الحديث النبوي عند المسلمين. جمعه الإمام محمد بن إسماعيل البخاري واحتوى على أحاديث النبي محمد التي اعتبرها البخاري صحيحة.',
      pages: 1200,
      audioAvailable: true,
      pdfUrl: '#',
      audioUrl: '#'
    },
    {
      id: '3',
      title: 'The Sealed Nectar',
      author: 'Safiur-Rahman Al-Mubarakpuri',
      language: 'en',
      category: 'seerah',
      coverImage: 'https://via.placeholder.com/200x300?text=The+Sealed+Nectar',
      description: 'The Sealed Nectar is a biography of the Islamic prophet Muhammad by Safiur Rahman Mubarakpuri. The book was awarded first prize at the first Islamic Conference on Seerah in 1976 in Pakistan.',
      pages: 480,
      audioAvailable: false,
      pdfUrl: '#'
    },
    {
      id: '4',
      title: 'فقه السنة',
      author: 'سيد سابق',
      language: 'ar',
      category: 'fiqh',
      coverImage: 'https://via.placeholder.com/200x300?text=فقه+السنة',
      description: 'كتاب فقه السنة للشيخ سيد سابق هو من الكتب التي لاقت رواجاً بين طلبة العلم، وقد جمع فيه الأحكام الفقهية المختلفة معتمداً على القرآن والسنة.',
      pages: 800,
      audioAvailable: false,
      pdfUrl: '#'
    },
    {
      id: '5',
      title: 'Don\'t Be Sad',
      author: 'Aid al-Qarni',
      language: 'en',
      category: 'spirituality',
      coverImage: 'https://via.placeholder.com/200x300?text=Don\'t+Be+Sad',
      description: 'Don\'t Be Sad is a book written by Aaidh ibn Abdullah al-Qarni. It deals with ways to prevent sadness and depression through Islamic teachings and wisdom.',
      pages: 320,
      audioAvailable: true,
      pdfUrl: '#',
      audioUrl: '#'
    },
    {
      id: '6',
      title: 'العقيدة الواسطية',
      author: 'ابن تيمية',
      language: 'ar',
      category: 'aqeedah',
      coverImage: 'https://via.placeholder.com/200x300?text=العقيدة+الواسطية',
      description: 'العقيدة الواسطية هي رسالة صغيرة في العقيدة الإسلامية ألفها شيخ الإسلام ابن تيمية. تحتوي على عقيدة أهل السنة والجماعة.',
      pages: 150,
      audioAvailable: false,
      pdfUrl: '#'
    }
  ]);
  
  const [videos, setVideos] = useState<any[]>([
    {
      id: '1',
      title: 'مقدمة في علوم القرآن',
      originalLanguage: 'ar',
      translations: [
        { language: 'en', status: 'completed', audioUrl: '#', subtitlesUrl: '#' },
        { language: 'fr', status: 'completed', audioUrl: '#', subtitlesUrl: '#' },
        { language: 'id', status: 'in_progress' }
      ],
      thumbnailUrl: 'https://via.placeholder.com/640x360?text=مقدمة+في+علوم+القرآن',
      duration: 1800, // 30 mins
      uploadDate: '2023-09-15',
      videoUrl: '#'
    },
    {
      id: '2',
      title: 'Scientific Miracles in Islam',
      originalLanguage: 'en',
      translations: [
        { language: 'ar', status: 'completed', audioUrl: '#', subtitlesUrl: '#' },
        { language: 'ur', status: 'completed', audioUrl: '#', subtitlesUrl: '#' },
        { language: 'fr', status: 'in_progress' },
        { language: 'tr', status: 'failed' }
      ],
      thumbnailUrl: 'https://via.placeholder.com/640x360?text=Scientific+Miracles',
      duration: 2400, // 40 mins
      uploadDate: '2023-10-20',
      videoUrl: '#'
    },
    {
      id: '3',
      title: 'كيف تقرأ القرآن بالتجويد',
      originalLanguage: 'ar',
      translations: [
        { language: 'en', status: 'completed', audioUrl: '#', subtitlesUrl: '#' },
        { language: 'id', status: 'completed', audioUrl: '#', subtitlesUrl: '#' },
        { language: 'bn', status: 'in_progress' }
      ],
      thumbnailUrl: 'https://via.placeholder.com/640x360?text=تعلم+التجويد',
      duration: 3600, // 60 mins
      uploadDate: '2023-11-05',
      videoUrl: '#'
    }
  ]);
  
  // Filtered books and videos based on search and filters
  const filteredBooks = books.filter((book) => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          book.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesLanguage = selectedLanguage === 'all' || book.language === selectedLanguage;
    const matchesCategory = selectedCategory === 'all' || book.category === selectedCategory;
    
    return matchesSearch && matchesLanguage && matchesCategory;
  });
  
  const filteredVideos = videos.filter((video) => {
    const matchesSearch = video.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLanguage = selectedLanguage === 'all' || 
                           video.originalLanguage === selectedLanguage || 
                           video.translations.some((t: any) => t.language === selectedLanguage);
    
    return matchesSearch && matchesLanguage;
  });
  
  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Functions for book/video interactions
  const openBookReader = (book: any) => {
    setSelectedBook(book);
    setCurrentPage(1);
    setIsBookReaderOpen(true);
  };
  
  const openVideoPlayer = (video: any) => {
    setSelectedVideo(video);
    setSelectedTranslation(video.translations[0]?.language || '');
    setIsVideoPlayerOpen(true);
  };
  
  // Audio controls for book reader
  const playAudio = () => {
    if (audioRef.current) {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };
  
  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };
  
  const handleVolumeChange = (values: number[]) => {
    const newVolume = values[0];
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume / 100;
    }
  };
  
  // File upload handling
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCurrentFile(e.target.files[0]);
      setCurrentFileType(e.target.files[0].type);
      setIsMultipleFiles(e.target.files.length > 1);
      setIsUploadDialogOpen(true);
    }
  };
  
  const handleUploadSubmit = async (details: UploadDetails) => {
    // This would normally connect to the API to upload the file
    toast({
      title: "تم الرفع بنجاح",
      description: `تم رفع ${details.title} بنجاح`,
    });
    
    setIsUploadDialogOpen(false);
    
    // Add dummy data to the local state
    if (activeTab === 'books') {
      const newBook = {
        id: `new-${Date.now()}`,
        title: details.title,
        author: details.author || 'غير معروف',
        language: details.language || 'ar',
        category: details.category || 'other',
        coverImage: 'https://via.placeholder.com/200x300?text=كتاب+جديد',
        description: details.description || 'لا يوجد وصف',
        pages: details.pages || 100,
        audioAvailable: false,
        pdfUrl: '#'
      };
      setBooks([...books, newBook]);
    } else {
      const newVideo = {
        id: `new-${Date.now()}`,
        title: details.title,
        originalLanguage: details.language || 'ar',
        translations: [],
        thumbnailUrl: 'https://via.placeholder.com/640x360?text=فيديو+جديد',
        duration: 600, // 10 mins
        uploadDate: new Date().toISOString().split('T')[0],
        videoUrl: '#'
      };
      setVideos([...videos, newVideo]);
    }
  };
  
  // Camera handling
  const openCamera = (mode: 'search' | 'ocr') => {
    setCameraMode(mode);
    setIsCameraOpen(true);
  };
  
  const fetchBooks = () => {
    // This would normally connect to the API to fetch books
    toast({
      title: "تم تحديث الكتب",
      description: "تم تحديث قائمة الكتب بنجاح",
    });
  };
  
  return (
    <div className="container mx-auto py-8 rtl">
      <h1 className="text-3xl font-bold mb-6 text-center">المكتبة الإسلامية الشاملة</h1>
      
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-grow">
          <Input
            placeholder="ابحث عن كتاب أو فيديو..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
        </div>
        
        <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="اللغة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع اللغات</SelectItem>
            {languages.map((lang) => (
              <SelectItem key={lang.id} value={lang.id}>
                {lang.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {activeTab === 'books' && (
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="التصنيف" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع التصنيفات</SelectItem>
              {bookCategories.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          multiple
          onChange={handleFileUpload}
          accept={activeTab === 'books' ? ".pdf,.epub,.zip,.rar,.tar,.png,.jpg,.jpeg" : "video/*"}
        />
        
        <div className="flex items-center gap-2">
          {activeTab === 'books' && <UploadDialogBookImport onComplete={fetchBooks} />}
          
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload size={18} />
            <span>رفع {activeTab === 'books' ? 'كتاب' : 'فيديو'}</span>
          </Button>
        
        {activeTab === 'books' && (
          <>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => openCamera('search')}
            >
              <Camera size={18} />
              <span>البحث بالصورة</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => openCamera('ocr')}
            >
              <Text size={18} />
              <span>استخراج النص من الصورة</span>
            </Button>
          </>
        )}
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 mb-8">
          <TabsTrigger value="books" className="flex items-center gap-2">
            <Book size={18} />
            <span>الكتب</span>
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex items-center gap-2">
            <Video size={18} />
            <span>الفيديوهات</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="books">
          {isLoading && filteredBooks.length === 0 ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4">جاري تحميل الكتب...</p>
            </div>
          ) : filteredBooks.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="mx-auto h-16 w-16 text-gray-300" />
              <h3 className="mt-4 text-xl font-semibold">لا توجد كتب</h3>
              <p className="mt-2 text-gray-500">
                لم يتم العثور على كتب تطابق معايير البحث الخاصة بك
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBooks.map((book) => (
                <Card key={book.id} className="overflow-hidden">
                  <div className="aspect-[2/3] relative bg-gray-100">
                    <img 
                      src={book.coverImage} 
                      alt={book.title}
                      className="object-cover w-full h-full"
                      onError={(e) => {
                        // Fallback for failed images
                        const target = e.target as HTMLImageElement;
                        target.src = 'https://via.placeholder.com/200x300?text=No+Image';
                      }}
                    />
                  </div>
                  <CardHeader>
                    <div className="flex justify-between">
                      <CardTitle className="text-lg">{book.title}</CardTitle>
                      <Badge>
                        {languages.find(l => l.id === book.language)?.name || book.language}
                      </Badge>
                    </div>
                    <CardDescription>{book.author}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm line-clamp-3">{book.description}</p>
                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <FileText size={16} className="ml-1" />
                      <span>{book.pages} صفحة</span>
                      {book.audioAvailable && (
                        <Badge variant="outline" className="ml-2">
                          <Volume2 size={14} className="ml-1" /> صوتي
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                      onClick={() => openBookReader(book)}
                    >
                      <BookOpen size={16} />
                      <span>قراءة</span>
                    </Button>
                    <Button
                      variant="outline" 
                      size="sm"
                      className="flex items-center gap-1"
                      disabled={!book.audioAvailable}
                      onClick={() => {
                        if (book.audioAvailable) {
                          openBookReader(book);
                          setTimeout(() => playAudio(), 500);
                        }
                      }}
                    >
                      <Volume2 size={16} />
                      <span>استماع</span>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="videos">
          {isLoading && filteredVideos.length === 0 ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4">جاري تحميل الفيديوهات...</p>
            </div>
          ) : filteredVideos.length === 0 ? (
            <div className="text-center py-8">
              <Video className="mx-auto h-16 w-16 text-gray-300" />
              <h3 className="mt-4 text-xl font-semibold">لا توجد فيديوهات</h3>
              <p className="mt-2 text-gray-500">
                لم يتم العثور على فيديوهات تطابق معايير البحث الخاصة بك
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredVideos.map((video) => (
                <Card key={video.id} className="overflow-hidden">
                  <div className="aspect-video relative bg-gray-100">
                    <img 
                      src={video.thumbnailUrl} 
                      alt={video.title}
                      className="object-cover w-full h-full"
                      onError={(e) => {
                        // Fallback for failed images
                        const target = e.target as HTMLImageElement;
                        target.src = 'https://via.placeholder.com/640x360?text=No+Preview';
                      }}
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button
                        variant="default"
                        size="icon"
                        className="rounded-full w-12 h-12"
                        onClick={() => openVideoPlayer(video)}
                      >
                        <Play size={24} />
                      </Button>
                    </div>
                  </div>
                  <CardHeader>
                    <div className="flex justify-between">
                      <CardTitle className="text-lg">{video.title}</CardTitle>
                      <Badge>
                        {languages.find(l => l.id === video.originalLanguage)?.name || video.originalLanguage}
                      </Badge>
                    </div>
                    <CardDescription>
                      {formatTime(video.duration)} • {new Date(video.uploadDate).toLocaleDateString('ar-EG')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm font-medium mb-2">الترجمات المتوفرة:</p>
                    <div className="flex flex-wrap gap-2">
                      {video.translations.map((translation, index) => (
                        <Badge 
                          key={index} 
                          variant={translation.status === 'completed' ? 'default' : 
                                  translation.status === 'in_progress' ? 'outline' : 'destructive'}
                          className="flex items-center gap-1"
                        >
                          {languages.find(l => l.id === translation.language)?.name || translation.language}
                          {translation.status === 'in_progress' && 
                            <span className="ml-1 animate-pulse">•</span>
                          }
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="w-full flex items-center gap-2"
                      onClick={() => openVideoPlayer(video)}
                    >
                      <Play size={16} />
                      <span>مشاهدة وترجمة</span>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Book reader modal */}
      <Dialog open={isBookReaderOpen} onOpenChange={setIsBookReaderOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{selectedBook?.title}</DialogTitle>
            <DialogDescription>
              {selectedBook?.author} • {languages.find(l => l.id === selectedBook?.language)?.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 overflow-hidden">
            <div className="bg-gray-50 rounded-lg overflow-hidden flex flex-col">
              <div className="flex justify-between items-center p-2 bg-gray-100">
                <div className="flex items-center">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setCurrentPage(currentPage > 1 ? currentPage - 1 : 1)}
                    disabled={currentPage <= 1}
                  >
                    <SkipBack size={18} />
                  </Button>
                  <span className="mx-2">
                    صفحة {currentPage} من {selectedBook?.pages}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setCurrentPage(currentPage < (selectedBook?.pages || 1) ? currentPage + 1 : selectedBook?.pages || currentPage)}
                    disabled={currentPage >= (selectedBook?.pages || 1)}
                  >
                    <SkipForward size={18} />
                  </Button>
                </div>
                <div>
                  <Button 
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(selectedBook?.pdfUrl, '_blank')}
                  >
                    <Download size={16} className="ml-1" />
                    <span>تحميل</span>
                  </Button>
                </div>
              </div>
              
              <ScrollArea className="flex-1 p-4">
                <div className="min-h-[500px] bg-white p-6 shadow-sm rounded">
                  {/* Book content would be displayed here */}
                  <p className="mb-4">
                    محتوى الكتاب سيظهر هنا في التطبيق النهائي. هذا مجرد نموذج توضيحي للواجهة.
                  </p>
                  <p className="mb-4">
                    يتيح نظام عرض الكتب إمكانية عرض محتوى الكتاب مع تقليب الصفحات والاستماع للنسخة الصوتية.
                  </p>
                  <p className="mb-4">
                    يمكن أيضًا البحث داخل محتوى الكتاب وإضافة إشارات مرجعية واقتباسات.
                  </p>
                  <p>
                    في النسخة النهائية، سيتم عرض محتوى الكتب من ملفات PDF مع إمكانية التحكم في حجم الخط والألوان وغيرها من خيارات العرض.
                  </p>
                </div>
              </ScrollArea>
            </div>
            
            <div className="flex flex-col">
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h3 className="font-medium mb-2">حول الكتاب</h3>
                <p className="text-sm mb-3">{selectedBook?.description}</p>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-500">المؤلف:</span> {selectedBook?.author}
                  </div>
                  <div>
                    <span className="text-gray-500">اللغة:</span> {languages.find(l => l.id === selectedBook?.language)?.name}
                  </div>
                  <div>
                    <span className="text-gray-500">الصفحات:</span> {selectedBook?.pages}
                  </div>
                  <div>
                    <span className="text-gray-500">التصنيف:</span> {bookCategories.find(c => c.id === selectedBook?.category)?.name}
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 flex-1">
                {selectedBook?.audioAvailable ? (
                  <div className="flex flex-col h-full">
                    <h3 className="font-medium mb-4">الاستماع للكتاب</h3>
                    
                    <div className="flex-1 flex items-center justify-center">
                      <div className="w-32 h-32 rounded-full bg-primary flex items-center justify-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="rounded-full w-16 h-16 text-white"
                          onClick={isPlaying ? pauseAudio : playAudio}
                        >
                          {isPlaying ? <Pause size={32} /> : <Play size={32} />}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex justify-between text-sm text-gray-500 mb-1">
                        <span>0:00</span>
                        <span>30:00</span>
                      </div>
                      <Progress value={progress} />
                    </div>
                    
                    <div className="flex items-center mt-4 gap-2">
                      <Button variant="ghost" size="icon">
                        <RotateCcw size={18} />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <SkipBack size={18} />
                      </Button>
                      <div className="flex-1">
                        <Slider 
                          value={[volume]} 
                          min={0} 
                          max={100} 
                          step={1}
                          onValueChange={handleVolumeChange}
                        />
                      </div>
                      <Button variant="ghost" size="icon">
                        {volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}
                      </Button>
                    </div>
                    
                    {/* Hidden audio element */}
                    <audio
                      ref={audioRef}
                      src={selectedBook?.audioUrl}
                      onTimeUpdate={() => {
                        if (audioRef.current) {
                          const duration = audioRef.current.duration || 1800;
                          const currentTime = audioRef.current.currentTime;
                          setProgress((currentTime / duration) * 100);
                        }
                      }}
                      onEnded={() => setIsPlaying(false)}
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full">
                    <VolumeX size={48} className="text-gray-300 mb-4" />
                    <p className="text-gray-500 text-center">
                      النسخة الصوتية غير متوفرة لهذا الكتاب
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Video player modal */}
      <Dialog open={isVideoPlayerOpen} onOpenChange={setIsVideoPlayerOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{selectedVideo?.title}</DialogTitle>
            <DialogDescription>
              {languages.find(l => l.id === selectedVideo?.originalLanguage)?.name} • {formatTime(selectedVideo?.duration)}
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col gap-4 flex-1 overflow-hidden">
            <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
              {/* Video would be embedded here */}
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  variant="default"
                  size="icon"
                  className="rounded-full w-16 h-16"
                >
                  <Play size={32} />
                </Button>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium mb-2">ترجمة الفيديو</h3>
              
              <div className="flex flex-wrap gap-2 mb-4">
                <Button 
                  variant={selectedTranslation === selectedVideo?.originalLanguage ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedTranslation(selectedVideo?.originalLanguage)}
                >
                  النسخة الأصلية - {languages.find(l => l.id === selectedVideo?.originalLanguage)?.name}
                </Button>
                
                {selectedVideo?.translations.map((translation, index) => (
                  <Button 
                    key={index}
                    variant={selectedTranslation === translation.language ? "default" : "outline"}
                    size="sm"
                    disabled={translation.status !== 'completed'}
                    onClick={() => setSelectedTranslation(translation.language)}
                  >
                    {languages.find(l => l.id === translation.language)?.name}
                    {translation.status === 'in_progress' && <span className="ml-1 animate-pulse">•</span>}
                  </Button>
                ))}
              </div>
              
              <div className="bg-white p-4 rounded border">
                <p className="text-gray-500 mb-2 text-sm">النص المترجم:</p>
                <p>
                  هنا سيظهر النص المترجم للفيديو في اللغة المختارة. يمكن للمستخدمين تحميل الترجمة كملف نصي أو الاستماع للترجمة الصوتية.
                </p>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline">
              <Download size={16} className="ml-1" />
              <span>تحميل الترجمة</span>
            </Button>
            <Button>
              <Volume2 size={16} className="ml-1" />
              <span>الاستماع للترجمة</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    
      {/* Upload dialog for books/videos */}
      <UploadDialog
        isOpen={isUploadDialogOpen}
        onClose={() => setIsUploadDialogOpen(false)}
        onUpload={handleUploadSubmit}
        file={currentFile}
        fileType={currentFileType}
        isMultipleFiles={isMultipleFiles}
        contentType={activeTab === 'books' ? 'books' : 'videos'}
      />
    </div>
  );
};

export default IslamicLibraryPage;