import { useState, useEffect, useContext } from "react";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Layout } from "@/components/layout";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { AuthContext } from "@/App";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { fetchLanguages } from "@/lib/translation";
import { Link } from "wouter";
import { Settings as SettingsIcon, User } from "lucide-react";

// Settings form schema
const settingsSchema = z.object({
  preferredSourceLanguage: z.string(),
  preferredTargetLanguage: z.string(),
  voiceSpeed: z.number().min(0.25).max(2),
  voiceGender: z.enum(["FEMALE", "MALE"]),
  theme: z.enum(["light", "dark", "system"]),
  filterLevel: z.enum(["mild", "moderate", "strict"])
});

type SettingsFormValues = z.infer<typeof settingsSchema>;

export default function Settings() {
  const { t, i18n } = useTranslation();
  const { user } = useContext(AuthContext);
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Query to get user settings
  const { data: settings, isLoading: isLoadingSettings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      if (!user) return null;
      const res = await fetch("/api/settings", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to load settings");
      return res.json();
    },
    enabled: !!user,
    refetchOnWindowFocus: false
  });
  
  // Query to get available languages
  const { data: languages, isLoading: isLoadingLanguages } = useQuery({
    queryKey: ["/api/languages"],
    queryFn: fetchLanguages,
    staleTime: Infinity
  });
  
  // Settings form
  const form = useForm<SettingsFormValues>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      preferredSourceLanguage: "ar",
      preferredTargetLanguage: "en",
      voiceSpeed: 1,
      voiceGender: "FEMALE",
      theme: "light",
      filterLevel: "moderate"
    }
  });
  
  // Update form when settings are loaded
  useEffect(() => {
    if (settings) {
      form.reset({
        preferredSourceLanguage: settings.preferredSourceLanguage,
        preferredTargetLanguage: settings.preferredTargetLanguage,
        voiceSpeed: settings.voiceSpeed,
        voiceGender: settings.voiceGender,
        theme: settings.theme,
        filterLevel: settings.filterLevel
      });
    }
  }, [settings, form]);
  
  // Save settings
  const onSubmit = async (values: SettingsFormValues) => {
    if (!user) return;
    
    setIsSubmitting(true);
    
    try {
      await apiRequest("POST", "/api/settings", values);
      
      // Update i18n language
      i18n.changeLanguage(values.preferredSourceLanguage);
      
      toast({
        title: t("settings.saveSuccess"),
        description: t("settings.settingsUpdated")
      });
    } catch (error) {
      toast({
        title: t("settings.saveError"),
        description: (error as Error).message,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Check if user is logged in
  if (!user) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-6">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="flex flex-col items-center justify-center">
                <SettingsIcon className="h-16 w-16 text-gray-300 mb-4" />
                <h2 className="text-2xl font-bold mb-2">{t("settings.loginRequired")}</h2>
                <p className="text-gray-500 mb-6">{t("settings.loginRequiredDescription")}</p>
                <Button asChild>
                  <Link href="/profile">
                    {t("auth.login")}
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }
  
  // Loading state
  if (isLoadingSettings || isLoadingLanguages) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-6">
          <Card>
            <CardHeader className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-2/3"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                    <div className="h-10 bg-gray-200 rounded w-full"></div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardHeader>
            <CardTitle>{t("settings.title")}</CardTitle>
            <CardDescription>{t("settings.description")}</CardDescription>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{t("settings.languagePreferences")}</h3>
                    
                    <FormField
                      control={form.control}
                      name="preferredSourceLanguage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("settings.preferredSourceLanguage")}</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t("settings.selectLanguage")} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {languages?.map((language) => (
                                <SelectItem key={language.code} value={language.code}>
                                  <span className="flex items-center">
                                    {language.flagCode && (
                                      <img
                                        src={`https://cdn.jsdelivr.net/npm/country-flag-icons/3x2/${language.flagCode}.svg`}
                                        alt={language.name}
                                        className="w-4 h-3 mr-2"
                                      />
                                    )}
                                    {language.nativeName}
                                  </span>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            {t("settings.preferredSourceLanguageDescription")}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="preferredTargetLanguage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("settings.preferredTargetLanguage")}</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t("settings.selectLanguage")} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {languages?.map((language) => (
                                <SelectItem key={language.code} value={language.code}>
                                  <span className="flex items-center">
                                    {language.flagCode && (
                                      <img
                                        src={`https://cdn.jsdelivr.net/npm/country-flag-icons/3x2/${language.flagCode}.svg`}
                                        alt={language.name}
                                        className="w-4 h-3 mr-2"
                                      />
                                    )}
                                    {language.nativeName}
                                  </span>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            {t("settings.preferredTargetLanguageDescription")}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{t("settings.voiceSettings")}</h3>
                    
                    <FormField
                      control={form.control}
                      name="voiceGender"
                      render={({ field }) => (
                        <FormItem className="space-y-1">
                          <FormLabel>{t("settings.voiceGender")}</FormLabel>
                          <FormDescription>
                            {t("settings.voiceGenderDescription")}
                          </FormDescription>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="FEMALE" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  {t("settings.female")}
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="MALE" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  {t("settings.male")}
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="voiceSpeed"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("settings.voiceSpeed")}: {field.value}x</FormLabel>
                          <FormControl>
                            <Slider
                              min={0.25}
                              max={2}
                              step={0.25}
                              defaultValue={[field.value]}
                              onValueChange={(values) => field.onChange(values[0])}
                              value={[field.value]}
                            />
                          </FormControl>
                          <FormDescription>
                            {t("settings.voiceSpeedDescription")}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{t("settings.contentFiltering")}</h3>
                    
                    <FormField
                      control={form.control}
                      name="filterLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("settings.filterLevel")}</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t("settings.selectFilterLevel")} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="mild">{t("settings.filterLevelMild")}</SelectItem>
                              <SelectItem value="moderate">{t("settings.filterLevelModerate")}</SelectItem>
                              <SelectItem value="strict">{t("settings.filterLevelStrict")}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            {t("settings.filterLevelDescription")}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{t("settings.appearance")}</h3>
                    
                    <FormField
                      control={form.control}
                      name="theme"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("settings.theme")}</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t("settings.selectTheme")} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="light">{t("settings.themeLight")}</SelectItem>
                              <SelectItem value="dark">{t("settings.themeDark")}</SelectItem>
                              <SelectItem value="system">{t("settings.themeSystem")}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            {t("settings.themeDescription")}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <div className="mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      {t("settings.saving")}
                    </>
                  ) : (
                    t("settings.saveSettings")
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
          
          <CardFooter className="flex justify-between border-t pt-6">
            <Button variant="outline" asChild>
              <Link href="/profile">
                <User className="mr-2 h-4 w-4" />
                {t("profile.title")}
              </Link>
            </Button>
            
            {user.isAdmin && (
              <Button variant="default" asChild>
                <Link href="/admin/dashboard">
                  {t("admin.dashboard")}
                </Link>
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
}
