import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Badge } from '@/components/ui/badge';
import { PlusCircle, UserPlus, Filter, Calendar, SearchIcon, UserCheck, UserX, MessageSquare } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { apiRequest } from '@/lib/queryClient';

// Define zod schema for new contact
const contactFormSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters' }),
  source: z.string().min(2, { message: 'Source is required' }),
  religion: z.string().optional(),
  interests: z.string().optional(),
  notes: z.string().optional(),
});

// Define zod schema for interaction
const interactionFormSchema = z.object({
  interactionType: z.string().min(2, { message: 'Type is required' }),
  topic: z.string().min(2, { message: 'Topic is required' }),
  notes: z.string().min(2, { message: 'Notes are required' }),
});

// Define contact status update schema
const statusUpdateSchema = z.object({
  status: z.enum([
    'initial_contact', 
    'interested', 
    'learning', 
    'convinced', 
    'converted', 
    'inactive'
  ]),
  notes: z.string().optional(),
});

// Types for contacts and interactions
type Contact = {
  id: string;
  name: string;
  source: string;
  religion?: string;
  interests?: string[];
  interactions: {
    date: string;
    type: string;
    topic: string;
    notes: string;
  }[];
  status: 'initial_contact' | 'interested' | 'learning' | 'convinced' | 'converted' | 'inactive';
  follow_up_date?: string;
};

type StatusColors = {
  [key: string]: string;
};

const ContactsPage = () => {
  const { toast } = useToast();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [filteredContacts, setFilteredContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [openInteractionDialog, setOpenInteractionDialog] = useState(false);
  const [openStatusDialog, setOpenStatusDialog] = useState(false);
  
  // Form hooks
  const contactForm = useForm<z.infer<typeof contactFormSchema>>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      source: '',
      religion: '',
      interests: '',
      notes: '',
    },
  });
  
  const interactionForm = useForm<z.infer<typeof interactionFormSchema>>({
    resolver: zodResolver(interactionFormSchema),
    defaultValues: {
      interactionType: 'question_answered',
      topic: '',
      notes: '',
    },
  });
  
  const statusForm = useForm<z.infer<typeof statusUpdateSchema>>({
    resolver: zodResolver(statusUpdateSchema),
    defaultValues: {
      status: 'interested',
      notes: '',
    },
  });
  
  // Status display styles
  const statusColors: StatusColors = {
    'initial_contact': 'bg-gray-500',
    'interested': 'bg-blue-500',
    'learning': 'bg-yellow-500',
    'convinced': 'bg-purple-500',
    'converted': 'bg-green-500',
    'inactive': 'bg-red-500',
  };
  
  const statusTranslations: { [key: string]: string } = {
    'initial_contact': 'أول اتصال',
    'interested': 'مهتم',
    'learning': 'يتعلم',
    'convinced': 'مقتنع',
    'converted': 'اهتدى',
    'inactive': 'غير نشط',
  };
  
  // Fetch contacts on component mount
  useEffect(() => {
    fetchContacts();
  }, []);
  
  // Update filtered contacts when contacts, status filter or search term change
  useEffect(() => {
    let filtered = [...contacts];
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(contact => contact.status === statusFilter);
    }
    
    // Apply search term
    if (searchTerm.trim() !== '') {
      const lowerSearchTerm = searchTerm.toLowerCase();
      filtered = filtered.filter(contact => 
        contact.name.toLowerCase().includes(lowerSearchTerm) ||
        (contact.religion && contact.religion.toLowerCase().includes(lowerSearchTerm)) ||
        (contact.interests && contact.interests.some(interest => 
          interest.toLowerCase().includes(lowerSearchTerm)
        ))
      );
    }
    
    setFilteredContacts(filtered);
  }, [contacts, statusFilter, searchTerm]);
  
  // Fetch all contacts
  const fetchContacts = async () => {
    try {
      setIsLoading(true);
      const response = await apiRequest('GET', '/api/dawah/contacts');
      const data = await response.json();
      setContacts(data.contacts || []);
    } catch (error) {
      console.error('Error fetching contacts:', error);
      toast({
        title: 'خطأ في جلب جهات الاتصال',
        description: 'حدث خطأ أثناء محاولة جلب قائمة جهات الاتصال',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Add a new contact
  const addNewContact = async (values: z.infer<typeof contactFormSchema>) => {
    try {
      setIsLoading(true);
      
      // Split interests by comma
      const interestsList = values.interests 
        ? values.interests.split(',').map(i => i.trim()) 
        : undefined;
      
      const response = await apiRequest('POST', '/api/dawah/contacts', {
        name: values.name,
        source: values.source,
        religion: values.religion || undefined,
        interests: interestsList,
        notes: values.notes
      });
      
      const data = await response.json();
      
      // Fetch updated contacts list
      await fetchContacts();
      
      setOpenAddDialog(false);
      contactForm.reset();
      
      toast({
        title: 'تمت الإضافة بنجاح',
        description: `تمت إضافة ${values.name} إلى قائمة جهات الاتصال`,
      });
    } catch (error) {
      console.error('Error adding contact:', error);
      toast({
        title: 'خطأ في إضافة جهة اتصال',
        description: 'حدث خطأ أثناء محاولة إضافة جهة اتصال جديدة',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Add an interaction to a contact
  const addInteraction = async (values: z.infer<typeof interactionFormSchema>) => {
    if (!selectedContact) return;
    
    try {
      setIsLoading(true);
      
      const response = await apiRequest('POST', `/api/dawah/contacts/${selectedContact.id}/interaction`, {
        interactionType: values.interactionType,
        topic: values.topic,
        notes: values.notes
      });
      
      // Fetch updated contacts list
      await fetchContacts();
      
      setOpenInteractionDialog(false);
      interactionForm.reset();
      
      toast({
        title: 'تمت إضافة التفاعل بنجاح',
        description: `تمت إضافة تفاعل جديد لـ ${selectedContact.name}`,
      });
    } catch (error) {
      console.error('Error adding interaction:', error);
      toast({
        title: 'خطأ في إضافة التفاعل',
        description: 'حدث خطأ أثناء محاولة إضافة تفاعل جديد',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Update contact status
  const updateStatus = async (values: z.infer<typeof statusUpdateSchema>) => {
    if (!selectedContact) return;
    
    try {
      setIsLoading(true);
      
      const response = await apiRequest('PUT', `/api/dawah/contacts/${selectedContact.id}/status`, {
        status: values.status,
        notes: values.notes
      });
      
      // Fetch updated contacts list
      await fetchContacts();
      
      setOpenStatusDialog(false);
      statusForm.reset();
      
      toast({
        title: 'تم تحديث الحالة بنجاح',
        description: `تم تحديث حالة ${selectedContact.name} إلى ${statusTranslations[values.status]}`,
      });
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: 'خطأ في تحديث الحالة',
        description: 'حدث خطأ أثناء محاولة تحديث حالة جهة الاتصال',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('ar', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  return (
    <div className="container mx-auto py-8 rtl">
      <h1 className="text-3xl font-bold mb-6 text-center">إدارة المهتمين بالإسلام</h1>
      
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-4">
          <Button 
            onClick={() => setOpenAddDialog(true)}
            className="px-4 py-2 flex items-center gap-2"
          >
            <UserPlus size={18} />
            <span>إضافة شخص جديد</span>
          </Button>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <div className="flex items-center space-x-2">
                <Filter size={16} />
                <SelectValue placeholder="تصفية حسب الحالة" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="initial_contact">أول اتصال</SelectItem>
              <SelectItem value="interested">مهتم</SelectItem>
              <SelectItem value="learning">يتعلم</SelectItem>
              <SelectItem value="convinced">مقتنع</SelectItem>
              <SelectItem value="converted">اهتدى</SelectItem>
              <SelectItem value="inactive">غير نشط</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input 
            placeholder="بحث عن اسم أو دين أو اهتمام..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-[300px]"
          />
        </div>
      </div>
      
      {isLoading && contacts.length === 0 ? (
        <div className="text-center py-8">جاري التحميل...</div>
      ) : filteredContacts.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-xl">لم يتم العثور على جهات اتصال</p>
          <p className="text-gray-500 mt-2">قم بإضافة جهات اتصال جديدة باستخدام الزر أعلاه</p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">الاسم</TableHead>
                <TableHead className="text-right">المصدر</TableHead>
                <TableHead className="text-right">الدين</TableHead>
                <TableHead className="text-right">الاهتمامات</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">آخر تفاعل</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredContacts.map((contact) => (
                <TableRow key={contact.id}>
                  <TableCell className="font-medium">{contact.name}</TableCell>
                  <TableCell>{contact.source}</TableCell>
                  <TableCell>{contact.religion || 'غير محدد'}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {contact.interests && contact.interests.length > 0 ? 
                        contact.interests.map((interest, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {interest}
                          </Badge>
                        )) : 
                        'غير محدد'
                      }
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={`${statusColors[contact.status]} text-white`}>
                      {statusTranslations[contact.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {contact.interactions && contact.interactions.length > 0 ? 
                      formatDate(contact.interactions[contact.interactions.length - 1].date) : 
                      'لا يوجد'
                    }
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => {
                          setSelectedContact(contact);
                          setOpenInteractionDialog(true);
                        }}
                      >
                        <MessageSquare size={16} className="ml-1" />
                        تفاعل
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => {
                          setSelectedContact(contact);
                          statusForm.setValue('status', contact.status);
                          setOpenStatusDialog(true);
                        }}
                      >
                        <Calendar size={16} className="ml-1" />
                        تحديث
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      
      {/* Contact Details Dialog (when a contact is selected) */}
      {selectedContact && (
        <Dialog open={!!selectedContact} onOpenChange={(open) => !open && setSelectedContact(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>تفاصيل: {selectedContact.name}</DialogTitle>
              <DialogDescription>
                مصدر الاتصال: {selectedContact.source}
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="info">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="info">المعلومات الأساسية</TabsTrigger>
                <TabsTrigger value="interactions">التفاعلات ({selectedContact.interactions?.length || 0})</TabsTrigger>
                <TabsTrigger value="journey">رحلة الهداية</TabsTrigger>
              </TabsList>
              
              <TabsContent value="info">
                <div className="space-y-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>الاسم</Label>
                      <div className="mt-1">{selectedContact.name}</div>
                    </div>
                    <div>
                      <Label>المصدر</Label>
                      <div className="mt-1">{selectedContact.source}</div>
                    </div>
                    <div>
                      <Label>الدين</Label>
                      <div className="mt-1">{selectedContact.religion || 'غير محدد'}</div>
                    </div>
                    <div>
                      <Label>الحالة</Label>
                      <div className="mt-1">
                        <Badge className={`${statusColors[selectedContact.status]} text-white`}>
                          {statusTranslations[selectedContact.status]}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <Label>الاهتمامات</Label>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {selectedContact.interests && selectedContact.interests.length > 0 ? 
                        selectedContact.interests.map((interest, i) => (
                          <Badge key={i} variant="secondary" className="text-sm">
                            {interest}
                          </Badge>
                        )) : 
                        'لم يتم تحديد اهتمامات'
                      }
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="interactions">
                {selectedContact.interactions && selectedContact.interactions.length > 0 ? (
                  <div className="space-y-4 py-4 max-h-[400px] overflow-y-auto">
                    {selectedContact.interactions.map((interaction, i) => (
                      <Card key={i}>
                        <CardHeader className="py-4">
                          <div className="flex justify-between items-center">
                            <CardTitle className="text-md font-medium">
                              {interaction.topic}
                            </CardTitle>
                            <Badge variant="outline">{interaction.type}</Badge>
                          </div>
                          <CardDescription>{formatDate(interaction.date)}</CardDescription>
                        </CardHeader>
                        <CardContent className="py-2">
                          <p>{interaction.notes}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p>لا توجد تفاعلات مسجلة</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="journey">
                <div className="py-4">
                  <div className="relative pb-12">
                    {/* Journey timeline */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="h-full w-1 bg-gray-200" />
                    </div>
                    
                    {['initial_contact', 'interested', 'learning', 'convinced', 'converted'].map((stage, i) => {
                      const isActive = ['initial_contact', 'interested', 'learning', 'convinced', 'converted']
                        .indexOf(selectedContact.status) >= i;
                      const stageInteraction = selectedContact.interactions?.find(interaction => 
                        interaction.type === 'status_change' && interaction.notes?.includes(stage)
                      );
                      
                      return (
                        <div key={stage} className="relative flex items-center mb-8">
                          <div className={`
                            flex items-center justify-center w-8 h-8 rounded-full z-10
                            ${isActive ? statusColors[selectedContact.status] : 'bg-gray-200'}
                          `}>
                            {isActive ? <UserCheck className="w-4 h-4 text-white" /> : <UserX className="w-4 h-4 text-gray-400" />}
                          </div>
                          <div className="mr-4">
                            <div className="font-medium">
                              {statusTranslations[stage as keyof typeof statusTranslations]}
                            </div>
                            {stageInteraction && (
                              <div className="text-gray-500 text-sm">{formatDate(stageInteraction.date)}</div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Add New Contact Dialog */}
      <Dialog open={openAddDialog} onOpenChange={setOpenAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة شخص مهتم جديد</DialogTitle>
            <DialogDescription>
              أضف تفاصيل الشخص المهتم للمتابعة والتواصل معه
            </DialogDescription>
          </DialogHeader>
          
          <Form {...contactForm}>
            <form onSubmit={contactForm.handleSubmit(addNewContact)} className="space-y-4">
              <FormField
                control={contactForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاسم</FormLabel>
                    <FormControl>
                      <Input placeholder="أحمد محمد" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={contactForm.control}
                name="source"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>المصدر</FormLabel>
                    <FormControl>
                      <Input placeholder="فيسبوك / تويتر / مباشر / إلخ" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={contactForm.control}
                name="religion"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الدين الحالي</FormLabel>
                    <FormControl>
                      <Input placeholder="مسيحي / ملحد / إلخ" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={contactForm.control}
                name="interests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاهتمامات</FormLabel>
                    <FormControl>
                      <Input placeholder="مفصولة بفواصل: العلم, تاريخ الإسلام, إلخ" {...field} />
                    </FormControl>
                    <FormDescription>
                      أدخل الاهتمامات مفصولة بفواصل
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={contactForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ملاحظات</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="أي ملاحظات إضافية حول الشخص المهتم" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setOpenAddDialog(false)}
                >
                  إلغاء
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? 'جاري الإضافة...' : 'إضافة شخص مهتم'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Add Interaction Dialog */}
      <Dialog open={openInteractionDialog} onOpenChange={setOpenInteractionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة تفاعل جديد</DialogTitle>
            <DialogDescription>
              {selectedContact && `إضافة تفاعل جديد مع ${selectedContact.name}`}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...interactionForm}>
            <form onSubmit={interactionForm.handleSubmit(addInteraction)} className="space-y-4">
              <FormField
                control={interactionForm.control}
                name="interactionType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نوع التفاعل</FormLabel>
                    <Select 
                      value={field.value} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر نوع التفاعل" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="question_answered">إجابة على سؤال</SelectItem>
                        <SelectItem value="material_shared">مشاركة محتوى</SelectItem>
                        <SelectItem value="conversation">محادثة</SelectItem>
                        <SelectItem value="meeting">لقاء شخصي</SelectItem>
                        <SelectItem value="follow_up">متابعة</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={interactionForm.control}
                name="topic"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الموضوع</FormLabel>
                    <FormControl>
                      <Input placeholder="موضوع التفاعل" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={interactionForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ملاحظات</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="تفاصيل التفاعل" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setOpenInteractionDialog(false)}
                >
                  إلغاء
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? 'جاري الإضافة...' : 'إضافة تفاعل'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Update Status Dialog */}
      <Dialog open={openStatusDialog} onOpenChange={setOpenStatusDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تحديث حالة الشخص المهتم</DialogTitle>
            <DialogDescription>
              {selectedContact && `تحديث حالة ${selectedContact.name} في رحلة الهداية`}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...statusForm}>
            <form onSubmit={statusForm.handleSubmit(updateStatus)} className="space-y-4">
              <FormField
                control={statusForm.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الحالة الجديدة</FormLabel>
                    <Select 
                      value={field.value} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر الحالة الجديدة" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="initial_contact">أول اتصال</SelectItem>
                        <SelectItem value="interested">مهتم</SelectItem>
                        <SelectItem value="learning">يتعلم</SelectItem>
                        <SelectItem value="convinced">مقتنع</SelectItem>
                        <SelectItem value="converted">اهتدى</SelectItem>
                        <SelectItem value="inactive">غير نشط</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={statusForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ملاحظات</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="سبب تغيير الحالة وملاحظات إضافية" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setOpenStatusDialog(false)}
                >
                  إلغاء
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? 'جاري التحديث...' : 'تحديث الحالة'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ContactsPage;