import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LanguageSelector } from "@/components/language-selector";
import { TranslationOutput } from "@/components/translation-output";
import { useCamera } from "@/hooks/use-camera";
import { useTranslation as useTranslationHook } from "@/hooks/use-translation";
import { Camera, ImageIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CameraPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [sourceLanguage, setSourceLanguage] = useState("ar");
  const [targetLanguage, setTargetLanguage] = useState("en");
  const [extractedText, setExtractedText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  
  // Camera hook
  const {
    isActive,
    isCapturing,
    videoRef,
    previewUrl,
    startCamera,
    stopCamera,
    capturePhoto,
    discardPhoto,
    isSupported: isCameraSupported
  } = useCamera({
    onSuccess: (imageSrc) => {
      processImage(imageSrc);
    },
    onError: (error) => {
      toast({
        title: t("errors.cameraError"),
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Translation hook
  const { imageToText, isImageProcessing } = useTranslationHook({
    onSuccess: (data) => {
      if ('extractedText' in data && 'translatedText' in data) {
        setExtractedText(data.extractedText);
        setTranslatedText(data.translatedText);
      }
    },
    onError: (error) => {
      toast({
        title: t("errors.imageProcessingError"),
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Process captured image
  const processImage = async (imageData: string) => {
    await imageToText(imageData, sourceLanguage, targetLanguage);
  };
  
  // Handle language swap
  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
  };
  
  // Clean up camera on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">{t("camera.title")}</h1>
        
        {/* Language Selection */}
        <LanguageSelector
          sourceLanguage={sourceLanguage}
          targetLanguage={targetLanguage}
          onSourceLanguageChange={setSourceLanguage}
          onTargetLanguageChange={setTargetLanguage}
          onSwapLanguages={handleSwapLanguages}
        />
        
        {/* Camera / Preview */}
        <Card className="mb-6">
          <CardContent className="p-4 flex flex-col items-center">
            {!isCameraSupported ? (
              <div className="text-center py-8">
                <ImageIcon className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">{t("camera.notSupported")}</p>
              </div>
            ) : previewUrl ? (
              <div className="w-full">
                <img 
                  src={previewUrl} 
                  alt={t("camera.capturedImage")} 
                  className="w-full max-h-[300px] object-contain mb-4"
                />
                
                {isImageProcessing ? (
                  <div className="flex justify-center py-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="flex justify-center space-x-2">
                    <Button onClick={discardPhoto}>
                      {t("camera.discardPhoto")}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="w-full">
                {isActive ? (
                  <div className="relative w-full max-w-lg mx-auto">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      className="w-full h-[300px] object-cover rounded-lg"
                    ></video>
                    <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white p-2 rounded-full">
                      <div className="h-3 w-3 rounded-full bg-red-500 animate-pulse"></div>
                    </div>
                  </div>
                ) : (
                  <div 
                    className="w-full h-[300px] bg-gray-100 flex items-center justify-center rounded-lg cursor-pointer"
                    onClick={startCamera}
                  >
                    <div className="text-center">
                      <Camera className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                      <p className="text-gray-500">{t("camera.tapToActivate")}</p>
                    </div>
                  </div>
                )}
                
                <div className="flex justify-center mt-4">
                  {isActive && (
                    <Button 
                      onClick={capturePhoto} 
                      disabled={isCapturing}
                      className="rounded-full w-16 h-16 flex items-center justify-center"
                    >
                      <div className="w-14 h-14 border-4 border-white rounded-full flex items-center justify-center">
                        <div className="w-12 h-12 bg-white rounded-full"></div>
                      </div>
                    </Button>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Extracted Text */}
        {extractedText && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <h2 className="text-lg font-medium text-gray-700 mb-2">{t("camera.extractedText")}</h2>
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                <p className="text-gray-800 whitespace-pre-line">{extractedText}</p>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Translation Output */}
        {extractedText && (
          <TranslationOutput
            translatedText={translatedText}
            targetLanguage={targetLanguage}
            isTranslating={isImageProcessing}
          />
        )}
      </div>
    </Layout>
  );
}
