import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RecentTranslations } from "@/components/recent-translations";
import { AuthContext } from "@/App";
import { useContext } from "react";
import { Search, History as HistoryIcon } from "lucide-react";
import { Link } from "wouter";

export default function History() {
  const { t } = useTranslation();
  const { user } = useContext(AuthContext);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Check if user is logged in
  if (!user) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-6">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="flex flex-col items-center justify-center">
                <HistoryIcon className="h-16 w-16 text-gray-300 mb-4" />
                <h2 className="text-2xl font-bold mb-2">{t("history.loginRequired")}</h2>
                <p className="text-gray-500 mb-6">{t("history.loginRequiredDescription")}</p>
                <Button asChild>
                  <Link href="/profile">
                    {t("auth.login")}
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">{t("history.title")}</h1>
        </div>
        
        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t("history.searchPlaceholder")}
            className="w-full pl-9"
          />
        </div>
        
        {/* History */}
        <Card>
          <CardHeader>
            <CardTitle>{t("history.allTranslations")}</CardTitle>
          </CardHeader>
          <CardContent>
            <RecentTranslations limit={50} showViewAll={false} />
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
