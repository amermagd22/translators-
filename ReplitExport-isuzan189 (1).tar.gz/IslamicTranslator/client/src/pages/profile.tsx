import { useState, useContext } from "react";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Layout } from "@/components/layout";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AuthContext } from "@/App";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { User, LogIn } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(3, {
    message: "اسم المستخدم يجب أن يحتوي على الأقل 3 أحرف"
  }),
  password: z.string().min(6, {
    message: "كلمة المرور يجب أن تحتوي على الأقل 6 أحرف"
  })
});

const registerSchema = loginSchema.extend({
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "كلمات المرور غير متطابقة",
  path: ["confirmPassword"]
});

export default function Profile() {
  const { t } = useTranslation();
  const { user, login, logout } = useContext(AuthContext);
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Login form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: ""
    }
  });
  
  // Register form
  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: ""
    }
  });
  
  // Handle login
  const handleLogin = async (values: z.infer<typeof loginSchema>) => {
    setIsSubmitting(true);
    
    try {
      await login(values.username, values.password);
      
      toast({
        title: t("auth.loginSuccess"),
        description: t("auth.welcomeBack", { username: values.username })
      });
      
      loginForm.reset();
    } catch (error) {
      toast({
        title: t("auth.loginError"),
        description: (error as Error).message,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle register
  const handleRegister = async (values: z.infer<typeof registerSchema>) => {
    setIsSubmitting(true);
    
    try {
      // Omit confirmPassword before sending to server
      const { confirmPassword, ...userData } = values;
      
      await apiRequest("POST", "/api/register", userData);
      
      toast({
        title: t("auth.registerSuccess"),
        description: t("auth.accountCreated")
      });
      
      registerForm.reset();
      
      // Auto login after registration
      await login(userData.username, userData.password);
    } catch (error) {
      toast({
        title: t("auth.registerError"),
        description: (error as Error).message,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
      
      toast({
        description: t("auth.logoutSuccess")
      });
    } catch (error) {
      toast({
        title: t("auth.logoutError"),
        description: (error as Error).message,
        variant: "destructive"
      });
    }
  };
  
  // If user is already logged in
  if (user) {
    return (
      <Layout showBottomNav={false}>
        <div className="container mx-auto px-4 py-6">
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl">{t("profile.title")}</CardTitle>
              <CardDescription>{t("profile.yourAccount")}</CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="flex flex-col items-center space-y-4 py-6">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="h-12 w-12 text-primary" />
                </div>
                
                <div className="text-center">
                  <h2 className="text-xl font-bold">{user.username}</h2>
                  {user.isAdmin && (
                    <span className="inline-block bg-secondary/10 text-secondary text-xs px-2 py-1 rounded-full mt-1">
                      {t("profile.admin")}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="space-y-4 mt-6">
                <div className="border rounded-lg p-3">
                  <p className="text-sm text-gray-500">{t("profile.accountType")}</p>
                  <p className="font-medium">
                    {user.isAdmin ? t("profile.adminAccount") : t("profile.standardAccount")}
                  </p>
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={handleLogout}>
                <LogIn className="mr-2 h-4 w-4 rotate-180" />
                {t("auth.logout")}
              </Button>
              
              {user.isAdmin && (
                <Button variant="default" asChild>
                  <a href="/admin/dashboard">
                    {t("admin.dashboard")}
                  </a>
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </Layout>
    );
  }
  
  // Auth forms for non-logged in users
  return (
    <Layout showBottomNav={false}>
      <div className="container mx-auto px-4 py-6">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl">{t("auth.title")}</CardTitle>
            <CardDescription>{t("auth.subtitle")}</CardDescription>
          </CardHeader>
          
          <CardContent>
            <Tabs defaultValue="login">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">{t("auth.login")}</TabsTrigger>
                <TabsTrigger value="register">{t("auth.register")}</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.username")}</FormLabel>
                          <FormControl>
                            <Input placeholder={t("auth.usernamePlaceholder")} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.password")}</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder={t("auth.passwordPlaceholder")} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <div className="mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          {t("auth.loggingIn")}
                        </>
                      ) : (
                        t("auth.login")
                      )}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
              
              <TabsContent value="register">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.username")}</FormLabel>
                          <FormControl>
                            <Input placeholder={t("auth.usernamePlaceholder")} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.password")}</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder={t("auth.passwordPlaceholder")} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("auth.confirmPassword")}</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder={t("auth.confirmPasswordPlaceholder")} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <div className="mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          {t("auth.registering")}
                        </>
                      ) : (
                        t("auth.register")
                      )}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
