import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LanguageSelector } from "@/components/language-selector";
import { useSpeechRecognition, useSpeechSynthesis } from "@/hooks/use-speech";
import { useTranslation as useTranslationHook } from "@/hooks/use-translation";
import { getLanguageDirection, getLanguageFontClass } from "@/lib/utils";
import { Mic, MicOff, Volume2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ConversationMessage {
  id: number;
  sourceText: string;
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  timestamp: Date;
}

export default function Conversation() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [sourceLanguage, setSourceLanguage] = useState("ar");
  const [targetLanguage, setTargetLanguage] = useState("en");
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [isContinuousMode, setIsContinuousMode] = useState(false);
  const [currentSpeaker, setCurrentSpeaker] = useState<"source" | "target">("source");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Translation hook
  const { translateText } = useTranslationHook({
    onSuccess: (data) => {
      if ('translatedText' in data) {
        // Add new message
        const newMessage: ConversationMessage = {
          id: Date.now(),
          sourceText: lastTranscript.current,
          translatedText: data.translatedText,
          sourceLanguage: currentSpeaker === "source" ? sourceLanguage : targetLanguage,
          targetLanguage: currentSpeaker === "source" ? targetLanguage : sourceLanguage,
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, newMessage]);
        
        // Speak the translation
        speechSynthesis.speak(
          data.translatedText, 
          { language: currentSpeaker === "source" ? targetLanguage : sourceLanguage }
        );
      }
    }
  });
  
  // For storing the last transcript before processing
  const lastTranscript = useRef("");
  
  // Speech recognition
  const { 
    transcript, 
    isListening, 
    startListening, 
    stopListening,
    isSupported: isSpeechRecognitionSupported
  } = useSpeechRecognition({
    language: currentSpeaker === "source" ? sourceLanguage : targetLanguage,
    continuous: isContinuousMode,
    onResult: (text) => {
      lastTranscript.current = text;
    },
    onEnd: async () => {
      if (lastTranscript.current.trim()) {
        // Translate the text
        const fromLang = currentSpeaker === "source" ? sourceLanguage : targetLanguage;
        const toLang = currentSpeaker === "source" ? targetLanguage : sourceLanguage;
        
        await translateText(lastTranscript.current, fromLang, toLang);
      }
    }
  });
  
  // Speech synthesis
  const { speak, isSupported: isSpeechSynthesisSupported } = useSpeechSynthesis();
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  // Toggle between speakers
  const toggleSpeaker = () => {
    stopListening();
    setCurrentSpeaker(prev => prev === "source" ? "target" : "source");
  };
  
  // Start conversation
  const startConversation = () => {
    if (!isSpeechRecognitionSupported) {
      toast({
        title: t("errors.unsupportedBrowser"),
        description: t("errors.speechRecognitionNotSupported"),
        variant: "destructive"
      });
      return;
    }
    
    startListening();
  };
  
  // Clear conversation
  const clearConversation = () => {
    setMessages([]);
  };
  
  // Handle language swap
  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
  };
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">{t("conversation.title")}</h1>
        
        {/* Language Selection */}
        <LanguageSelector
          sourceLanguage={sourceLanguage}
          targetLanguage={targetLanguage}
          onSourceLanguageChange={setSourceLanguage}
          onTargetLanguageChange={setTargetLanguage}
          onSwapLanguages={handleSwapLanguages}
        />
        
        {/* Current speaker indicator */}
        <div className="mb-4 flex justify-center">
          <Card className="w-fit">
            <CardContent className="p-4 flex items-center">
              <span className="mr-2">{t("conversation.currentSpeaker")}:</span>
              <span className="font-bold">
                {currentSpeaker === "source" 
                  ? t(`languages.${sourceLanguage}`) 
                  : t(`languages.${targetLanguage}`)}
              </span>
              <Button 
                variant="outline" 
                size="sm" 
                className="ml-2"
                onClick={toggleSpeaker}
              >
                {t("conversation.changeSpeaker")}
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Conversation Area */}
        <Card className="mb-4">
          <CardContent className="p-4 h-[400px] overflow-y-auto">
            {messages.length === 0 ? (
              <div className="h-full flex items-center justify-center text-gray-500">
                {t("conversation.empty")}
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => {
                  const isSourceMessage = message.sourceLanguage === sourceLanguage;
                  const sourceDirection = getLanguageDirection(message.sourceLanguage);
                  const targetDirection = getLanguageDirection(message.targetLanguage);
                  const sourceFontClass = getLanguageFontClass(message.sourceLanguage);
                  const targetFontClass = getLanguageFontClass(message.targetLanguage);
                  
                  return (
                    <div 
                      key={message.id}
                      className={`flex flex-col ${isSourceMessage ? "items-start" : "items-end"}`}
                    >
                      <div 
                        className={`max-w-[80%] p-3 rounded-lg mb-1 ${
                          isSourceMessage 
                            ? "bg-primary text-white rounded-bl-none" 
                            : "bg-gray-100 text-gray-800 rounded-br-none"
                        }`}
                      >
                        <p 
                          className={sourceFontClass}
                          dir={sourceDirection}
                        >
                          {message.sourceText}
                        </p>
                      </div>
                      <div 
                        className={`max-w-[80%] p-3 bg-gray-100 rounded-lg ${
                          isSourceMessage ? "rounded-tl-none" : "rounded-tr-none"
                        }`}
                      >
                        <p 
                          className={targetFontClass}
                          dir={targetDirection}
                        >
                          {message.translatedText}
                        </p>
                      </div>
                      <div className="flex mt-1">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => speak(
                            message.translatedText, 
                            { language: message.targetLanguage }
                          )}
                        >
                          <Volume2 className="h-4 w-4 mr-1" />
                          {t("actions.speak")}
                        </Button>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Controls */}
        <div className="flex flex-col items-center space-y-4">
          <div className="flex space-x-2">
            <Button
              variant={isListening ? "destructive" : "default"}
              size="lg"
              onClick={isListening ? stopListening : startConversation}
              className="rounded-full w-16 h-16 flex items-center justify-center"
            >
              {isListening ? (
                <MicOff className="h-8 w-8" />
              ) : (
                <Mic className="h-8 w-8" />
              )}
            </Button>
          </div>
          
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={toggleSpeaker}
              disabled={isListening}
            >
              {t("conversation.changeSpeaker")}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={clearConversation}
              disabled={messages.length === 0}
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              {t("conversation.clear")}
            </Button>
          </div>
          
          {isListening && (
            <Card className="bg-primary/10 w-full max-w-md">
              <CardContent className="p-4 text-center">
                <div className="mic-animation text-primary text-center mb-2">
                  <Mic className="h-6 w-6 mx-auto" />
                </div>
                <p>{t("conversation.listening")}</p>
                {transcript && (
                  <p className="mt-2 font-bold">{transcript}</p>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
