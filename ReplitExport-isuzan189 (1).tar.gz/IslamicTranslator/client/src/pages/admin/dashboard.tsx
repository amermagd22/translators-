import { useState, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { AuthContext } from "@/App";
import { 
  BarChart as BarChartIcon, 
  Users, 
  Languages, 
  ListFilter, 
  Search, 
  ChevronLeft 
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchLanguages } from "@/lib/translation";
import { Link } from "wouter";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";

export default function AdminDashboard() {
  const { t } = useTranslation();
  const { user } = useContext(AuthContext);
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [filterSearch, setFilterSearch] = useState("");
  
  // Redirect if user is not admin
  useEffect(() => {
    if (user && !user.isAdmin) {
      toast({
        title: t("admin.unauthorized"),
        description: t("admin.unauthorizedDescription"),
        variant: "destructive"
      });
      
      // Redirect to home
      window.location.href = "/";
    }
  }, [user, toast, t]);
  
  // Stats query
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/admin/stats"],
    queryFn: async () => {
      const res = await fetch("/api/admin/stats?days=7", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to load stats");
      return res.json();
    },
    enabled: !!user?.isAdmin,
    refetchOnWindowFocus: false
  });
  
  // Prohibited words query
  const { data: prohibitedWords, isLoading: isLoadingWords } = useQuery({
    queryKey: ["/api/admin/prohibited-words"],
    queryFn: async () => {
      const res = await fetch("/api/admin/prohibited-words", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to load prohibited words");
      return res.json();
    },
    enabled: !!user?.isAdmin && activeTab === "content-filter",
    refetchOnWindowFocus: false
  });
  
  // Languages query
  const { data: languages } = useQuery({
    queryKey: ["/api/languages"],
    queryFn: fetchLanguages,
    staleTime: Infinity
  });
  
  // Calculate total stats
  const calculateTotalStats = () => {
    if (!stats) return { text: 0, voice: 0, image: 0, total: 0 };
    
    const totals = stats.reduce((acc, day) => {
      acc.text += day.textTranslations;
      acc.voice += day.voiceTranslations;
      acc.image += day.imageTranslations;
      acc.total += day.textTranslations + day.voiceTranslations + day.imageTranslations;
      return acc;
    }, { text: 0, voice: 0, image: 0, total: 0 });
    
    return totals;
  };
  
  // Format for charts
  const formatStatsForChart = () => {
    if (!stats) return [];
    
    return stats.map(day => ({
      date: new Date(day.date).toLocaleDateString(),
      text: day.textTranslations,
      voice: day.voiceTranslations,
      image: day.imageTranslations
    })).reverse();
  };
  
  // Format for pie chart
  const formatStatsForPieChart = () => {
    const totals = calculateTotalStats();
    
    return [
      { name: t("admin.textTranslations"), value: totals.text },
      { name: t("admin.voiceTranslations"), value: totals.voice },
      { name: t("admin.imageTranslations"), value: totals.image }
    ];
  };
  
  // Format for languages chart
  const formatLanguageStats = () => {
    if (!stats || !stats[0]?.languageStats) return [];
    
    const languageCounts = {};
    
    stats.forEach(day => {
      const langs = day.languageStats;
      Object.keys(langs).forEach(lang => {
        languageCounts[lang] = (languageCounts[lang] || 0) + langs[lang];
      });
    });
    
    return Object.entries(languageCounts).map(([code, count]) => {
      const language = languages?.find(l => l.code === code);
      return {
        name: language ? language.name : code,
        value: count as number
      };
    }).sort((a, b) => b.value - a.value).slice(0, 5);
  };
  
  // Filter prohibited words
  const filteredProhibitedWords = prohibitedWords 
    ? prohibitedWords.filter(word => 
        word.word.toLowerCase().includes(filterSearch.toLowerCase()) ||
        word.language.toLowerCase().includes(filterSearch.toLowerCase()) ||
        word.category.toLowerCase().includes(filterSearch.toLowerCase())
      )
    : [];
  
  // Check if user is not admin
  if (user && !user.isAdmin) {
    return null; // Redirect happens in useEffect
  }
  
  // Loading state
  if (isLoadingStats && activeTab === "overview") {
    return (
      <Layout showBottomNav={false}>
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">{t("admin.dashboard")}</h1>
            <Button variant="outline" asChild>
              <Link href="/">
                <ChevronLeft className="mr-2 h-4 w-4" />
                {t("admin.backToApp")}
              </Link>
            </Button>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 animate-pulse">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardHeader className="h-24 bg-gray-200 rounded"></CardHeader>
                <CardContent className="h-40 bg-gray-200 rounded mt-4"></CardContent>
              </Card>
            ))}
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout showBottomNav={false}>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">{t("admin.dashboard")}</h1>
          <Button variant="outline" asChild>
            <Link href="/">
              <ChevronLeft className="mr-2 h-4 w-4" />
              {t("admin.backToApp")}
            </Link>
          </Button>
        </div>
        
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="overview">
              <BarChartIcon className="ml-2 h-4 w-4" />
              {t("admin.overview")}
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="ml-2 h-4 w-4" />
              {t("admin.users")}
            </TabsTrigger>
            <TabsTrigger value="languages">
              <Languages className="ml-2 h-4 w-4" />
              {t("admin.languages")}
            </TabsTrigger>
            <TabsTrigger value="content-filter">
              <ListFilter className="ml-2 h-4 w-4" />
              {t("admin.contentFilter")}
            </TabsTrigger>
          </TabsList>
          
          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.totalTranslations")}</CardTitle>
                  <CardDescription>{t("admin.last7Days")}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold mb-4">{calculateTotalStats().total}</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={formatStatsForChart()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="text" name={t("admin.textTranslations")} fill="hsl(var(--chart-1))" />
                      <Bar dataKey="voice" name={t("admin.voiceTranslations")} fill="hsl(var(--chart-2))" />
                      <Bar dataKey="image" name={t("admin.imageTranslations")} fill="hsl(var(--chart-3))" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.translationTypes")}</CardTitle>
                  <CardDescription>{t("admin.distributionByType")}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={formatStatsForPieChart()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        <Cell fill="hsl(var(--chart-1))" />
                        <Cell fill="hsl(var(--chart-2))" />
                        <Cell fill="hsl(var(--chart-3))" />
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.popularLanguages")}</CardTitle>
                  <CardDescription>{t("admin.top5Languages")}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={formatLanguageStats()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {formatLanguageStats().map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={`hsl(var(--chart-${(index % 5) + 1}))`} 
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Users Tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>{t("admin.userManagement")}</CardTitle>
                <CardDescription>{t("admin.userManagementDescription")}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 text-center py-8">
                  {t("admin.userManagementComingSoon")}
                </p>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Languages Tab */}
          <TabsContent value="languages">
            <Card>
              <CardHeader>
                <CardTitle>{t("admin.languageManagement")}</CardTitle>
                <CardDescription>{t("admin.languageManagementDescription")}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 text-center py-8">
                  {t("admin.languageManagementComingSoon")}
                </p>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Content Filter Tab */}
          <TabsContent value="content-filter">
            <Card>
              <CardHeader>
                <CardTitle>{t("admin.contentFilterManagement")}</CardTitle>
                <CardDescription>{t("admin.contentFilterDescription")}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative mb-6">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                  <Input
                    value={filterSearch}
                    onChange={(e) => setFilterSearch(e.target.value)}
                    placeholder={t("admin.searchProhibitedWords")}
                    className="w-full pl-9"
                  />
                </div>
                
                {isLoadingWords ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="border rounded-md">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t("admin.word")}</TableHead>
                          <TableHead>{t("admin.language")}</TableHead>
                          <TableHead>{t("admin.category")}</TableHead>
                          <TableHead>{t("admin.replacement")}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredProhibitedWords.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center py-4">
                              {filterSearch 
                                ? t("admin.noProhibitedWordsFound") 
                                : t("admin.noProhibitedWords")}
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredProhibitedWords.map((word) => (
                            <TableRow key={word.id}>
                              <TableCell className="font-medium">{word.word}</TableCell>
                              <TableCell>{word.language}</TableCell>
                              <TableCell>{word.category}</TableCell>
                              <TableCell>
                                {word.replacement || t("admin.defaultReplacement")}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
