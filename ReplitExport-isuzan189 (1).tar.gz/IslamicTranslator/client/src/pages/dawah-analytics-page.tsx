import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { apiRequest } from '@/lib/queryClient';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell 
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  BookOpen, 
  Heart, 
  ThumbsUp, 
  Map, 
  Activity, 
  CheckCircle, 
  Download,
  FileText,
  BarChart2
} from 'lucide-react';

// Types for the analytics data
type ConversionStats = {
  conversionFunnel: {
    initial_contact: number;
    interested: number;
    learning: number;
    convinced: number;
    converted: number;
    inactive: number;
  };
  totalContacts: number;
  conversionRate: number;
  mostEffectiveTopics: Array<{
    topic: string;
    conversions: number;
    effectiveness: number;
  }>;
};

type RegionalStats = {
  regions: Array<{
    region: string;
    stats: {
      interactions: number;
      questions_answered: number;
      materials_shared: number;
      potential_converts: number;
      conversions: number;
      conversion_rate: number;
      top_topics: Array<{
        topic: string;
        count: number;
      }>;
    };
    timeline?: Array<{
      date: string;
      interactions: number;
      conversions: number;
    }>;
  }>;
};

type TopicInsights = {
  topics: Array<{
    topic: string;
    total_uses: number;
    questions_generated: number;
    positive_responses: number;
    conversions_influenced: number;
    conversion_effectiveness: number;
    average_engagement_time: number;
  }>;
};

type DemographicInsights = {
  demographics: Array<{
    demographic: string;
    count: number;
    conversion_rate: number;
    average_journey_length: number;
  }>;
  most_responsive: string;
  fastest_conversion: string;
};

type DawahReport = {
  summary: {
    total_interactions: number;
    total_conversions: number;
    overall_conversion_rate: number;
    active_regions: number;
    most_effective_region: string;
    most_effective_topic: string;
    most_responsive_demographic: string;
  };
  conversion_funnel: {
    initial_contact: number;
    interested: number;
    learning: number;
    convinced: number;
    converted: number;
    inactive: number;
  };
  top_regions: Array<{
    region: string;
    conversions: number;
    conversion_rate: number;
  }>;
  top_topics: Array<{
    topic: string;
    conversions: number;
    effectiveness: number;
  }>;
  top_demographics: Array<{
    demographic: string;
    conversion_rate: number;
    count: number;
  }>;
  recommendations: string[];
};

// Translations for display
const regionTranslations: { [key: string]: string } = {
  'north_america': 'أمريكا الشمالية',
  'europe': 'أوروبا',
  'middle_east': 'الشرق الأوسط',
  'africa': 'أفريقيا',
  'asia': 'آسيا',
  'australia': 'أستراليا',
  'south_america': 'أمريكا الجنوبية',
  'online': 'عبر الإنترنت'
};

const demographicTranslations: { [key: string]: string } = {
  'students': 'طلاب',
  'professionals': 'محترفون',
  'religious_seekers': 'باحثون عن الدين',
  'former_christians': 'مسيحيون سابقون',
  'former_atheists': 'ملحدون سابقون',
  'former_hindus': 'هندوس سابقون',
  'former_buddhists': 'بوذيون سابقون',
  'former_jews': 'يهود سابقون',
  'born_muslims': 'مسلمون بالولادة'
};

const statusTranslations: { [key: string]: string } = {
  'initial_contact': 'أول اتصال',
  'interested': 'مهتم',
  'learning': 'يتعلم',
  'convinced': 'مقتنع',
  'converted': 'اهتدى',
  'inactive': 'غير نشط'
};

// Colors for charts
const COLORS = [
  '#2563eb', '#0891b2', '#0d9488', '#059669', '#16a34a', 
  '#65a30d', '#ca8a04', '#d97706', '#ea580c', '#dc2626'
];

const STATUS_COLORS = {
  'initial_contact': '#6b7280',
  'interested': '#2563eb',
  'learning': '#ca8a04',
  'convinced': '#7c3aed',
  'converted': '#16a34a',
  'inactive': '#dc2626'
};

const formatNumber = (num: number) => {
  return new Intl.NumberFormat('ar-EG').format(num);
};

const formatPercent = (value: number) => {
  return `${(value * 100).toFixed(1)}%`;
};

const DawahAnalyticsPage = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [timeframeFilter, setTimeframeFilter] = useState('all');
  const [topicSortBy, setTopicSortBy] = useState('conversion_effectiveness');
  
  // Analytics data
  const [conversionStats, setConversionStats] = useState<ConversionStats | null>(null);
  const [regionalStats, setRegionalStats] = useState<RegionalStats | null>(null);
  const [topicInsights, setTopicInsights] = useState<TopicInsights | null>(null);
  const [demographicInsights, setDemographicInsights] = useState<DemographicInsights | null>(null);
  const [dawahReport, setDawahReport] = useState<DawahReport | null>(null);
  
  // Fetch all analytics data on component mount
  useEffect(() => {
    Promise.all([
      fetchConversionStats(),
      fetchRegionalStats(),
      fetchTopicInsights(),
      fetchDemographicInsights(),
      fetchDawahReport()
    ])
      .then(() => setIsLoading(false))
      .catch(error => {
        console.error('Error fetching analytics data:', error);
        setIsLoading(false);
        toast({
          title: 'خطأ في جلب البيانات',
          description: 'حدث خطأ أثناء محاولة جلب بيانات التحليلات',
          variant: 'destructive',
        });
      });
  }, []);
  
  // Fetch data when filters change
  useEffect(() => {
    fetchRegionalStats();
  }, [timeframeFilter]);
  
  useEffect(() => {
    fetchTopicInsights();
  }, [topicSortBy]);
  
  // Fetch conversion stats data
  const fetchConversionStats = async () => {
    try {
      const response = await apiRequest('GET', '/api/dawah/analytics/conversion');
      const data = await response.json();
      setConversionStats(data);
    } catch (error) {
      console.error('Error fetching conversion stats:', error);
      toast({
        title: 'خطأ في جلب إحصائيات التحويل',
        description: 'حدث خطأ أثناء محاولة جلب إحصائيات التحويل',
        variant: 'destructive',
      });
    }
  };
  
  // Fetch regional stats data
  const fetchRegionalStats = async () => {
    try {
      const response = await apiRequest('GET', `/api/dawah/analytics/regional?timeframe=${timeframeFilter}`);
      const data = await response.json();
      setRegionalStats(data);
    } catch (error) {
      console.error('Error fetching regional stats:', error);
      toast({
        title: 'خطأ في جلب الإحصائيات الإقليمية',
        description: 'حدث خطأ أثناء محاولة جلب الإحصائيات الإقليمية',
        variant: 'destructive',
      });
    }
  };
  
  // Fetch topic insights data
  const fetchTopicInsights = async () => {
    try {
      const response = await apiRequest('GET', `/api/dawah/analytics/topics?sortBy=${topicSortBy}`);
      const data = await response.json();
      setTopicInsights(data);
    } catch (error) {
      console.error('Error fetching topic insights:', error);
      toast({
        title: 'خطأ في جلب تحليلات المواضيع',
        description: 'حدث خطأ أثناء محاولة جلب تحليلات المواضيع',
        variant: 'destructive',
      });
    }
  };
  
  // Fetch demographic insights data
  const fetchDemographicInsights = async () => {
    try {
      const response = await apiRequest('GET', '/api/dawah/analytics/demographics');
      const data = await response.json();
      setDemographicInsights(data);
    } catch (error) {
      console.error('Error fetching demographic insights:', error);
      toast({
        title: 'خطأ في جلب الرؤى الديموغرافية',
        description: 'حدث خطأ أثناء محاولة جلب الرؤى الديموغرافية',
        variant: 'destructive',
      });
    }
  };
  
  // Fetch comprehensive dawah report
  const fetchDawahReport = async () => {
    try {
      const response = await apiRequest('GET', '/api/dawah/analytics/report');
      const data = await response.json();
      setDawahReport(data);
    } catch (error) {
      console.error('Error fetching dawah report:', error);
      toast({
        title: 'خطأ في جلب تقرير الدعوة',
        description: 'حدث خطأ أثناء محاولة جلب تقرير الدعوة',
        variant: 'destructive',
      });
    }
  };
  
  // Convert conversion funnel data to recharts format
  const getFunnelChartData = () => {
    if (!conversionStats) return [];
    
    const { conversionFunnel } = conversionStats;
    return Object.entries(conversionFunnel).map(([status, count]) => ({
      name: statusTranslations[status] || status,
      value: count,
      color: STATUS_COLORS[status as keyof typeof STATUS_COLORS] || '#888'
    }));
  };
  
  // Get pie chart data for demographics
  const getDemographicChartData = () => {
    if (!demographicInsights?.demographics) return [];
    
    return demographicInsights.demographics.map(demo => ({
      name: demographicTranslations[demo.demographic] || demo.demographic,
      value: demo.count,
      conversionRate: demo.conversion_rate
    }));
  };
  
  // Format topics for display
  const formatTopicName = (topic: string) => {
    return topic.replace(/_/g, ' ');
  };
  
  // Format timeline data for display
  const formatTimelineData = (timeline?: Array<{ date: string; interactions: number; conversions: number }>) => {
    if (!timeline) return [];
    
    return timeline.map(item => ({
      ...item,
      date: new Date(item.date).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' })
    }));
  };
  
  // Generate PDF report - placeholder function
  const generatePDFReport = () => {
    toast({
      title: 'جاري إنشاء التقرير',
      description: 'سيتم تنزيل التقرير بتنسيق PDF قريبًا',
    });
    
    // In a real implementation, this would generate a PDF report
    setTimeout(() => {
      toast({
        title: 'تم إنشاء التقرير',
        description: 'تم تنزيل تقرير إحصائيات الدعوة بنجاح',
      });
    }, 2000);
  };
  
  // Generate Excel report - placeholder function
  const generateExcelReport = () => {
    toast({
      title: 'جاري إنشاء التقرير',
      description: 'سيتم تنزيل البيانات بتنسيق Excel قريبًا',
    });
    
    // In a real implementation, this would generate an Excel report
    setTimeout(() => {
      toast({
        title: 'تم إنشاء التقرير',
        description: 'تم تنزيل بيانات إحصائيات الدعوة بنجاح',
      });
    }, 2000);
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto py-8 text-center">
        <h1 className="text-3xl font-bold mb-6">تحليلات الدعوة</h1>
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary"></div>
        </div>
        <p className="mt-4">جاري تحميل البيانات...</p>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8 rtl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">تحليلات الدعوة الإسلامية</h1>
        
        <div className="flex space-x-4">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={generatePDFReport}
          >
            <FileText size={18} />
            <span>تقرير PDF</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={generateExcelReport}
          >
            <Download size={18} />
            <span>تصدير Excel</span>
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 mb-8">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="conversion">التحويل</TabsTrigger>
          <TabsTrigger value="regions">المناطق</TabsTrigger>
          <TabsTrigger value="topics">المواضيع</TabsTrigger>
          <TabsTrigger value="demographics">التركيبة السكانية</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview">
          {dawahReport && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      إجمالي التفاعلات
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">
                      {formatNumber(dawahReport.summary.total_interactions)}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      عبر {dawahReport.summary.active_regions} منطقة نشطة
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      إجمالي المهتدين
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">
                      {formatNumber(dawahReport.summary.total_conversions)}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      نسبة التحويل: {formatPercent(dawahReport.summary.overall_conversion_rate)}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      أكثر المواضيع فعالية
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xl font-bold">
                      {formatTopicName(dawahReport.summary.most_effective_topic)}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      في منطقة {regionTranslations[dawahReport.summary.most_effective_region] || dawahReport.summary.most_effective_region}
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle>قمع التحويل</CardTitle>
                    <CardDescription>
                      تتبع تقدم المهتمين عبر مراحل رحلة الهداية
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart
                        data={getFunnelChartData()}
                        layout="vertical"
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis 
                          dataKey="name" 
                          type="category" 
                          width={100} 
                        />
                        <Tooltip 
                          formatter={(value) => [formatNumber(value as number), 'الأشخاص']}
                          labelFormatter={(label) => `${label}`}
                        />
                        <Bar dataKey="value">
                          {getFunnelChartData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>توصيات لتحسين الدعوة</CardTitle>
                    <CardDescription>
                      اقتراحات لزيادة فعالية جهود الدعوة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {dawahReport.recommendations.map((recommendation, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle className="text-green-600 mt-1 flex-shrink-0" size={18} />
                          <span>{recommendation}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>أفضل المناطق</CardTitle>
                    <CardDescription>
                      المناطق الأكثر نجاحاً في الدعوة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {dawahReport.top_regions.map((region, i) => (
                        <div key={i}>
                          <div className="flex justify-between mb-1">
                            <span>{regionTranslations[region.region] || region.region}</span>
                            <span className="text-green-600">{formatNumber(region.conversions)}</span>
                          </div>
                          <Progress 
                            value={region.conversion_rate * 100} 
                            className="h-2" 
                          />
                          <p className="text-xs text-right mt-1">
                            {formatPercent(region.conversion_rate)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>أفضل المواضيع</CardTitle>
                    <CardDescription>
                      المواضيع الأكثر فعالية في الدعوة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {dawahReport.top_topics.slice(0, 5).map((topic, i) => (
                        <div key={i}>
                          <div className="flex justify-between mb-1">
                            <span>{formatTopicName(topic.topic)}</span>
                            <span className="text-blue-600">{formatNumber(topic.conversions)}</span>
                          </div>
                          <Progress 
                            value={topic.effectiveness * 100} 
                            className="h-2" 
                          />
                          <p className="text-xs text-right mt-1">
                            {formatPercent(topic.effectiveness)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>أفضل التركيبات السكانية</CardTitle>
                    <CardDescription>
                      الفئات الأكثر استجابة للدعوة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {dawahReport.top_demographics.map((demo, i) => (
                        <div key={i}>
                          <div className="flex justify-between mb-1">
                            <span>{demographicTranslations[demo.demographic] || demo.demographic}</span>
                            <span className="text-purple-600">{formatNumber(demo.count)}</span>
                          </div>
                          <Progress 
                            value={demo.conversion_rate * 100} 
                            className="h-2" 
                          />
                          <p className="text-xs text-right mt-1">
                            {formatPercent(demo.conversion_rate)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>
        
        {/* Conversion Tab */}
        <TabsContent value="conversion">
          {conversionStats && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      إجمالي جهات الاتصال
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">
                      {formatNumber(conversionStats.totalContacts)}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      نسبة التحويل
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">
                      {formatPercent(conversionStats.conversionRate)}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      المهتدون
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">
                      {formatNumber(conversionStats.conversionFunnel.converted)}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      نسبة المقتنعين إلى المهتدين
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600">
                      {conversionStats.conversionFunnel.convinced > 0
                        ? formatPercent(conversionStats.conversionFunnel.converted / conversionStats.conversionFunnel.convinced)
                        : '0%'
                      }
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle>قمع التحويل</CardTitle>
                    <CardDescription>
                      تتبع تقدم المهتمين عبر مراحل رحلة الهداية
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart
                        data={getFunnelChartData()}
                        layout="vertical"
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis 
                          dataKey="name" 
                          type="category" 
                          width={100} 
                        />
                        <Tooltip 
                          formatter={(value) => [formatNumber(value as number), 'الأشخاص']}
                          labelFormatter={(label) => `${label}`}
                        />
                        <Bar dataKey="value">
                          {getFunnelChartData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>أكثر المواضيع فعالية</CardTitle>
                    <CardDescription>
                      المواضيع التي أدت إلى أعلى معدلات التحويل
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart
                        data={conversionStats.mostEffectiveTopics}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="topic" 
                          tick={{ fontSize: 12 }}
                          tickFormatter={formatTopicName}
                        />
                        <YAxis yAxisId="left" orientation="left" />
                        <YAxis 
                          yAxisId="right" 
                          orientation="right" 
                          tickFormatter={(value) => formatPercent(value)}
                        />
                        <Tooltip 
                          formatter={(value, name) => {
                            if (name === 'effectiveness') {
                              return [formatPercent(value as number), 'الفعالية'];
                            }
                            return [formatNumber(value as number), 'التحويلات'];
                          }}
                          labelFormatter={(label) => formatTopicName(label)}
                        />
                        <Legend />
                        <Bar 
                          yAxisId="left" 
                          dataKey="conversions" 
                          name="التحويلات" 
                          fill="#2563eb" 
                        />
                        <Bar 
                          yAxisId="right" 
                          dataKey="effectiveness" 
                          name="الفعالية" 
                          fill="#16a34a" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>تحليل قمع التحويل</CardTitle>
                  <CardDescription>
                    المعدلات والنسب بين مراحل رحلة الهداية المختلفة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div>
                      <h3 className="font-semibold mb-2">أول اتصال → مهتم</h3>
                      <div className="text-2xl font-bold text-blue-600 mb-1">
                        {conversionStats.conversionFunnel.initial_contact > 0
                          ? formatPercent(conversionStats.conversionFunnel.interested / conversionStats.conversionFunnel.initial_contact)
                          : '0%'
                        }
                      </div>
                      <Progress 
                        value={conversionStats.conversionFunnel.initial_contact > 0
                          ? (conversionStats.conversionFunnel.interested / conversionStats.conversionFunnel.initial_contact) * 100
                          : 0
                        } 
                        className="h-2 mb-1" 
                      />
                      <p className="text-sm text-muted-foreground">
                        {formatNumber(conversionStats.conversionFunnel.interested)} من أصل {formatNumber(conversionStats.conversionFunnel.initial_contact)}
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold mb-2">مهتم → يتعلم</h3>
                      <div className="text-2xl font-bold text-yellow-600 mb-1">
                        {conversionStats.conversionFunnel.interested > 0
                          ? formatPercent(conversionStats.conversionFunnel.learning / conversionStats.conversionFunnel.interested)
                          : '0%'
                        }
                      </div>
                      <Progress 
                        value={conversionStats.conversionFunnel.interested > 0
                          ? (conversionStats.conversionFunnel.learning / conversionStats.conversionFunnel.interested) * 100
                          : 0
                        } 
                        className="h-2 mb-1" 
                      />
                      <p className="text-sm text-muted-foreground">
                        {formatNumber(conversionStats.conversionFunnel.learning)} من أصل {formatNumber(conversionStats.conversionFunnel.interested)}
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold mb-2">يتعلم → مقتنع</h3>
                      <div className="text-2xl font-bold text-purple-600 mb-1">
                        {conversionStats.conversionFunnel.learning > 0
                          ? formatPercent(conversionStats.conversionFunnel.convinced / conversionStats.conversionFunnel.learning)
                          : '0%'
                        }
                      </div>
                      <Progress 
                        value={conversionStats.conversionFunnel.learning > 0
                          ? (conversionStats.conversionFunnel.convinced / conversionStats.conversionFunnel.learning) * 100
                          : 0
                        } 
                        className="h-2 mb-1" 
                      />
                      <p className="text-sm text-muted-foreground">
                        {formatNumber(conversionStats.conversionFunnel.convinced)} من أصل {formatNumber(conversionStats.conversionFunnel.learning)}
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold mb-2">مقتنع → اهتدى</h3>
                      <div className="text-2xl font-bold text-green-600 mb-1">
                        {conversionStats.conversionFunnel.convinced > 0
                          ? formatPercent(conversionStats.conversionFunnel.converted / conversionStats.conversionFunnel.convinced)
                          : '0%'
                        }
                      </div>
                      <Progress 
                        value={conversionStats.conversionFunnel.convinced > 0
                          ? (conversionStats.conversionFunnel.converted / conversionStats.conversionFunnel.convinced) * 100
                          : 0
                        } 
                        className="h-2 mb-1" 
                      />
                      <p className="text-sm text-muted-foreground">
                        {formatNumber(conversionStats.conversionFunnel.converted)} من أصل {formatNumber(conversionStats.conversionFunnel.convinced)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
        
        {/* Regions Tab */}
        <TabsContent value="regions">
          <div className="flex justify-end mb-4">
            <Select value={timeframeFilter} onValueChange={setTimeframeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="الفترة الزمنية" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الوقت</SelectItem>
                <SelectItem value="week">آخر أسبوع</SelectItem>
                <SelectItem value="month">آخر شهر</SelectItem>
                <SelectItem value="quarter">آخر 3 أشهر</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {regionalStats && regionalStats.regions.length > 0 ? (
            <div className="grid grid-cols-1 gap-6">
              {regionalStats.regions.map((region, regionIndex) => (
                <Card key={regionIndex}>
                  <CardHeader>
                    <CardTitle>
                      {regionTranslations[region.region] || region.region}
                    </CardTitle>
                    <CardDescription>
                      إحصائيات وتحليلات منطقة {regionTranslations[region.region] || region.region}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <div className="grid grid-cols-2 gap-4 mb-6">
                          <div>
                            <h3 className="text-sm font-medium text-muted-foreground mb-1">
                              التفاعلات
                            </h3>
                            <div className="text-2xl font-bold">
                              {formatNumber(region.stats.interactions)}
                            </div>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium text-muted-foreground mb-1">
                              الأسئلة المجاب عنها
                            </h3>
                            <div className="text-2xl font-bold">
                              {formatNumber(region.stats.questions_answered)}
                            </div>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium text-muted-foreground mb-1">
                              المهتمين المحتملين
                            </h3>
                            <div className="text-2xl font-bold">
                              {formatNumber(region.stats.potential_converts)}
                            </div>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium text-muted-foreground mb-1">
                              المهتدين
                            </h3>
                            <div className="text-2xl font-bold text-green-600">
                              {formatNumber(region.stats.conversions)}
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="font-semibold mb-2">نسبة التحويل</h3>
                          <div className="text-3xl font-bold text-green-600 mb-1">
                            {formatPercent(region.stats.conversion_rate)}
                          </div>
                          <Progress 
                            value={region.stats.conversion_rate * 100} 
                            className="h-2 mb-1" 
                          />
                        </div>
                        
                        <Separator className="my-6" />
                        
                        <div>
                          <h3 className="font-semibold mb-3">أهم المواضيع</h3>
                          <div className="space-y-2">
                            {region.stats.top_topics.slice(0, 5).map((topic, topicIndex) => (
                              <div key={topicIndex} className="flex justify-between items-center">
                                <span>{formatTopicName(topic.topic)}</span>
                                <Badge variant="outline">{formatNumber(topic.count)}</Badge>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-4">التفاعلات والتحويلات عبر الزمن</h3>
                        
                        {region.timeline && region.timeline.length > 0 ? (
                          <ResponsiveContainer width="100%" height={300}>
                            <LineChart
                              data={formatTimelineData(region.timeline)}
                              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis />
                              <Tooltip 
                                formatter={(value) => [formatNumber(value as number), '']}
                              />
                              <Legend />
                              <Line 
                                type="monotone" 
                                dataKey="interactions" 
                                name="التفاعلات" 
                                stroke="#2563eb" 
                                strokeWidth={2} 
                                dot={{ r: 4 }}
                                activeDot={{ r: 6 }}
                              />
                              <Line 
                                type="monotone" 
                                dataKey="conversions" 
                                name="التحويلات" 
                                stroke="#16a34a" 
                                strokeWidth={2}
                                dot={{ r: 4 }}
                                activeDot={{ r: 6 }}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        ) : (
                          <div className="flex items-center justify-center h-[300px] bg-gray-50 rounded-lg">
                            <p className="text-muted-foreground">لا توجد بيانات متاحة للجدول الزمني</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <BarChart2 className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-semibold">لا توجد بيانات إقليمية</h3>
              <p className="mt-1 text-gray-500">لم يتم العثور على بيانات للمناطق في الفترة الزمنية المحددة</p>
            </div>
          )}
        </TabsContent>
        
        {/* Topics Tab */}
        <TabsContent value="topics">
          <div className="flex justify-end mb-4">
            <Select value={topicSortBy} onValueChange={setTopicSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="ترتيب حسب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conversion_effectiveness">فعالية التحويل</SelectItem>
                <SelectItem value="total_uses">إجمالي الاستخدام</SelectItem>
                <SelectItem value="engagement_time">وقت المشاركة</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {topicInsights && topicInsights.topics.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle>فعالية المواضيع</CardTitle>
                    <CardDescription>
                      مقارنة بين المواضيع المختلفة من حيث الفعالية
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart
                        data={topicInsights.topics.slice(0, 10)}
                        layout="vertical"
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis 
                          dataKey="topic" 
                          type="category" 
                          width={150}
                          tickFormatter={formatTopicName}
                        />
                        <Tooltip 
                          formatter={(value) => [formatPercent(value as number), 'فعالية التحويل']}
                          labelFormatter={(label) => formatTopicName(label)}
                        />
                        <Bar 
                          dataKey="conversion_effectiveness" 
                          name="فعالية التحويل" 
                          fill="#16a34a"
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>الاستخدام والتحويلات</CardTitle>
                    <CardDescription>
                      عدد مرات استخدام الموضوع وتأثيره على التحويلات
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart
                        data={topicInsights.topics.slice(0, 10)}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="topic" 
                          tickFormatter={formatTopicName}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis />
                        <Tooltip 
                          formatter={(value) => [formatNumber(value as number), '']}
                          labelFormatter={(label) => formatTopicName(label)}
                        />
                        <Legend />
                        <Bar 
                          dataKey="total_uses" 
                          name="عدد الاستخدامات"
                          fill="#2563eb" 
                        />
                        <Bar 
                          dataKey="conversions_influenced" 
                          name="التحويلات المتأثرة"
                          fill="#16a34a" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>تفاصيل المواضيع</CardTitle>
                    <CardDescription>
                      مقاييس مفصلة لكل موضوع دعوي
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="py-3 px-4 text-right">الموضوع</th>
                            <th className="py-3 px-4 text-right">الاستخدامات</th>
                            <th className="py-3 px-4 text-right">الأسئلة المولدة</th>
                            <th className="py-3 px-4 text-right">الاستجابات الإيجابية</th>
                            <th className="py-3 px-4 text-right">التحويلات المتأثرة</th>
                            <th className="py-3 px-4 text-right">فعالية التحويل</th>
                            <th className="py-3 px-4 text-right">متوسط وقت المشاركة (أيام)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {topicInsights.topics.map((topic, i) => (
                            <tr key={i} className="border-b">
                              <td className="py-3 px-4 font-medium">{formatTopicName(topic.topic)}</td>
                              <td className="py-3 px-4">{formatNumber(topic.total_uses)}</td>
                              <td className="py-3 px-4">{formatNumber(topic.questions_generated)}</td>
                              <td className="py-3 px-4">{formatNumber(topic.positive_responses)}</td>
                              <td className="py-3 px-4">{formatNumber(topic.conversions_influenced)}</td>
                              <td className="py-3 px-4">
                                <Badge className="bg-green-100 text-green-800">
                                  {formatPercent(topic.conversion_effectiveness)}
                                </Badge>
                              </td>
                              <td className="py-3 px-4">{topic.average_engagement_time.toFixed(1)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <Activity className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-semibold">لا توجد بيانات المواضيع</h3>
              <p className="mt-1 text-gray-500">لم يتم العثور على بيانات للمواضيع</p>
            </div>
          )}
        </TabsContent>
        
        {/* Demographics Tab */}
        <TabsContent value="demographics">
          {demographicInsights && demographicInsights.demographics.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      الفئة الأكثر استجابة
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xl font-bold text-purple-600">
                      {demographicTranslations[demographicInsights.most_responsive] || demographicInsights.most_responsive}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      أعلى معدل تحويل بين جميع الفئات الديموغرافية
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      أسرع تحويل
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xl font-bold text-blue-600">
                      {demographicTranslations[demographicInsights.fastest_conversion] || demographicInsights.fastest_conversion}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      أقصر متوسط وقت للرحلة من الاتصال الأول إلى الهداية
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      إجمالي الفئات
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xl font-bold">
                      {formatNumber(demographicInsights.demographics.length)}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      عدد الفئات الديموغرافية المتتبعة
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>توزيع الفئات الديموغرافية</CardTitle>
                    <CardDescription>
                      عدد جهات الاتصال في كل فئة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={getDemographicChartData()}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {getDemographicChartData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value) => [formatNumber(value as number), 'عدد الأشخاص']}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>معدلات التحويل حسب الفئة</CardTitle>
                    <CardDescription>
                      نسبة التحويل لكل فئة ديموغرافية
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart
                        data={demographicInsights.demographics}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="demographic" 
                          tickFormatter={(value) => demographicTranslations[value] || value}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis 
                          tickFormatter={(value) => formatPercent(value)}
                        />
                        <Tooltip 
                          formatter={(value) => [formatPercent(value as number), 'معدل التحويل']}
                          labelFormatter={(label) => demographicTranslations[label] || label}
                        />
                        <Bar 
                          dataKey="conversion_rate" 
                          name="معدل التحويل" 
                          fill="#7c3aed"
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>تفاصيل الفئات الديموغرافية</CardTitle>
                  <CardDescription>
                    بيانات مفصلة عن كل فئة ديموغرافية
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="py-3 px-4 text-right">الفئة</th>
                          <th className="py-3 px-4 text-right">عدد الأشخاص</th>
                          <th className="py-3 px-4 text-right">معدل التحويل</th>
                          <th className="py-3 px-4 text-right">متوسط طول الرحلة (أيام)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {demographicInsights.demographics.map((demo, i) => (
                          <tr key={i} className="border-b">
                            <td className="py-3 px-4 font-medium">
                              {demographicTranslations[demo.demographic] || demo.demographic}
                            </td>
                            <td className="py-3 px-4">{formatNumber(demo.count)}</td>
                            <td className="py-3 px-4">
                              <Badge className="bg-purple-100 text-purple-800">
                                {formatPercent(demo.conversion_rate)}
                              </Badge>
                            </td>
                            <td className="py-3 px-4">{demo.average_journey_length.toFixed(1)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8">
              <Users className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-semibold">لا توجد بيانات ديموغرافية</h3>
              <p className="mt-1 text-gray-500">لم يتم العثور على بيانات للفئات الديموغرافية</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DawahAnalyticsPage;