
import React from 'react';
import { Layout } from '../components/layout';

export default function PrivacyPolicy() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">سياسة الخصوصية وحقوق الملكية</h1>
        
        <div className="space-y-6 text-right">
          <section>
            <h2 className="text-2xl font-semibold mb-4">حقوق الملكية</h2>
            <p>جميع الحقوق محفوظة © 2024</p>
            <p>لا يجوز نسخ أو استخدام أي جزء من هذا التطبيق دون إذن كتابي مسبق.</p>
          </section>
          
          <section>
            <h2 className="text-2xl font-semibold mb-4">سياسة الخصوصية</h2>
            <p>نحن نحترم خصوصية مستخدمينا ونلتزم بحماية بياناتهم الشخصية.</p>
            <ul className="list-disc list-inside space-y-2 mr-4">
              <li>نحن نجمع فقط البيانات الضرورية لتشغيل التطبيق</li>
              <li>لا نشارك بياناتك مع أي طرف ثالث</li>
              <li>تُخزن جميع البيانات بشكل آمن ومشفر</li>
            </ul>
          </section>
          
          <section>
            <h2 className="text-2xl font-semibold mb-4">حقوق المستخدم</h2>
            <p>للمستخدم الحق في:</p>
            <ul className="list-disc list-inside space-y-2 mr-4">
              <li>الوصول إلى بياناته الشخصية</li>
              <li>طلب حذف بياناته</li>
              <li>تحديث معلوماته الشخصية</li>
            </ul>
          </section>
        </div>
      </div>
    </Layout>
  );
}
