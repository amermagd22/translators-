import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface UseSpeechRecognitionOptions {
  onResult?: (transcript: string) => void;
  onEnd?: () => void;
  onError?: (error: Error) => void;
  language?: string;
  continuous?: boolean;
}

interface UseSpeechSynthesisOptions {
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: Error) => void;
  language?: string;
  rate?: number;
  pitch?: number;
  volume?: number;
}

// Speech recognition hook
export function useSpeechRecognition(options?: UseSpeechRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const recognitionRef = useRef<any>(null);
  const { toast } = useToast();
  
  // Check browser support
  const isSpeechRecognitionSupported = 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
  
  useEffect(() => {
    // Clean up on unmount
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);
  
  const startListening = () => {
    if (!isSpeechRecognitionSupported) {
      const error = new Error("Speech recognition not supported in this browser");
      options?.onError?.(error);
      toast({
        title: "غير مدعوم",
        description: "ميزة التعرف على الصوت غير مدعومة في هذا المتصفح",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      // Configure recognition
      recognitionRef.current.continuous = options?.continuous ?? false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = options?.language || 'ar-SA';
      
      // Set event handlers
      recognitionRef.current.onresult = (event: any) => {
        const current = event.resultIndex;
        const result = event.results[current];
        const transcriptValue = result[0].transcript;
        
        setTranscript(transcriptValue);
        options?.onResult?.(transcriptValue);
      };
      
      recognitionRef.current.onerror = (event: any) => {
        const error = new Error(`Speech recognition error: ${event.error}`);
        options?.onError?.(error);
        toast({
          title: "خطأ في التعرف على الصوت",
          description: event.error,
          variant: "destructive"
        });
        setIsListening(false);
      };
      
      recognitionRef.current.onend = () => {
        options?.onEnd?.();
        setIsListening(false);
      };
      
      // Start recognition
      recognitionRef.current.start();
      setIsListening(true);
    } catch (error) {
      const err = error as Error;
      options?.onError?.(err);
      toast({
        title: "فشل بدء التعرف على الصوت",
        description: err.message,
        variant: "destructive"
      });
    }
  };
  
  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };
  
  return {
    isListening,
    transcript,
    startListening,
    stopListening,
    isSupported: isSpeechRecognitionSupported
  };
}

// Speech synthesis hook
export function useSpeechSynthesis(options?: UseSpeechSynthesisOptions) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const { toast } = useToast();
  
  // Check browser support
  const isSpeechSynthesisSupported = 'speechSynthesis' in window;
  
  useEffect(() => {
    if (isSpeechSynthesisSupported) {
      synthRef.current = window.speechSynthesis;
    }
    
    // Clean up on unmount
    return () => {
      if (synthRef.current && isSpeaking) {
        synthRef.current.cancel();
      }
    };
  }, [isSpeechSynthesisSupported, isSpeaking]);
  
  const speak = (text: string, overrideOptions?: Partial<UseSpeechSynthesisOptions>) => {
    if (!isSpeechSynthesisSupported) {
      const error = new Error("Speech synthesis not supported in this browser");
      options?.onError?.(error);
      toast({
        title: "غير مدعوم",
        description: "ميزة تحويل النص إلى صوت غير مدعومة في هذا المتصفح",
        variant: "destructive"
      });
      return;
    }
    
    if (!text.trim()) {
      toast({
        title: "خطأ",
        description: "لا يوجد نص للقراءة",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Cancel any ongoing speech
      if (synthRef.current) {
        synthRef.current.cancel();
      }
      
      // Create utterance
      utteranceRef.current = new SpeechSynthesisUtterance(text);
      
      // Set language and voice options
      const language = overrideOptions?.language || options?.language || 'ar-SA';
      utteranceRef.current.lang = language;
      
      // Get voices for the language
      const voices = synthRef.current?.getVoices().filter(voice => voice.lang.startsWith(language.split('-')[0]));
      if (voices && voices.length > 0) {
        utteranceRef.current.voice = voices[0];
      }
      
      // Set other options
      utteranceRef.current.rate = overrideOptions?.rate || options?.rate || 1;
      utteranceRef.current.pitch = overrideOptions?.pitch || options?.pitch || 1;
      utteranceRef.current.volume = overrideOptions?.volume || options?.volume || 1;
      
      // Set event handlers
      utteranceRef.current.onstart = () => {
        setIsSpeaking(true);
        options?.onStart?.();
      };
      
      utteranceRef.current.onend = () => {
        setIsSpeaking(false);
        options?.onEnd?.();
      };
      
      utteranceRef.current.onerror = (event) => {
        const error = new Error(`Speech synthesis error: ${event.error}`);
        options?.onError?.(error);
        toast({
          title: "خطأ في تحويل النص إلى صوت",
          description: event.error,
          variant: "destructive"
        });
        setIsSpeaking(false);
      };
      
      // Start speaking
      synthRef.current?.speak(utteranceRef.current);
    } catch (error) {
      const err = error as Error;
      options?.onError?.(err);
      toast({
        title: "فشل تحويل النص إلى صوت",
        description: err.message,
        variant: "destructive"
      });
    }
  };
  
  const stop = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  };
  
  const pause = () => {
    if (synthRef.current) {
      synthRef.current.pause();
    }
  };
  
  const resume = () => {
    if (synthRef.current) {
      synthRef.current.resume();
    }
  };
  
  return {
    isSpeaking,
    speak,
    stop,
    pause,
    resume,
    isSupported: isSpeechSynthesisSupported
  };
}
