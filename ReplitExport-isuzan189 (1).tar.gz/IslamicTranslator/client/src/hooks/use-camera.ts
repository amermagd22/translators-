import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface UseCameraOptions {
  onSuccess?: (imageSrc: string) => void;
  onError?: (error: Error) => void;
}

export function useCamera(options?: UseCameraOptions) {
  const [isActive, setIsActive] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();
  
  // Check if camera is supported
  const isCameraSupported = 'mediaDevices' in navigator && 'getUserMedia' in navigator.mediaDevices;
  
  // Clean up function to stop the camera stream
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    setIsActive(false);
    setPreviewUrl(null);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);
  
  // Start the camera
  const startCamera = async () => {
    if (!isCameraSupported) {
      const cameraError = new Error("Camera not supported in this browser or device");
      setError(cameraError);
      options?.onError?.(cameraError);
      toast({
        title: "غير مدعوم",
        description: "كاميرا غير مدعومة في هذا المتصفح أو الجهاز",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Stop any existing stream
      stopCamera();
      
      // Request camera permissions
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Use back camera if available
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      // Store the stream reference
      streamRef.current = stream;
      
      // If videoRef is available, set the stream as source
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      setHasPermission(true);
      setIsActive(true);
      setError(null);
    } catch (err) {
      const cameraError = err as Error;
      setHasPermission(false);
      setError(cameraError);
      setIsActive(false);
      
      options?.onError?.(cameraError);
      toast({
        title: "خطأ في الوصول للكاميرا",
        description: cameraError.message,
        variant: "destructive"
      });
    }
  };
  
  // Capture a photo
  const capturePhoto = () => {
    if (!videoRef.current || !isActive) {
      toast({
        title: "خطأ",
        description: "الكاميرا غير نشطة",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsCapturing(true);
      
      // Create a canvas to capture the photo
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      if (!context) {
        throw new Error("Could not get canvas context");
      }
      
      // Set canvas dimensions to video dimensions
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      
      // Draw the video frame on the canvas
      context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      
      // Convert canvas to base64 image
      const imageData = canvas.toDataURL('image/jpeg');
      
      // Set preview and notify
      setPreviewUrl(imageData);
      options?.onSuccess?.(imageData);
      
      setIsCapturing(false);
      
      // Stop the camera after capturing
      stopCamera();
    } catch (err) {
      const captureError = err as Error;
      setError(captureError);
      setIsCapturing(false);
      
      options?.onError?.(captureError);
      toast({
        title: "فشل التقاط الصورة",
        description: captureError.message,
        variant: "destructive"
      });
    }
  };
  
  // Discard the photo and restart camera
  const discardPhoto = () => {
    setPreviewUrl(null);
    startCamera();
  };
  
  return {
    isActive,
    isCapturing,
    hasPermission,
    error,
    previewUrl,
    videoRef,
    startCamera,
    stopCamera,
    capturePhoto,
    discardPhoto,
    isSupported: isCameraSupported
  };
}
