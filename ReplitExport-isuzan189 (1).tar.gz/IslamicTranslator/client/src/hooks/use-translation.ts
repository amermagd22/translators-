import { useState } from "react";
import { 
  translateText, 
  speechToText, 
  textToSpeech, 
  imageToText,
  TranslationResponse,
  SpeechToTextResponse,
  TextToSpeechResponse,
  ImageToTextResponse
} from "@/lib/translation";
import { useToast } from "@/hooks/use-toast";

interface UseTranslationOptions {
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
}

export function useTranslation(options?: UseTranslationOptions) {
  const [isTranslating, setIsTranslating] = useState(false);
  const [isSpeechRecognizing, setIsSpeechRecognizing] = useState(false);
  const [isSpeechSynthesizing, setIsSpeechSynthesizing] = useState(false);
  const [isImageProcessing, setIsImageProcessing] = useState(false);
  const { toast } = useToast();
  
  const handleTranslateText = async (
    sourceText: string,
    sourceLanguage: string,
    targetLanguage: string
  ): Promise<TranslationResponse | null> => {
    if (!sourceText.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال نص للترجمة",
        variant: "destructive"
      });
      return null;
    }
    
    setIsTranslating(true);
    
    try {
      const response = await translateText(sourceText, sourceLanguage, targetLanguage);
      options?.onSuccess?.(response);
      return response;
    } catch (error) {
      const err = error as Error;
      toast({
        title: "فشل الترجمة",
        description: err.message,
        variant: "destructive"
      });
      options?.onError?.(err);
      return null;
    } finally {
      setIsTranslating(false);
    }
  };
  
  const handleSpeechToText = async (
    audioData: string,
    sourceLanguage: string
  ): Promise<SpeechToTextResponse | null> => {
    setIsSpeechRecognizing(true);
    
    try {
      const response = await speechToText(audioData, sourceLanguage);
      options?.onSuccess?.(response);
      return response;
    } catch (error) {
      const err = error as Error;
      toast({
        title: "فشل التعرف على الصوت",
        description: err.message,
        variant: "destructive"
      });
      options?.onError?.(err);
      return null;
    } finally {
      setIsSpeechRecognizing(false);
    }
  };
  
  const handleTextToSpeech = async (
    text: string,
    language: string,
    voiceGender?: string,
    voiceSpeed?: number
  ): Promise<TextToSpeechResponse | null> => {
    if (!text.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال نص للتحويل إلى صوت",
        variant: "destructive"
      });
      return null;
    }
    
    setIsSpeechSynthesizing(true);
    
    try {
      const response = await textToSpeech(text, language, voiceGender, voiceSpeed);
      options?.onSuccess?.(response);
      return response;
    } catch (error) {
      const err = error as Error;
      toast({
        title: "فشل تحويل النص إلى صوت",
        description: err.message,
        variant: "destructive"
      });
      options?.onError?.(err);
      return null;
    } finally {
      setIsSpeechSynthesizing(false);
    }
  };
  
  const handleImageToText = async (
    imageData: string,
    sourceLanguage: string,
    targetLanguage: string
  ): Promise<ImageToTextResponse | null> => {
    setIsImageProcessing(true);
    
    try {
      const response = await imageToText(imageData, sourceLanguage, targetLanguage);
      options?.onSuccess?.(response);
      return response;
    } catch (error) {
      const err = error as Error;
      toast({
        title: "فشل استخراج النص من الصورة",
        description: err.message,
        variant: "destructive"
      });
      options?.onError?.(err);
      return null;
    } finally {
      setIsImageProcessing(false);
    }
  };
  
  return {
    translateText: handleTranslateText,
    speechToText: handleSpeechToText,
    textToSpeech: handleTextToSpeech,
    imageToText: handleImageToText,
    isTranslating,
    isSpeechRecognizing,
    isSpeechSynthesizing,
    isImageProcessing
  };
}
