import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useState, useEffect, useContext, createContext } from "react";
import { apiRequest } from "./lib/queryClient";
import { useTranslation } from "react-i18next";

// Pages
import Home from "@/pages/home";
import Conversation from "@/pages/conversation";
import Camera from "@/pages/camera";
import Profile from "@/pages/profile";
import History from "@/pages/history";
import Settings from "@/pages/settings";
import AdminDashboard from "@/pages/admin/dashboard";
import NotFound from "@/pages/not-found";
import ContactsPage from "@/pages/contacts-page";
import DawahAnalyticsPage from "@/pages/dawah-analytics-page";
import IslamicLibraryPage from "@/pages/islamic-library-page";

interface User {
  id: number;
  username: string;
  isAdmin: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: async () => {},
  logout: async () => {},
});

function Router() {
  const { user } = useContext(AuthContext);
  
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/conversation" component={Conversation} />
      <Route path="/camera" component={Camera} />
      <Route path="/profile" component={Profile} />
      <Route path="/history" component={History} />
      <Route path="/settings" component={Settings} />
      <Route path="/contacts" component={ContactsPage} />
      <Route path="/dawah-analytics" component={DawahAnalyticsPage} />
      <Route path="/islamic-library" component={IslamicLibraryPage} />
      {user?.isAdmin && <Route path="/admin/dashboard" component={AdminDashboard} />}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { i18n } = useTranslation();
  
  // Check if the user is logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch("/api/user", {
          credentials: "include"
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
          
          // Load user settings if user is logged in
          const settingsResponse = await fetch("/api/settings", {
            credentials: "include"
          });
          
          if (settingsResponse.ok) {
            const settings = await settingsResponse.json();
            // Set language based on user's preferred language
            i18n.changeLanguage(settings.preferredSourceLanguage);
          }
        }
      } catch (error) {
        console.error("Auth check error:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuth();
  }, [i18n]);
  
  const login = async (username: string, password: string) => {
    try {
      const response = await apiRequest("POST", "/api/login", { username, password });
      const userData = await response.json();
      setUser(userData);
      
      // Load user settings after login
      const settingsResponse = await fetch("/api/settings", {
        credentials: "include"
      });
      
      if (settingsResponse.ok) {
        const settings = await settingsResponse.json();
        i18n.changeLanguage(settings.preferredSourceLanguage);
      }
    } catch (error) {
      console.error("Login error:", error);
      throw error;
    }
  };
  
  const logout = async () => {
    try {
      await apiRequest("POST", "/api/logout");
      setUser(null);
      // Set language back to default on logout
      i18n.changeLanguage("ar");
    } catch (error) {
      console.error("Logout error:", error);
      throw error;
    }
  };
  
  const authContextValue = {
    user,
    isLoading,
    login,
    logout
  };
  
  return (
    <QueryClientProvider client={queryClient}>
      <AuthContext.Provider value={authContextValue}>
        <Router />
        <Toaster />
      </AuthContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
