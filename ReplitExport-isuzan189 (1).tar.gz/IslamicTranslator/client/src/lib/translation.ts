import { apiRequest } from "./queryClient";

// Language interface
export interface Language {
  id: number;
  code: string;
  name: string;
  nativeName: string;
  direction: string;
  flagCode?: string;
}

// Translation interface
export interface Translation {
  id: number;
  userId?: number;
  sourceText: string;
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  translationType: "text" | "voice" | "image";
  createdAt: Date;
}

// Translation response interface
export interface TranslationResponse {
  translatedText: string;
}

// Speech recognition response
export interface SpeechToTextResponse {
  recognizedText: string;
}

// Text to speech response
export interface TextToSpeechResponse {
  audioData: string;
}

// Image to text response
export interface ImageToTextResponse {
  extractedText: string;
  translatedText: string;
}

// Translation functions
export async function translateText(
  sourceText: string,
  sourceLanguage: string,
  targetLanguage: string
): Promise<TranslationResponse> {
  try {
    const res = await apiRequest("POST", "/api/translate", {
      sourceText,
      sourceLanguage,
      targetLanguage
    });
    
    return await res.json();
  } catch (error) {
    console.error("Translation error:", error);
    throw new Error("Failed to translate text");
  }
}

// Speech to text function
export async function speechToText(
  audioData: string,
  sourceLanguage: string
): Promise<SpeechToTextResponse> {
  try {
    const res = await apiRequest("POST", "/api/speech-to-text", {
      audioData,
      sourceLanguage
    });
    
    return await res.json();
  } catch (error) {
    console.error("Speech recognition error:", error);
    throw new Error("Failed to recognize speech");
  }
}

// Text to speech function
export async function textToSpeech(
  text: string,
  language: string,
  voiceGender?: string,
  voiceSpeed?: number
): Promise<TextToSpeechResponse> {
  try {
    const res = await apiRequest("POST", "/api/text-to-speech", {
      text,
      language,
      voiceGender,
      voiceSpeed
    });
    
    return await res.json();
  } catch (error) {
    console.error("Text to speech error:", error);
    throw new Error("Failed to convert text to speech");
  }
}

// Image to text function
export async function imageToText(
  imageData: string,
  sourceLanguage: string,
  targetLanguage: string
): Promise<ImageToTextResponse> {
  try {
    const res = await apiRequest("POST", "/api/image-to-text", {
      imageData,
      sourceLanguage,
      targetLanguage
    });
    
    return await res.json();
  } catch (error) {
    console.error("Image to text error:", error);
    throw new Error("Failed to extract and translate text from image");
  }
}

// Fetch languages
export async function fetchLanguages(): Promise<Language[]> {
  try {
    const res = await fetch("/api/languages", { credentials: "include" });
    
    if (!res.ok) {
      throw new Error(`Failed to fetch languages: ${res.status}`);
    }
    
    return await res.json();
  } catch (error) {
    console.error("Fetch languages error:", error);
    throw error;
  }
}

// Fetch translation history
export async function fetchTranslationHistory(limit?: number): Promise<Translation[]> {
  try {
    const url = limit ? `/api/translations?limit=${limit}` : "/api/translations";
    const res = await fetch(url, { credentials: "include" });
    
    if (!res.ok) {
      if (res.status === 401) {
        return []; // Return empty array if unauthorized
      }
      throw new Error(`Failed to fetch translation history: ${res.status}`);
    }
    
    const translations = await res.json();
    return translations.map((t: any) => ({
      ...t,
      createdAt: new Date(t.createdAt)
    }));
  } catch (error) {
    console.error("Fetch translation history error:", error);
    throw error;
  }
}
