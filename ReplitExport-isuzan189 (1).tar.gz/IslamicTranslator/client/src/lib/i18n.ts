import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// Arabic translations
const arTranslations = {
  app: {
    title: "المترجم الذكي"
  },
  nav: {
    translate: "الترجمة",
    conversation: "المحادثة",
    voice: "صوت",
    camera: "كاميرا",
    profile: "حسابي"
  },
  translations: {
    recent: "آخر الترجمات",
    viewAll: "عرض الكل",
    error: "حدث خطأ أثناء تحميل الترجمات",
    empty: "لا توجد ترجمات سابقة",
    title: "سجل الترجمات"
  },
  features: {
    title: "ميزات إضافية",
    imageTranslation: {
      title: "ترجمة الصور",
      description: "التقط صورة للنص وترجمها فوراً"
    },
    conversation: {
      title: "المحادثة المباشرة",
      description: "ترجمة فورية للمحادثات بين لغتين"
    },
    documentTranslation: {
      title: "ترجمة المستندات",
      description: "ترجم مستندات PDF و Word بالكامل"
    },
    offlineTranslation: {
      title: "الترجمة بدون انترنت",
      description: "ترجم حتى بدون اتصال بالانترنت"
    }
  },
  actions: {
    copy: "نسخ",
    copySource: "نسخ المصدر",
    copyTranslation: "نسخ الترجمة",
    share: "مشاركة",
    speak: "قراءة",
    speakSource: "قراءة المصدر",
    speakTranslation: "قراءة الترجمة",
    delete: "حذف"
  },
  microphone: {
    title: "التعرف على الصوت",
    listening: "تحدث الآن... جارٍ الاستماع",
    processingAudio: "جاري معالجة الصوت...",
    preparingMicrophone: "جاري تجهيز الميكروفون...",
    cancel: "إلغاء",
    done: "تم"
  },
  camera: {
    title: "ترجمة الصور",
    modalTitle: "التقاط صورة للترجمة",
    capturedImage: "الصورة الملتقطة",
    notSupported: "كاميرا غير مدعومة في هذا المتصفح أو الجهاز",
    permissionDenied: "تم رفض إذن الوصول للكاميرا",
    requestPermission: "طلب الإذن",
    tapToActivate: "انقر لتفعيل الكاميرا",
    retake: "إعادة التقاط",
    use: "استخدام",
    discardPhoto: "التقاط صورة جديدة",
    extractedText: "النص المستخرج"
  },
  conversation: {
    title: "المحادثة المباشرة",
    currentSpeaker: "المتحدث الحالي",
    changeSpeaker: "تغيير المتحدث",
    clear: "مسح المحادثة",
    empty: "ابدأ محادثة جديدة بالضغط على زر الميكروفون",
    listening: "جارٍ الاستماع..."
  },
  history: {
    title: "سجل الترجمات",
    searchPlaceholder: "البحث في سجل الترجمات",
    allTranslations: "جميع الترجمات",
    loginRequired: "تسجيل الدخول مطلوب",
    loginRequiredDescription: "يرجى تسجيل الدخول لعرض سجل الترجمات الخاص بك"
  },
  settings: {
    title: "الإعدادات",
    description: "قم بتخصيص إعدادات التطبيق",
    languagePreferences: "تفضيلات اللغة",
    preferredSourceLanguage: "لغة المصدر المفضلة",
    preferredSourceLanguageDescription: "اللغة الافتراضية للنص المصدر",
    preferredTargetLanguage: "لغة الهدف المفضلة",
    preferredTargetLanguageDescription: "اللغة الافتراضية للترجمة",
    voiceSettings: "إعدادات الصوت",
    voiceGender: "جنس الصوت",
    voiceGenderDescription: "اختر جنس الصوت للنطق",
    female: "أنثى",
    male: "ذكر",
    voiceSpeed: "سرعة الصوت",
    voiceSpeedDescription: "ضبط سرعة نطق النص",
    contentFiltering: "تصفية المحتوى",
    filterLevel: "مستوى التصفية",
    filterLevelDescription: "ضبط شدة تصفية المحتوى غير المناسب",
    filterLevelMild: "خفيف",
    filterLevelModerate: "متوسط",
    filterLevelStrict: "صارم",
    selectFilterLevel: "اختر مستوى التصفية",
    appearance: "المظهر",
    theme: "السمة",
    themeDescription: "اختر سمة التطبيق",
    themeLight: "فاتح",
    themeDark: "داكن",
    themeSystem: "حسب النظام",
    selectTheme: "اختر السمة",
    selectLanguage: "اختر اللغة",
    saveSettings: "حفظ الإعدادات",
    saveSuccess: "تم الحفظ",
    settingsUpdated: "تم تحديث الإعدادات بنجاح",
    saveError: "خطأ في الحفظ",
    saving: "جاري الحفظ...",
    loginRequired: "تسجيل الدخول مطلوب",
    loginRequiredDescription: "يرجى تسجيل الدخول لتخصيص الإعدادات"
  },
  auth: {
    title: "تسجيل الدخول",
    subtitle: "قم بتسجيل الدخول أو إنشاء حساب جديد",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    username: "اسم المستخدم",
    usernamePlaceholder: "أدخل اسم المستخدم",
    password: "كلمة المرور",
    passwordPlaceholder: "أدخل كلمة المرور",
    confirmPassword: "تأكيد كلمة المرور",
    confirmPasswordPlaceholder: "أعد إدخال كلمة المرور",
    logout: "تسجيل الخروج",
    loginSuccess: "تم تسجيل الدخول بنجاح",
    welcomeBack: "مرحباً بعودتك، {{username}}",
    loginError: "خطأ في تسجيل الدخول",
    registerSuccess: "تم إنشاء الحساب بنجاح",
    accountCreated: "تم إنشاء حسابك بنجاح",
    registerError: "خطأ في إنشاء الحساب",
    logoutSuccess: "تم تسجيل الخروج بنجاح",
    logoutError: "خطأ في تسجيل الخروج",
    loggingIn: "جاري تسجيل الدخول...",
    registering: "جاري إنشاء الحساب..."
  },
  profile: {
    title: "الملف الشخصي",
    yourAccount: "معلومات حسابك",
    admin: "مسؤول",
    accountType: "نوع الحساب",
    adminAccount: "حساب مسؤول",
    standardAccount: "حساب قياسي"
  },
  admin: {
    dashboard: "لوحة التحكم",
    backToApp: "العودة للتطبيق",
    overview: "نظرة عامة",
    users: "المستخدمين",
    languages: "اللغات",
    contentFilter: "تصفية المحتوى",
    unauthorized: "غير مصرح",
    unauthorizedDescription: "ليس لديك صلاحية الوصول للوحة التحكم",
    totalTranslations: "إجمالي الترجمات",
    last7Days: "آخر 7 أيام",
    textTranslations: "ترجمات نصية",
    voiceTranslations: "ترجمات صوتية",
    imageTranslations: "ترجمات صور",
    translationTypes: "أنواع الترجمات",
    distributionByType: "توزيع الترجمات حسب النوع",
    popularLanguages: "اللغات الشائعة",
    top5Languages: "أكثر 5 لغات استخداماً",
    userManagement: "إدارة المستخدمين",
    userManagementDescription: "إدارة حسابات المستخدمين",
    userManagementComingSoon: "قريباً: إدارة المستخدمين",
    languageManagement: "إدارة اللغات",
    languageManagementDescription: "إدارة اللغات المدعومة في التطبيق",
    languageManagementComingSoon: "قريباً: إدارة اللغات",
    contentFilterManagement: "إدارة تصفية المحتوى",
    contentFilterDescription: "إدارة الكلمات المحظورة وقواعد التصفية",
    searchProhibitedWords: "البحث عن كلمات محظورة",
    word: "الكلمة",
    language: "اللغة",
    category: "الفئة",
    replacement: "البديل",
    defaultReplacement: "[تم التصفية]",
    noProhibitedWords: "لا توجد كلمات محظورة",
    noProhibitedWordsFound: "لم يتم العثور على كلمات محظورة مطابقة"
  },
  errors: {
    unsupportedBrowser: "متصفح غير مدعوم",
    speechRecognitionNotSupported: "ميزة التعرف على الصوت غير مدعومة في هذا المتصفح",
    cameraError: "خطأ في الكاميرا",
    imageProcessingError: "خطأ في معالجة الصورة"
  },
  islamic_question: {
    title: "سؤال إسلامي",
    description: "اطرح سؤالاً حول الإسلام أو القرآن أو السنة وستحصل على إجابة دقيقة",
    question_label: "سؤالك",
    question_placeholder: "اكتب سؤالاً حول الإسلام...",
    answer_label: "الإجابة",
    sources: "المصادر",
    focus_area: "مجال التركيز",
    select_focus: "اختر مجال التركيز",
    focus_general: "عام",
    focus_quran: "القرآن الكريم",
    focus_hadith: "الحديث الشريف",
    focus_fiqh: "الفقه الإسلامي",
    submit: "أرسل السؤال",
    loading: "جاري البحث...",
    clear: "محو",
    error_title: "خطأ",
    error_empty: "يرجى كتابة سؤال",
    error_message: "حدث خطأ أثناء معالجة السؤال"
  },
  languages: {
    ar: "العربية",
    en: "الإنجليزية",
    fr: "الفرنسية",
    es: "الإسبانية",
    zh: "الصينية",
    ur: "الأردية",
    hi: "الهندية",
    tr: "التركية",
    fa: "الفارسية",
    id: "الإندونيسية"
  }
};

// English translations
const enTranslations = {
  app: {
    title: "Smart Translator"
  },
  nav: {
    translate: "Translate",
    conversation: "Conversation",
    voice: "Voice",
    camera: "Camera",
    profile: "Profile"
  },
  translations: {
    recent: "Recent Translations",
    viewAll: "View All",
    error: "Error loading translations",
    empty: "No previous translations",
    title: "Translation History"
  },
  features: {
    title: "Additional Features",
    imageTranslation: {
      title: "Image Translation",
      description: "Take a photo of text and translate it instantly"
    },
    conversation: {
      title: "Live Conversation",
      description: "Real-time translation between two languages"
    },
    documentTranslation: {
      title: "Document Translation",
      description: "Translate entire PDF and Word documents"
    },
    offlineTranslation: {
      title: "Offline Translation",
      description: "Translate even without internet connection"
    }
  },
  actions: {
    copy: "Copy",
    copySource: "Copy Source",
    copyTranslation: "Copy Translation",
    share: "Share",
    speak: "Speak",
    speakSource: "Speak Source",
    speakTranslation: "Speak Translation",
    delete: "Delete"
  },
  microphone: {
    title: "Voice Recognition",
    listening: "Speak now... Listening",
    processingAudio: "Processing audio...",
    preparingMicrophone: "Preparing microphone...",
    cancel: "Cancel",
    done: "Done"
  },
  camera: {
    title: "Image Translation",
    modalTitle: "Take a photo for translation",
    capturedImage: "Captured Image",
    notSupported: "Camera not supported in this browser or device",
    permissionDenied: "Camera permission was denied",
    requestPermission: "Request Permission",
    tapToActivate: "Tap to activate camera",
    retake: "Retake",
    use: "Use",
    discardPhoto: "Take new photo",
    extractedText: "Extracted Text"
  },
  conversation: {
    title: "Live Conversation",
    currentSpeaker: "Current Speaker",
    changeSpeaker: "Change Speaker",
    clear: "Clear Conversation",
    empty: "Start a new conversation by tapping the microphone button",
    listening: "Listening..."
  },
  history: {
    title: "Translation History",
    searchPlaceholder: "Search translation history",
    allTranslations: "All Translations",
    loginRequired: "Login Required",
    loginRequiredDescription: "Please login to view your translation history"
  },
  settings: {
    title: "Settings",
    description: "Customize application settings",
    languagePreferences: "Language Preferences",
    preferredSourceLanguage: "Preferred Source Language",
    preferredSourceLanguageDescription: "Default language for source text",
    preferredTargetLanguage: "Preferred Target Language",
    preferredTargetLanguageDescription: "Default language for translation",
    voiceSettings: "Voice Settings",
    voiceGender: "Voice Gender",
    voiceGenderDescription: "Choose voice gender for speech",
    female: "Female",
    male: "Male",
    voiceSpeed: "Voice Speed",
    voiceSpeedDescription: "Adjust speech rate",
    contentFiltering: "Content Filtering",
    filterLevel: "Filter Level",
    filterLevelDescription: "Adjust how strictly inappropriate content is filtered",
    filterLevelMild: "Mild",
    filterLevelModerate: "Moderate",
    filterLevelStrict: "Strict",
    selectFilterLevel: "Select filter level",
    appearance: "Appearance",
    theme: "Theme",
    themeDescription: "Choose application theme",
    themeLight: "Light",
    themeDark: "Dark",
    themeSystem: "System",
    selectTheme: "Select theme",
    selectLanguage: "Select language",
    saveSettings: "Save Settings",
    saveSuccess: "Saved",
    settingsUpdated: "Settings updated successfully",
    saveError: "Save Error",
    saving: "Saving...",
    loginRequired: "Login Required",
    loginRequiredDescription: "Please login to customize settings"
  },
  auth: {
    title: "Authentication",
    subtitle: "Login or create a new account",
    login: "Login",
    register: "Register",
    username: "Username",
    usernamePlaceholder: "Enter username",
    password: "Password",
    passwordPlaceholder: "Enter password",
    confirmPassword: "Confirm Password",
    confirmPasswordPlaceholder: "Re-enter password",
    logout: "Logout",
    loginSuccess: "Login Successful",
    welcomeBack: "Welcome back, {{username}}",
    loginError: "Login Error",
    registerSuccess: "Registration Successful",
    accountCreated: "Your account has been created successfully",
    registerError: "Registration Error",
    logoutSuccess: "Logout Successful",
    logoutError: "Logout Error",
    loggingIn: "Logging in...",
    registering: "Registering..."
  },
  profile: {
    title: "Profile",
    yourAccount: "Your Account Information",
    admin: "Admin",
    accountType: "Account Type",
    adminAccount: "Administrator Account",
    standardAccount: "Standard Account"
  },
  admin: {
    dashboard: "Admin Dashboard",
    backToApp: "Back to App",
    overview: "Overview",
    users: "Users",
    languages: "Languages",
    contentFilter: "Content Filter",
    unauthorized: "Unauthorized",
    unauthorizedDescription: "You don't have permission to access the admin dashboard",
    totalTranslations: "Total Translations",
    last7Days: "Last 7 Days",
    textTranslations: "Text Translations",
    voiceTranslations: "Voice Translations",
    imageTranslations: "Image Translations",
    translationTypes: "Translation Types",
    distributionByType: "Distribution by Type",
    popularLanguages: "Popular Languages",
    top5Languages: "Top 5 Most Used Languages",
    userManagement: "User Management",
    userManagementDescription: "Manage user accounts",
    userManagementComingSoon: "Coming Soon: User Management",
    languageManagement: "Language Management",
    languageManagementDescription: "Manage supported languages in the application",
    languageManagementComingSoon: "Coming Soon: Language Management",
    contentFilterManagement: "Content Filter Management",
    contentFilterDescription: "Manage prohibited words and filtering rules",
    searchProhibitedWords: "Search prohibited words",
    word: "Word",
    language: "Language",
    category: "Category",
    replacement: "Replacement",
    defaultReplacement: "[filtered]",
    noProhibitedWords: "No prohibited words",
    noProhibitedWordsFound: "No prohibited words found matching your search"
  },
  errors: {
    unsupportedBrowser: "Unsupported Browser",
    speechRecognitionNotSupported: "Speech recognition is not supported in this browser",
    cameraError: "Camera Error",
    imageProcessingError: "Image Processing Error"
  },
  islamic_question: {
    title: "Islamic Question",
    description: "Ask a question about Islam, Quran or Sunnah and get accurate answers",
    question_label: "Your Question",
    question_placeholder: "Type a question about Islam...",
    answer_label: "Answer",
    sources: "Sources",
    focus_area: "Focus Area",
    select_focus: "Select Focus Area",
    focus_general: "General",
    focus_quran: "Quran",
    focus_hadith: "Hadith",
    focus_fiqh: "Islamic Jurisprudence",
    submit: "Submit Question",
    loading: "Searching...",
    clear: "Clear",
    error_title: "Error",
    error_empty: "Please enter a question",
    error_message: "An error occurred while processing your question"
  },
  languages: {
    ar: "Arabic",
    en: "English",
    fr: "French",
    es: "Spanish",
    zh: "Chinese",
    ur: "Urdu",
    hi: "Hindi",
    tr: "Turkish",
    fa: "Persian",
    id: "Indonesian"
  }
};

// Initialize i18next
i18n
  .use(initReactI18next)
  .init({
    resources: {
      ar: { translation: arTranslations },
      en: { translation: enTranslations }
    },
    lng: "ar", // Default language
    fallbackLng: "ar",
    interpolation: {
      escapeValue: false // React already escapes values
    },
    react: {
      useSuspense: false
    }
  });

export default i18n;
