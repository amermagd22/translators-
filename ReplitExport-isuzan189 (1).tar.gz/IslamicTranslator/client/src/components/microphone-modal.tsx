import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { useSpeechRecognition } from "@/hooks/use-speech";
import { useTranslation } from "react-i18next";
import { Mic, X } from "lucide-react";

interface MicrophoneModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceLanguage: string;
  onResult: (text: string) => void;
}

export function MicrophoneModal({
  isOpen,
  onClose,
  sourceLanguage,
  onResult
}: MicrophoneModalProps) {
  const { t } = useTranslation();
  const [recordingTime, setRecordingTime] = useState(0);
  
  // Speech recognition hook
  const {
    transcript,
    isListening,
    startListening,
    stopListening,
    isSupported
  } = useSpeechRecognition({
    language: sourceLanguage,
    onResult: (text) => {
      // We'll receive continuous updates as the user speaks
    },
    onEnd: () => {
      if (transcript.trim()) {
        onResult(transcript);
      }
    },
    onError: (error) => {
      console.error("Speech recognition error:", error);
    }
  });
  
  // Start recording when modal opens
  useEffect(() => {
    if (isOpen && isSupported) {
      startListening();
      setRecordingTime(0);
    }
    return () => {
      stopListening();
    };
  }, [isOpen, isSupported, startListening, stopListening]);
  
  // Timer for recording duration
  useEffect(() => {
    let interval: number;
    
    if (isListening) {
      interval = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isListening]);
  
  // Format time as MM:SS
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };
  
  // Handle stop recording
  const handleStopRecording = () => {
    stopListening();
    if (transcript.trim()) {
      onResult(transcript);
    }
    onClose();
  };
  
  // Handle cancel recording
  const handleCancelRecording = () => {
    stopListening();
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleCancelRecording()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t("microphone.title")}</DialogTitle>
          <DialogClose asChild>
            <Button variant="ghost" size="icon" className="absolute right-4 top-4" onClick={handleCancelRecording}>
              <X className="h-4 w-4" />
            </Button>
          </DialogClose>
        </DialogHeader>
        
        <div className="p-8 flex flex-col items-center">
          <div className={`mic-animation text-primary text-center mb-8 ${isListening ? 'animate-pulse' : ''}`}>
            <Mic className="h-16 w-16" />
          </div>
          
          <p className="text-gray-600 mb-2 text-center">
            {isListening 
              ? t("microphone.listening") 
              : transcript 
                ? t("microphone.processingAudio") 
                : t("microphone.preparingMicrophone")}
          </p>
          
          {isListening && (
            <p className="text-sm text-gray-500 mb-4">{formatTime(recordingTime)}</p>
          )}
          
          {transcript && (
            <div className="mb-6 p-3 bg-gray-50 border border-gray-200 rounded-lg w-full max-h-32 overflow-y-auto">
              <p className="text-gray-800">{transcript}</p>
            </div>
          )}
          
          <div className="flex space-x-4">
            <Button variant="outline" onClick={handleCancelRecording}>
              {t("microphone.cancel")}
            </Button>
            <Button onClick={handleStopRecording}>
              {t("microphone.done")}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
