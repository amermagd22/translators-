import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { BulkBookImport } from "@/components/bulk-book-import";
import { BookPlus, Upload } from "lucide-react";

interface UploadDialogBookImportProps {
  bookId?: string;
  trigger?: React.ReactNode;
  onComplete?: () => void;
}

export function UploadDialogBookImport({ bookId, trigger, onComplete }: UploadDialogBookImportProps) {
  const [open, setOpen] = useState(false);

  const handleSuccess = () => {
    setOpen(false);
    if (onComplete) {
      onComplete();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="secondary" className="gap-2">
            <BookPlus className="h-4 w-4" />
            <span>استيراد كتاب</span>
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-5xl w-full h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">استيراد كتاب جديد</DialogTitle>
          <DialogDescription className="text-center">
            استخدم الكاميرا أو ارفع ملفات لاستيراد كتاب كبير بسهولة
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-2">
          <BulkBookImport bookId={bookId} onSuccess={handleSuccess} />
        </div>
        
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => setOpen(false)}>
            إلغاء
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}