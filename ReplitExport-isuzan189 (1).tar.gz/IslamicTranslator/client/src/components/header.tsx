import { Link, useLocation } from "wouter";
import { useContext } from "react";
import { AuthContext } from "@/App";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { Languages, HistoryIcon, Settings, LogOut, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Header() {
  const { user, logout } = useContext(AuthContext);
  const [location] = useLocation();
  const { t } = useTranslation();

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Languages className="h-6 w-6 ml-2" />
          <h1 className="text-xl font-bold">{t("app.title")}</h1>
        </div>
        <div className="flex items-center space-x-reverse space-x-4">
          {user ? (
            <>
              <Link href="/history">
                <Button variant="ghost" size="icon" className="text-white">
                  <HistoryIcon className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="/settings">
                <Button variant="ghost" size="icon" className="text-white">
                  <Settings className="h-5 w-5" />
                </Button>
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-white">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>{user.username}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <span className="w-full flex items-center">
                        <User className="ml-2 h-4 w-4" />
                        {t("profile.title")}
                      </span>
                    </Link>
                  </DropdownMenuItem>
                  {user.isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin/dashboard">
                        <span className="w-full flex items-center">
                          <Settings className="ml-2 h-4 w-4" />
                          {t("admin.dashboard")}
                        </span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="ml-2 h-4 w-4" />
                    {t("auth.logout")}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            location !== '/profile' && (
              <Link href="/profile">
                <Button variant="ghost" size="sm" className="text-white">
                  {t("auth.login")}
                </Button>
              </Link>
            )
          )}
        </div>
      </div>
    </header>
  );
}