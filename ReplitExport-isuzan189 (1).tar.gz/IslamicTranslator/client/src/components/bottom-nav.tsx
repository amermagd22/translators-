import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { Languages, MessageSquare, Mic, Camera, User } from "lucide-react";

export function BottomNav() {
  const [location] = useLocation();
  const { t } = useTranslation();

  const isActive = (path: string) => location === path;

  const navItems = [
    {
      icon: <Languages className="text-xl" />,
      label: t("nav.translate"),
      path: "/"
    },
    {
      icon: <MessageSquare className="text-xl" />,
      label: t("nav.conversation"),
      path: "/conversation"
    },
    {
      icon: <Mic className="text-xl" />,
      label: t("nav.voice"),
      path: "/voice",
      isMain: true
    },
    {
      icon: <Camera className="text-xl" />,
      label: t("nav.camera"),
      path: "/camera"
    },
    {
      icon: <User className="text-xl" />,
      label: t("nav.profile"),
      path: "/profile"
    }
  ];

  return (
    <nav className="bg-white shadow-lg fixed bottom-0 left-0 right-0 z-10">
      <div className="flex justify-around">
        {navItems.map((item, index) => (
          <Link key={index} href={item.path}>
            <button
              className={`flex flex-col items-center py-3 px-6 ${
                isActive(item.path) ? "text-primary" : "text-gray-500"
              }`}
            >
              {item.isMain ? (
                <div className="relative">
                  <div className="absolute -top-5 bg-accent text-white p-3 rounded-full shadow-lg">
                    {item.icon}
                  </div>
                  <span className="text-xs mt-6">{item.label}</span>
                </div>
              ) : (
                <>
                  {item.icon}
                  <span className="text-xs mt-1">{item.label}</span>
                </>
              )}
            </button>
          </Link>
        ))}
      </div>
    </nav>
  );
}