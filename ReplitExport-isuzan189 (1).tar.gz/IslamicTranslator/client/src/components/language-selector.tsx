import { useState } from "react";
import { Button } from "@/components/ui/button";
import { LanguageModal } from "@/components/language-modal";
import { useQuery } from "@tanstack/react-query";
import { fetchLanguages, Language } from "@/lib/translation";
import { ArrowLeftRight } from "lucide-react";

interface LanguageSelectorProps {
  sourceLanguage: string;
  targetLanguage: string;
  onSourceLanguageChange: (code: string) => void;
  onTargetLanguageChange: (code: string) => void;
  onSwapLanguages: () => void;
}

export function LanguageSelector({
  sourceLanguage,
  targetLanguage,
  onSourceLanguageChange,
  onTargetLanguageChange,
  onSwapLanguages
}: LanguageSelectorProps) {
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [showTargetModal, setShowTargetModal] = useState(false);
  
  const { data: languages, isLoading } = useQuery({
    queryKey: ["/api/languages"],
    staleTime: Infinity
  });
  
  const getLanguageByCode = (code: string): Language | undefined => {
    return languages?.find(lang => lang.code === code);
  };
  
  const sourceLanguageInfo = getLanguageByCode(sourceLanguage);
  const targetLanguageInfo = getLanguageByCode(targetLanguage);
  
  const handleSourceLanguageSelect = (language: Language) => {
    onSourceLanguageChange(language.code);
    setShowSourceModal(false);
  };
  
  const handleTargetLanguageSelect = (language: Language) => {
    onTargetLanguageChange(language.code);
    setShowTargetModal(false);
  };
  
  return (
    <>
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex justify-between items-center">
          {/* Source Language */}
          <div className="flex-1 text-center border-l-2 border-gray-200 pl-2">
            <Button
              variant="ghost"
              className="flex flex-col items-center mx-auto"
              onClick={() => setShowSourceModal(true)}
              disabled={isLoading}
            >
              {sourceLanguageInfo ? (
                <>
                  <img 
                    src={`https://cdn.jsdelivr.net/npm/country-flag-icons/3x2/${sourceLanguageInfo.flagCode}.svg`} 
                    alt={sourceLanguageInfo.name} 
                    className="w-8 h-6 mb-1 rounded" 
                  />
                  <span className="text-sm font-medium">{sourceLanguageInfo.nativeName}</span>
                </>
              ) : (
                <span className="text-sm font-medium">Loading...</span>
              )}
            </Button>
          </div>
          
          {/* Swap button */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="mx-4 bg-gray-100 p-2 rounded-full hover:bg-gray-200"
            onClick={onSwapLanguages}
            disabled={isLoading}
          >
            <ArrowLeftRight className="h-5 w-5 text-primary" />
          </Button>
          
          {/* Target Language */}
          <div className="flex-1 text-center border-r-2 border-gray-200 pr-2">
            <Button
              variant="ghost"
              className="flex flex-col items-center mx-auto"
              onClick={() => setShowTargetModal(true)}
              disabled={isLoading}
            >
              {targetLanguageInfo ? (
                <>
                  <img 
                    src={`https://cdn.jsdelivr.net/npm/country-flag-icons/3x2/${targetLanguageInfo.flagCode}.svg`} 
                    alt={targetLanguageInfo.name} 
                    className="w-8 h-6 mb-1 rounded" 
                  />
                  <span className="text-sm font-medium">{targetLanguageInfo.nativeName}</span>
                </>
              ) : (
                <span className="text-sm font-medium">Loading...</span>
              )}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Language selection modals */}
      <LanguageModal
        isOpen={showSourceModal}
        onClose={() => setShowSourceModal(false)}
        languages={languages || []}
        onSelect={handleSourceLanguageSelect}
        selectedLanguage={sourceLanguage}
        isLoading={isLoading}
        title="اختر لغة المصدر"
      />
      
      <LanguageModal
        isOpen={showTargetModal}
        onClose={() => setShowTargetModal(false)}
        languages={languages || []}
        onSelect={handleTargetLanguageSelect}
        selectedLanguage={targetLanguage}
        isLoading={isLoading}
        title="اختر لغة الهدف"
      />
    </>
  );
}
