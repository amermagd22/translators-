import { ReactNode } from "react";
import { Header } from "@/components/header";
import { BottomNav } from "@/components/bottom-nav";

interface LayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
}

export function Layout({ children, showBottomNav = true }: LayoutProps) {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Header />
      <main className="flex-1 overflow-y-auto pb-16 container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
      {showBottomNav && <BottomNav />}
    </div>
  );
}
