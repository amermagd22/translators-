import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { Camera, MessageSquare, FileText, Globe } from "lucide-react";

export function FeatureCards() {
  const { t } = useTranslation();
  
  const features = [
    {
      icon: <Camera className="text-primary text-xl" />,
      title: t("features.imageTranslation.title"),
      description: t("features.imageTranslation.description"),
      path: "/camera"
    },
    {
      icon: <MessageSquare className="text-primary text-xl" />,
      title: t("features.conversation.title"),
      description: t("features.conversation.description"),
      path: "/conversation"
    },
    {
      icon: <FileText className="text-primary text-xl" />,
      title: t("features.documentTranslation.title"),
      description: t("features.documentTranslation.description"),
      path: "/"
    },
    {
      icon: <Globe className="text-primary text-xl" />,
      title: t("features.offlineTranslation.title"),
      description: t("features.offlineTranslation.description"),
      path: "/"
    }
  ];
  
  return (
    <div className="mt-8">
      <h3 className="text-lg font-semibold mb-4">{t("features.title")}</h3>
      <div className="grid grid-cols-2 gap-4">
        {features.map((feature, index) => (
          <Link key={index} href={feature.path}>
            <div className="bg-white rounded-lg shadow-sm p-4 flex flex-col items-center transition hover:shadow-md cursor-pointer">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3">
                {feature.icon}
              </div>
              <h3 className="text-sm font-medium mb-1">{feature.title}</h3>
              <p className="text-xs text-gray-500 text-center">{feature.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
