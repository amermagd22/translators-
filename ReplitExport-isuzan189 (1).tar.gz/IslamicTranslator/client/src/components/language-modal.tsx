import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Language } from "@/lib/translation";
import { X, Search } from "lucide-react";

interface LanguageModalProps {
  isOpen: boolean;
  onClose: () => void;
  languages: Language[];
  onSelect: (language: Language) => void;
  selectedLanguage: string;
  isLoading: boolean;
  title: string;
}

export function LanguageModal({
  isOpen,
  onClose,
  languages,
  onSelect,
  selectedLanguage,
  isLoading,
  title
}: LanguageModalProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredLanguages, setFilteredLanguages] = useState<Language[]>([]);
  
  useEffect(() => {
    if (languages.length > 0) {
      if (searchTerm.trim() === "") {
        setFilteredLanguages(languages);
      } else {
        const lowerSearchTerm = searchTerm.toLowerCase();
        setFilteredLanguages(
          languages.filter(
            lang =>
              lang.name.toLowerCase().includes(lowerSearchTerm) ||
              lang.nativeName.toLowerCase().includes(lowerSearchTerm)
          )
        );
      }
    }
  }, [searchTerm, languages]);
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">{title}</DialogTitle>
          <DialogClose asChild>
            <Button variant="ghost" size="icon" className="absolute right-4 top-4">
              <X className="h-4 w-4" />
            </Button>
          </DialogClose>
        </DialogHeader>
        
        <div className="p-2">
          <div className="mb-3 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
            <Input
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="بحث عن لغة..."
              className="w-full pl-9"
            />
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-1 p-1">
                {filteredLanguages.map(language => (
                  <Button
                    key={language.code}
                    variant="ghost"
                    className={`flex justify-start items-center w-full p-3 rounded-lg ${
                      selectedLanguage === language.code ? 'bg-primary/10 text-primary' : ''
                    }`}
                    onClick={() => onSelect(language)}
                  >
                    <img
                      src={`https://cdn.jsdelivr.net/npm/country-flag-icons/3x2/${language.flagCode}.svg`}
                      alt={language.name}
                      className="w-6 h-4 ml-3"
                    />
                    <span>{language.nativeName}</span>
                    {language.nativeName !== language.name && (
                      <span className="text-gray-500 text-sm mr-2">({language.name})</span>
                    )}
                  </Button>
                ))}
                
                {filteredLanguages.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    لا توجد لغات مطابقة للبحث
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
