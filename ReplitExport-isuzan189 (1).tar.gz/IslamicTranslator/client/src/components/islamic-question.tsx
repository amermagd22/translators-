import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, SendIcon, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface IslamicQuestionProps {
  language: string;
}

export function IslamicQuestion({ language }: IslamicQuestionProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [citations, setCitations] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [focusArea, setFocusArea] = useState<"general" | "quran" | "hadith" | "fiqh">("general");

  const handleSubmit = async () => {
    if (!question.trim()) {
      toast({
        title: t("islamic_question.error_title"),
        description: t("islamic_question.error_empty"),
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const res = await apiRequest("POST", "/api/islamic-questions", {
        question,
        language,
        focusArea,
      });
      
      const data = await res.json();
      
      setAnswer(data.answer || "");
      setCitations(data.citations || []);
      
    } catch (error) {
      toast({
        title: t("islamic_question.error_title"),
        description: t("islamic_question.error_message"),
        variant: "destructive",
      });
      console.error("Error fetching answer:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const clearAll = () => {
    setQuestion("");
    setAnswer("");
    setCitations([]);
  };

  return (
    <Card className="w-full mt-8 border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          {t("islamic_question.title")}
        </CardTitle>
        <CardDescription>
          {t("islamic_question.description")}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="focus-area">{t("islamic_question.focus_area")}</Label>
          <Select 
            value={focusArea} 
            onValueChange={(value) => setFocusArea(value as any)}
          >
            <SelectTrigger id="focus-area" className="w-full">
              <SelectValue placeholder={t("islamic_question.select_focus")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="general">{t("islamic_question.focus_general")}</SelectItem>
              <SelectItem value="quran">{t("islamic_question.focus_quran")}</SelectItem>
              <SelectItem value="hadith">{t("islamic_question.focus_hadith")}</SelectItem>
              <SelectItem value="fiqh">{t("islamic_question.focus_fiqh")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="question">{t("islamic_question.question_label")}</Label>
          <Textarea
            id="question"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder={t("islamic_question.question_placeholder")}
            className="min-h-[100px]"
            dir={language === "ar" ? "rtl" : "ltr"}
          />
        </div>

        {answer && (
          <div className="space-y-2 mt-4">
            <Label>{t("islamic_question.answer_label")}</Label>
            <div 
              className="p-4 bg-muted/50 rounded-md whitespace-pre-wrap" 
              dir={language === "ar" ? "rtl" : "ltr"}
            >
              {answer}
            </div>
            
            {citations.length > 0 && (
              <div className="mt-4">
                <Label>{t("islamic_question.sources")}</Label>
                <ul className="list-disc list-inside mt-2 text-sm text-muted-foreground">
                  {citations.map((citation, index) => (
                    <li key={index} className="break-all">
                      <a 
                        href={citation} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {citation}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={clearAll}
          disabled={isLoading || (!question && !answer)}
        >
          {t("islamic_question.clear")}
        </Button>
        <Button onClick={handleSubmit} disabled={isLoading || !question.trim()}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t("islamic_question.loading")}
            </>
          ) : (
            <>
              <SendIcon className="mr-2 h-4 w-4" />
              {t("islamic_question.submit")}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}