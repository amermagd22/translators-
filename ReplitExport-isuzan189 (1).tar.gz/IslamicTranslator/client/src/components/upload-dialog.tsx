import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';

// انواع التصنيفات واللغات
const bookCategories = [
  { id: 'quran', name: 'القرآن الكريم وعلومه' },
  { id: 'hadith', name: 'الحديث وعلومه' },
  { id: 'fiqh', name: 'الفقه الإسلامي' },
  { id: 'aqidah', name: 'العقيدة' },
  { id: 'seerah', name: 'السيرة النبوية' },
  { id: 'history', name: 'التاريخ الإسلامي' },
  { id: 'dawah', name: 'كتب الدعوة' },
  { id: 'comparative', name: 'مقارنة الأديان' },
  { id: 'science', name: 'الإعجاز العلمي' }
];

const languages = [
  { id: 'ar', name: 'العربية' },
  { id: 'en', name: 'الإنجليزية' },
  { id: 'fr', name: 'الفرنسية' },
  { id: 'es', name: 'الإسبانية' },
  { id: 'de', name: 'الألمانية' },
  { id: 'ru', name: 'الروسية' },
  { id: 'zh', name: 'الصينية' },
  { id: 'ur', name: 'الأردية' },
  { id: 'tr', name: 'التركية' },
  { id: 'ms', name: 'الملايو' }
];

type UploadDialogProps = {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (details: UploadDetails) => void;
  file: File | null;
  fileType: string;
  isMultipleFiles: boolean;
  contentType: 'books' | 'videos';
};

export type UploadDetails = {
  title: string;
  author: string;
  language: string;
  category: string;
  description: string;
  fileType: string;
  fileName: string;
};

export function UploadDialog({
  isOpen,
  onClose,
  onUpload,
  file,
  fileType,
  isMultipleFiles,
  contentType
}: UploadDialogProps) {
  const { toast } = useToast();
  const [details, setDetails] = useState<UploadDetails>({
    title: file ? file.name.split('.')[0] : '',
    author: '',
    language: 'ar',
    category: 'quran',
    description: '',
    fileType: fileType,
    fileName: file ? file.name : ''
  });
  
  const handleSubmit = () => {
    if (!details.title || !details.author) {
      toast({
        title: 'بيانات مفقودة',
        description: 'يجب إدخال العنوان والمؤلف',
        variant: 'destructive',
      });
      return;
    }
    
    onUpload(details);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) {
        onClose();
      }
    }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{contentType === 'books' ? 'إضافة كتاب جديد' : 'إضافة فيديو جديد'}</DialogTitle>
          <DialogDescription>
            {contentType === 'books' 
              ? 'أدخل معلومات الكتاب الذي تريد إضافته للمكتبة' 
              : 'أدخل معلومات الفيديو الذي تريد إضافته للمكتبة'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid items-center gap-2">
            <Label htmlFor="file-name">اسم الملف</Label>
            <Input
              id="file-name"
              value={file?.name || ''}
              readOnly
              disabled
            />
          </div>
          
          <div className="grid items-center gap-2">
            <Label htmlFor="file-type">نوع الملف</Label>
            <Input
              id="file-type"
              value={fileType === 'pdf' ? 'ملف PDF' 
                   : fileType === 'archive' ? 'ملف مضغوط' 
                   : fileType === 'image' ? 'صورة' 
                   : fileType === 'epub' ? 'كتاب إلكتروني (EPUB)' 
                   : 'نوع آخر'}
              readOnly
              disabled
            />
          </div>
          
          <div className="grid items-center gap-2">
            <Label htmlFor="title">العنوان <span className="text-red-500">*</span></Label>
            <Input
              id="title"
              value={details.title}
              onChange={(e) => setDetails({...details, title: e.target.value})}
              placeholder="أدخل عنوان الكتاب"
            />
          </div>
          
          <div className="grid items-center gap-2">
            <Label htmlFor="author">المؤلف <span className="text-red-500">*</span></Label>
            <Input
              id="author"
              value={details.author}
              onChange={(e) => setDetails({...details, author: e.target.value})}
              placeholder="أدخل اسم المؤلف"
            />
          </div>
          
          <div className="grid items-center gap-2">
            <Label htmlFor="language">اللغة</Label>
            <Select value={details.language} onValueChange={(value) => setDetails({...details, language: value})}>
              <SelectTrigger>
                <SelectValue placeholder="اختر اللغة" />
              </SelectTrigger>
              <SelectContent>
                {languages.map(lang => (
                  <SelectItem key={lang.id} value={lang.id}>{lang.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {contentType === 'books' && (
            <div className="grid items-center gap-2">
              <Label htmlFor="category">التصنيف</Label>
              <Select value={details.category} onValueChange={(value) => setDetails({...details, category: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  {bookCategories.map(category => (
                    <SelectItem key={category.id} value={category.id}>{category.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          <div className="grid items-center gap-2">
            <Label htmlFor="description">الوصف</Label>
            <Textarea
              id="description"
              value={details.description}
              onChange={(e) => setDetails({...details, description: e.target.value})}
              placeholder="أدخل وصفًا مختصرًا"
              className="min-h-[80px]"
            />
          </div>
          
          {isMultipleFiles && (
            <div className="bg-yellow-50 p-3 rounded border border-yellow-200 text-yellow-800 text-sm">
              <p>ملاحظة: لقد قمت بتحميل ملفات متعددة. سيتم معالجة هذه الملفات كمجموعة واحدة.</p>
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline"
            onClick={onClose}
          >
            إلغاء
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={!details.title || !details.author}
          >
            رفع وإضافة
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}