import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { formatCharCount, getLanguageDirection, getLanguageFontClass } from "@/lib/utils";
import { Mic, Camera, X, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { MicrophoneModal } from "@/components/microphone-modal";
import { CameraModal } from "@/components/camera-modal";

interface TranslationInputProps {
  value: string;
  onChange: (value: string) => void;
  onClear: () => void;
  onTranslate: () => void;
  sourceLanguage: string;
  maxLength?: number;
  isTranslating?: boolean;
  onMicrophoneCapture?: (text: string) => void;
  onCameraCapture?: (imageData: string) => void;
}

export function TranslationInput({
  value,
  onChange,
  onClear,
  onTranslate,
  sourceLanguage,
  maxLength = 500,
  isTranslating = false,
  onMicrophoneCapture,
  onCameraCapture
}: TranslationInputProps) {
  const [showMicrophoneModal, setShowMicrophoneModal] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  
  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [value]);
  
  const handleCopy = async () => {
    if (!value.trim()) return;
    
    try {
      await navigator.clipboard.writeText(value);
      toast({
        description: "تم نسخ النص",
      });
    } catch (err) {
      toast({
        title: "فشل نسخ النص",
        description: "يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    }
  };
  
  const handleMicrophoneResult = (text: string) => {
    onChange(text);
    if (onMicrophoneCapture) {
      onMicrophoneCapture(text);
    }
    setShowMicrophoneModal(false);
  };
  
  const handleCameraResult = (imageData: string) => {
    if (onCameraCapture) {
      onCameraCapture(imageData);
    }
    setShowCameraModal(false);
  };
  
  const inputDirection = getLanguageDirection(sourceLanguage);
  const inputFontClass = getLanguageFontClass(sourceLanguage);
  
  return (
    <>
      <div className="bg-white rounded-lg shadow-md p-4">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-medium text-gray-700">النص المصدر</h2>
          <div className="text-sm text-gray-500">
            {formatCharCount(value.length, maxLength)}
          </div>
        </div>
        
        <div className="relative">
          <Textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="اكتب أو انطق النص المراد ترجمته..."
            className={`w-full min-h-[120px] p-3 border border-gray-300 rounded-lg focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none resize-none ${inputFontClass}`}
            dir={inputDirection}
            maxLength={maxLength}
          />
          
          <div className="absolute bottom-3 right-3 flex space-x-reverse space-x-2">
            <Button
              variant="ghost"
              size="icon"
              type="button"
              onClick={onClear}
              disabled={!value.trim() || isTranslating}
              className="text-gray-500 hover:text-destructive"
            >
              <X className="h-4 w-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              type="button"
              onClick={handleCopy}
              disabled={!value.trim() || isTranslating}
              className="text-gray-500 hover:text-primary"
            >
              <Copy className="h-4 w-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              type="button"
              onClick={() => setShowCameraModal(true)}
              disabled={isTranslating}
              className="text-gray-500 hover:text-primary"
            >
              <Camera className="h-4 w-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              type="button"
              onClick={() => setShowMicrophoneModal(true)}
              disabled={isTranslating}
              className="text-primary hover:text-primary/80"
            >
              <Mic className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="mt-4 flex justify-end">
          <Button
            onClick={onTranslate}
            disabled={!value.trim() || isTranslating}
            className="bg-primary hover:bg-primary/90 text-white px-4 py-1 rounded-full text-sm font-medium flex items-center"
          >
            {isTranslating ? (
              <div className="mr-1 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : null}
            ترجمة
          </Button>
        </div>
      </div>
      
      {/* Microphone Modal */}
      <MicrophoneModal
        isOpen={showMicrophoneModal}
        onClose={() => setShowMicrophoneModal(false)}
        sourceLanguage={sourceLanguage}
        onResult={handleMicrophoneResult}
      />
      
      {/* Camera Modal */}
      <CameraModal
        isOpen={showCameraModal}
        onClose={() => setShowCameraModal(false)}
        onCapture={handleCameraResult}
      />
    </>
  );
}
