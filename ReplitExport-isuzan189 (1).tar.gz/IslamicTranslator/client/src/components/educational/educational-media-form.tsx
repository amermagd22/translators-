import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { insertEducationalMediaSchema, EducationalMedia } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface EducationalMediaFormProps {
  lessonId: number;
  mediaData?: EducationalMedia;
  onSuccess?: () => void;
}

const mediaFormSchema = insertEducationalMediaSchema.extend({
  mediaUrl: z.string().url({ message: "يجب أن يكون رابط صالح" }),
  title: z.string().min(3, { message: "يجب أن يكون العنوان 3 أحرف على الأقل" }),
  description: z.string().optional(),
  duration: z.coerce.number().min(1, { message: "يجب أن تكون المدة أكبر من صفر" }).optional(),
  thumbnailUrl: z.string().url({ message: "يجب أن يكون رابط صالح للصورة المصغرة" }).optional(),
  mediaType: z.enum(["video", "presentation"], {
    required_error: "يرجى اختيار نوع الوسائط",
  }),
  orderIndex: z.coerce.number().optional(),
});

export function EducationalMediaForm({ lessonId, mediaData, onSuccess }: EducationalMediaFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<z.infer<typeof mediaFormSchema>>({
    resolver: zodResolver(mediaFormSchema),
    defaultValues: mediaData ? {
      ...mediaData,
    } : {
      lessonId,
      mediaType: "video",
      orderIndex: 0,
    },
  });

  const onSubmit = async (values: z.infer<typeof mediaFormSchema>) => {
    setIsSubmitting(true);
    try {
      // Handle form submission - create or update media
      const url = mediaData 
        ? `/api/educational-media/${mediaData.id}` 
        : "/api/educational-media";
      
      const method = mediaData ? "PATCH" : "POST";
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      });
      
      if (!response.ok) {
        throw new Error("فشل في حفظ الوسائط التعليمية");
      }
      
      toast({
        title: mediaData ? "تم تحديث الوسائط بنجاح" : "تمت إضافة الوسائط بنجاح",
        description: mediaData 
          ? "تم تحديث الوسائط التعليمية بنجاح" 
          : "تمت إضافة الوسائط التعليمية بنجاح",
      });
      
      if (onSuccess) {
        onSuccess();
      }
      
      if (!mediaData) {
        form.reset({
          lessonId,
          mediaType: "video",
          title: "",
          description: "",
          mediaUrl: "",
          thumbnailUrl: "",
          duration: undefined,
          orderIndex: 0,
        });
      }
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: error instanceof Error ? error.message : "حدث خطأ أثناء حفظ الوسائط التعليمية",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="mediaType"
          render={({ field }) => (
            <FormItem className="space-y-1">
              <FormLabel>نوع الوسائط</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value="video" id="video" />
                    <Label htmlFor="video">فيديو</Label>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value="presentation" id="presentation" />
                    <Label htmlFor="presentation">عرض تقديمي</Label>
                  </div>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>عنوان الوسائط</FormLabel>
              <FormControl>
                <Input placeholder="أدخل عنوان الوسائط التعليمية" {...field} />
              </FormControl>
              <FormDescription>
                عنوان وصفي للوسائط التعليمية
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>وصف الوسائط</FormLabel>
              <FormControl>
                <Textarea placeholder="أدخل وصفًا للوسائط التعليمية" {...field} value={field.value || ""} />
              </FormControl>
              <FormDescription>
                وصف تفصيلي لمحتوى الوسائط التعليمية
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="mediaUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>رابط الوسائط</FormLabel>
              <FormControl>
                <Input placeholder="https://example.com/video.mp4" {...field} />
              </FormControl>
              <FormDescription>
                رابط مباشر للفيديو أو العرض التقديمي
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="thumbnailUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>رابط الصورة المصغرة (اختياري)</FormLabel>
              <FormControl>
                <Input placeholder="https://example.com/thumbnail.jpg" {...field} value={field.value || ""} />
              </FormControl>
              <FormDescription>
                رابط لصورة مصغرة تمثل محتوى الوسائط
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="duration"
          render={({ field }) => (
            <FormItem>
              <FormLabel>المدة (بالثواني) (اختياري)</FormLabel>
              <FormControl>
                <Input type="number" min="1" {...field} value={field.value || ""} />
              </FormControl>
              <FormDescription>
                مدة الوسائط التعليمية بالثواني
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="orderIndex"
          render={({ field }) => (
            <FormItem>
              <FormLabel>ترتيب العرض (اختياري)</FormLabel>
              <FormControl>
                <Input type="number" min="0" {...field} value={field.value ?? 0} />
              </FormControl>
              <FormDescription>
                ترتيب عرض هذه الوسائط في قائمة الوسائط التعليمية
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-end">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
            {mediaData ? "تحديث الوسائط" : "إضافة الوسائط"}
          </Button>
        </div>
      </form>
    </Form>
  );
}