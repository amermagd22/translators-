import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileVideo, 
  PresentationIcon, 
  Pencil, 
  Trash2, 
  ExternalLink,
  Filter,
  BarChart3,
  Book,
  Calendar,
  Clock,
  Tag
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox"; 
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { EducationalMediaForm } from "./educational-media-form";
import { EducationalMedia } from "@shared/schema";

interface EducationalMediaListProps {
  lessonId: number;
  mediaType?: string;
}

export function EducationalMediaList({ lessonId, mediaType }: EducationalMediaListProps) {
  const { toast } = useToast();
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [selectedMedia, setSelectedMedia] = useState<EducationalMedia | null>(null);
  
  // State for filtering and sorting
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest" | "duration" | "title">("newest");
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  
  const { data: mediaList, isLoading, isError } = useQuery<EducationalMedia[]>({
    queryKey: ["/api/educational-media/lesson", lessonId],
    enabled: !!lessonId,
  });
  
  // Extract categories from media items for filter dropdown
  const categories = mediaList 
    ? [...new Set(mediaList.filter(m => m.description?.includes("التصنيف:"))
        .map(m => {
          const match = m.description?.match(/التصنيف:\s*([^,;\n]+)/);
          return match ? match[1].trim() : null;
        })
        .filter(Boolean))] 
    : [];
  
  // Apply filters and sorting
  const processedMediaList = useMemo(() => {
    if (!mediaList) return [];
    
    // First filter by media type if specified
    let result = mediaType ? mediaList.filter(media => media.mediaType === mediaType) : mediaList;
    
    // Then apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        m => m.title.toLowerCase().includes(term) || 
             (m.description?.toLowerCase().includes(term) || false)
      );
    }
    
    // Then apply category filter
    if (categoryFilter) {
      result = result.filter(m => 
        m.description?.includes(`التصنيف: ${categoryFilter}`) || 
        m.description?.includes(`فئة: ${categoryFilter}`)
      );
    }
    
    // Finally apply sorting
    return result.sort((a, b) => {
      switch (sortOrder) {
        case "newest":
          return (new Date(b.createdAt || 0)).getTime() - (new Date(a.createdAt || 0)).getTime();
        case "oldest":
          return (new Date(a.createdAt || 0)).getTime() - (new Date(b.createdAt || 0)).getTime();
        case "duration":
          return (b.duration || 0) - (a.duration || 0);
        case "title":
          return a.title.localeCompare(b.title, 'ar');
        default:
          return 0;
      }
    });
  }, [mediaList, mediaType, searchTerm, categoryFilter, sortOrder]);

  const handleDelete = async (mediaId: number) => {
    try {
      const response = await fetch(`/api/educational-media/${mediaId}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error("Failed to delete educational media");
      }
      
      queryClient.invalidateQueries({ queryKey: ["/api/educational-media/lesson", lessonId] });
      toast({
        title: "تم الحذف بنجاح",
        description: "تم حذف المحتوى التعليمي بنجاح",
      });
    } catch (error) {
      toast({
        title: "فشل في الحذف",
        description: error instanceof Error ? error.message : "حدث خطأ أثناء حذف المحتوى",
        variant: "destructive",
      });
    }
  };

  const handleEditClick = (media: EducationalMedia) => {
    setSelectedMedia(media);
    setOpenEditDialog(true);
  };
  
  const handleViewMedia = (url: string) => {
    window.open(url, "_blank");
  };

  const getMediaIcon = (type: string) => {
    switch (type) {
      case "video":
        return <FileVideo className="h-5 w-5" />;
      case "presentation":
        return <PresentationIcon className="h-5 w-5" />;
      default:
        return <FileVideo className="h-5 w-5" />;
    }
  };
  
  const onEditSuccess = () => {
    setOpenEditDialog(false);
    setSelectedMedia(null);
    queryClient.invalidateQueries({ queryKey: ["/api/educational-media/lesson", lessonId] });
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-[160px] w-full rounded-md" />
        <Skeleton className="h-[160px] w-full rounded-md" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center p-4 border border-destructive/50 rounded-md">
        <p className="text-destructive">حدث خطأ أثناء تحميل الوسائط التعليمية</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">
          {mediaType === "video" ? "مقاطع الفيديو" : 
           mediaType === "presentation" ? "العروض التقديمية" : 
           "الوسائط التعليمية"}
        </h3>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm">
              {mediaType === "video" ? "إضافة فيديو جديد" : 
               mediaType === "presentation" ? "إضافة عرض تقديمي جديد" : 
               "إضافة وسائط جديدة"}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>
                {mediaType === "video" ? "إضافة فيديو جديد" : 
                 mediaType === "presentation" ? "إضافة عرض تقديمي جديد" : 
                 "إضافة وسائط تعليمية جديدة"}
              </DialogTitle>
            </DialogHeader>
            <EducationalMediaForm 
              lessonId={lessonId}
              mediaType={mediaType}
              onSuccess={() => {
                queryClient.invalidateQueries({ queryKey: ["/api/educational-media/lesson", lessonId] });
              }}
            />
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Filter and sort controls */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between mb-4 p-3 bg-muted/30 rounded-lg">
        <div className="flex items-center gap-2 flex-1">
          <Input 
            placeholder="البحث عن محتوى تعليمي..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-xs"
          />
          {searchTerm && (
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setSearchTerm("")}
              className="h-8 w-8"
            >
              <span className="sr-only">مسح</span>
              <span aria-hidden="true">&times;</span>
            </Button>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2">
          {categories.length > 0 && (
            <Select
              value={categoryFilter || ""}
              onValueChange={(value) => setCategoryFilter(value || null)}
            >
              <SelectTrigger className="w-[140px] h-9">
                <SelectValue placeholder="تصفية بالفئة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">جميع الفئات</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          
          <Select
            value={sortOrder}
            onValueChange={(value) => setSortOrder(value as any)}
          >
            <SelectTrigger className="w-[140px] h-9">
              <SelectValue placeholder="الترتيب حسب" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">الأحدث أولاً</SelectItem>
              <SelectItem value="oldest">الأقدم أولاً</SelectItem>
              <SelectItem value="duration">المدة (الأطول)</SelectItem>
              <SelectItem value="title">أبجدياً</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {processedMediaList && processedMediaList.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2">
          {processedMediaList.map((media) => (
            <Card key={media.id} className="overflow-hidden">
              <CardHeader className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <Badge variant="outline" className="mb-2">
                      {media.mediaType === "video" ? "فيديو" : "عرض تقديمي"}
                    </Badge>
                    <CardTitle className="text-base">{media.title}</CardTitle>
                  </div>
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleEditClick(media)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>هل أنت متأكد من حذف هذه الوسائط؟</AlertDialogTitle>
                          <AlertDialogDescription>
                            هذا الإجراء نهائي ولا يمكن التراجع عنه.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>إلغاء</AlertDialogCancel>
                          <AlertDialogAction 
                            className="bg-destructive text-destructive-foreground"
                            onClick={() => handleDelete(media.id)}
                          >
                            حذف
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <CardDescription className="line-clamp-2 mb-2">
                  {media.description || "لا يوجد وصف"}
                </CardDescription>
                {media.duration && (
                  <div className="text-xs text-muted-foreground">
                    المدة: {Math.floor(media.duration / 60)}:{(media.duration % 60).toString().padStart(2, '0')} دقيقة
                  </div>
                )}
              </CardContent>
              <CardFooter className="p-4 bg-muted/30">
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="w-full gap-2"
                  onClick={() => handleViewMedia(media.contentUrl)}
                >
                  {getMediaIcon(media.mediaType)}
                  عرض {media.mediaType === "video" ? "الفيديو" : "العرض التقديمي"}
                  <ExternalLink className="h-3 w-3 ml-1" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center p-8 border border-dashed rounded-md">
          <p className="text-muted-foreground">
            {mediaType === "video" ? "لم يتم إضافة أي مقاطع فيديو لهذا الدرس بعد" : 
             mediaType === "presentation" ? "لم يتم إضافة أي عروض تقديمية لهذا الدرس بعد" : 
             "لم يتم إضافة أي وسائط تعليمية لهذا الدرس بعد"}
          </p>
        </div>
      )}
      
      {openEditDialog && selectedMedia && (
        <Dialog open={openEditDialog} onOpenChange={setOpenEditDialog}>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>تعديل الوسائط التعليمية</DialogTitle>
            </DialogHeader>
            <EducationalMediaForm 
              lessonId={lessonId} 
              mediaData={selectedMedia}
              onSuccess={onEditSuccess}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}