import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { EducationalMediaList } from "./educational-media-list";
import { FileText, FileVideo, PresentationIcon } from "lucide-react";
import * as React from "react";

interface EducationalMediaTabProps {
  lessonId: number;
  lessonContent: string;
}

export function EducationalMediaTab({ lessonId, lessonContent }: EducationalMediaTabProps) {
  // State to track media counts
  const [videoCount, setVideoCount] = React.useState(0);
  const [presentationCount, setPresentationCount] = React.useState(0);

  // Function to update counts
  const updateCounts = async () => {
    try {
      const response = await fetch(`/api/educational-media/counts/${lessonId}`);
      const data = await response.json();
      setVideoCount(data.videoCount || 0);
      setPresentationCount(data.presentationCount || 0);
    } catch (error) {
      console.error("Failed to fetch media counts:", error);
    }
  };

  // Fetch counts on component mount
  React.useEffect(() => {
    updateCounts();
  }, [lessonId]);

  return (
    <Tabs defaultValue="content" className="w-full">
      <TabsList className="grid w-full grid-cols-3 mb-4">
        <TabsTrigger value="content" className="flex items-center gap-2">
          <FileText className="h-4 w-4" />
          <span>محتوى الدرس</span>
        </TabsTrigger>
        <TabsTrigger value="videos" className="flex items-center gap-2">
          <FileVideo className="h-4 w-4" />
          <span>مقاطع الفيديو</span>
          {videoCount > 0 && <Badge variant="secondary" className="mr-2">{videoCount}</Badge>}
        </TabsTrigger>
        <TabsTrigger value="presentations" className="flex items-center gap-2">
          <PresentationIcon className="h-4 w-4" />
          <span>العروض التقديمية</span>
          {presentationCount > 0 && <Badge variant="secondary" className="mr-2">{presentationCount}</Badge>}
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="content">
        <Card>
          <CardContent className="pt-6">
            <div className="prose prose-sm md:prose-base lg:prose-lg dark:prose-invert mx-auto">
              <div dangerouslySetInnerHTML={{ __html: lessonContent }} />
            </div>
          </CardContent>
        </Card>
      </TabsContent>
      
      <TabsContent value="videos">
        <EducationalMediaList 
          lessonId={lessonId} 
          mediaType="video"
        />
      </TabsContent>
      
      <TabsContent value="presentations">
        <EducationalMediaList 
          lessonId={lessonId} 
          mediaType="presentation"
        />
      </TabsContent>
    </Tabs>
  );
}