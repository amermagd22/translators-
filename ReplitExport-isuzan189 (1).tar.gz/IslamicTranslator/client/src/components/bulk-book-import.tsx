import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  Camera, 
  Upload, 
  FileText, 
  Image, 
  ChevronRight, 
  ChevronLeft, 
  Plus, 
  Trash2, 
  Check, 
  Ban, 
  BookOpen, 
  FileSymlink, 
  RefreshCw, 
  Layers, 
  BookCopy
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";

interface BulkBookImportProps {
  onSuccess?: () => void;
  bookId?: string;
}

export function BulkBookImport({ onSuccess, bookId }: BulkBookImportProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("camera");
  const [capturing, setCapturing] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [progress, setProgress] = useState(0);
  const [capturedImages, setCapturedImages] = useState<string[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [processingResults, setProcessingResults] = useState<{
    success: boolean;
    pageCount: number;
    errorMessage?: string;
  } | null>(null);
  const [bookDetails, setBookDetails] = useState({
    title: "",
    author: "",
    language: "ar",
    category: "academic",
  });
  const [importOptions, setImportOptions] = useState({
    autoDetectChapters: true,
    enhanceTextQuality: true,
    extractImages: true,
    preserveLayout: true,
    batchSize: 20,
  });
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Камера
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCapturing(true);
      }
    } catch (error) {
      toast({
        title: "خطأ في تشغيل الكاميرا",
        description: error instanceof Error ? error.message : "حدث خطأ غير معروف",
        variant: "destructive"
      });
    }
  };
  
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setCapturing(false);
    }
  };
  
  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext("2d");
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageDataUrl = canvas.toDataURL("image/jpeg", 0.95);
        
        setCapturedImages(prev => [...prev, imageDataUrl]);
        
        toast({
          title: "تم التقاط الصورة",
          description: `تم التقاط صفحة جديدة. المجموع: ${capturedImages.length + 1}`,
        });
      }
    }
  };
  
  // Обработка файлов
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const fileArray = Array.from(files);
      setSelectedFiles(fileArray);
      
      toast({
        title: "تم اختيار الملفات",
        description: `تم اختيار ${fileArray.length} ملف/ملفات`,
      });
    }
  };
  
  const handleBulkUpload = async () => {
    // Преобразование файлов в formData и отправка
    setProcessing(true);
    setProgress(0);
    
    try {
      const totalFiles = selectedFiles.length > 0 ? selectedFiles.length : capturedImages.length;
      const batchSize = importOptions.batchSize;
      let uploadedFiles = 0;
      
      // Симуляция загрузки с прогрессом
      for (let i = 0; i < totalFiles; i += batchSize) {
        const batch = selectedFiles.length > 0 
          ? selectedFiles.slice(i, i + batchSize)
          : capturedImages.slice(i, i + batchSize);
          
        // Здесь должен быть реальный API-запрос для загрузки файлов
        // Имитация задержки сети
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        uploadedFiles += batch.length;
        setProgress(Math.floor((uploadedFiles / totalFiles) * 100));
      }
      
      // После завершения загрузки всех файлов
      setProcessingResults({
        success: true,
        pageCount: totalFiles,
      });
      
      setCurrentStep(3);
    } catch (error) {
      setProcessingResults({
        success: false,
        pageCount: 0,
        errorMessage: error instanceof Error ? error.message : "حدث خطأ أثناء معالجة الملفات"
      });
      
      toast({
        title: "فشل في رفع الملفات",
        description: error instanceof Error ? error.message : "حدث خطأ أثناء رفع الملفات",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };
  
  const handleComplete = () => {
    // Оповещение об успехе и сброс состояния
    toast({
      title: "تم الاستيراد بنجاح",
      description: `تم استيراد ${processingResults?.pageCount || 0} صفحة بنجاح`,
    });
    
    setCapturedImages([]);
    setSelectedFiles([]);
    setProcessingResults(null);
    setCurrentStep(1);
    
    // Вызов колбэка успеха, если он предоставлен
    if (onSuccess) {
      onSuccess();
    }
    
    // Инвалидация запросов для обновления данных
    if (bookId) {
      queryClient.invalidateQueries({ queryKey: ["/api/books", bookId] });
    } else {
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
    }
  };
  
  return (
    <div className="w-full max-w-4xl mx-auto">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full mb-4">
          <TabsTrigger value="camera" className="flex items-center gap-2 flex-1">
            <Camera className="h-4 w-4" />
            <span>التقاط الصفحات</span>
          </TabsTrigger>
          <TabsTrigger value="files" className="flex items-center gap-2 flex-1">
            <Upload className="h-4 w-4" />
            <span>رفع الملفات</span>
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center gap-2 flex-1">
            <FileSymlink className="h-4 w-4" />
            <span>خيارات متقدمة</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Шаги мастера */}
        <div className="mb-6">
          <div className="flex justify-between items-center">
            <div className={`flex items-center ${currentStep >= 1 ? "text-primary" : "text-muted-foreground"}`}>
              <div className="rounded-full bg-primary/10 p-2">
                <FileText className="h-5 w-5" />
              </div>
              <span className="mx-2">اختيار الملفات</span>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
            <div className={`flex items-center ${currentStep >= 2 ? "text-primary" : "text-muted-foreground"}`}>
              <div className="rounded-full bg-primary/10 p-2">
                <Layers className="h-5 w-5" />
              </div>
              <span className="mx-2">معالجة الصفحات</span>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
            <div className={`flex items-center ${currentStep >= 3 ? "text-primary" : "text-muted-foreground"}`}>
              <div className="rounded-full bg-primary/10 p-2">
                <BookOpen className="h-5 w-5" />
              </div>
              <span className="mx-2">إكمال</span>
            </div>
          </div>
          <Progress value={currentStep === 1 ? 33 : currentStep === 2 ? 66 : 100} className="mt-2" />
        </div>
        
        {currentStep === 1 && (
          <>
            <TabsContent value="camera" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>التقاط صفحات الكتاب</CardTitle>
                  <CardDescription>
                    استخدم الكاميرا لالتقاط صور لصفحات الكتاب. تأكد من إضاءة جيدة ووضوح النص.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-black rounded-lg overflow-hidden relative aspect-video mb-4">
                    {!capturing ? (
                      <div className="flex flex-col items-center justify-center h-full bg-muted">
                        <Camera className="h-12 w-12 text-muted-foreground mb-2" />
                        <p className="text-muted-foreground">اضغط على زر البدء لتشغيل الكاميرا</p>
                      </div>
                    ) : (
                      <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        className="w-full h-full object-cover"
                      />
                    )}
                    
                    <canvas ref={canvasRef} className="hidden" />
                    
                    {capturing && (
                      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                        <Button 
                          onClick={captureImage} 
                          size="lg" 
                          className="rounded-full h-16 w-16 flex items-center justify-center"
                        >
                          <span className="sr-only">التقاط صورة</span>
                          <div className="h-12 w-12 rounded-full border-2 border-white" />
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-3 my-4">
                    {capturedImages.slice(-8).map((img, idx) => (
                      <div key={idx} className="relative w-20 h-20 rounded overflow-hidden">
                        <img src={img} alt={`صفحة ${idx + 1}`} className="object-cover w-full h-full" />
                        <Button
                          variant="destructive"
                          size="icon"
                          className="absolute top-1 right-1 h-5 w-5 rounded-full"
                          onClick={() => {
                            setCapturedImages(prev => prev.filter((_, i) => i !== idx));
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                    
                    {capturedImages.length > 8 && (
                      <div className="flex items-center justify-center w-20 h-20 bg-muted rounded">
                        <span className="text-muted-foreground">+{capturedImages.length - 8}</span>
                      </div>
                    )}
                    
                    {capturedImages.length === 0 && (
                      <div className="w-full text-center py-8 text-muted-foreground">
                        لم يتم التقاط أي صور بعد
                      </div>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium mb-1">عدد الصفحات الملتقطة</p>
                      <p className="text-2xl font-bold">{capturedImages.length}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-1">حجم الدفعة</p>
                      <Select
                        value={importOptions.batchSize.toString()}
                        onValueChange={(value) => {
                          setImportOptions(prev => ({
                            ...prev,
                            batchSize: parseInt(value, 10)
                          }));
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10 صفحات</SelectItem>
                          <SelectItem value="20">20 صفحة</SelectItem>
                          <SelectItem value="50">50 صفحة</SelectItem>
                          <SelectItem value="100">100 صفحة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  {!capturing ? (
                    <Button onClick={startCamera}>
                      <Camera className="mr-2 h-4 w-4" />
                      بدء الكاميرا
                    </Button>
                  ) : (
                    <Button variant="outline" onClick={stopCamera}>
                      <Ban className="mr-2 h-4 w-4" />
                      إيقاف الكاميرا
                    </Button>
                  )}
                  
                  <Button 
                    variant="secondary" 
                    onClick={() => {
                      if (capturedImages.length > 0) {
                        setCurrentStep(2);
                      } else {
                        toast({
                          title: "لا توجد صور",
                          description: "الرجاء التقاط صور أولاً قبل المتابعة",
                          variant: "destructive"
                        });
                      }
                    }}
                    disabled={capturedImages.length === 0}
                  >
                    متابعة
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="files" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>رفع ملفات الكتاب</CardTitle>
                  <CardDescription>
                    يمكنك رفع صور متعددة للصفحات أو ملف PDF للكتاب. سيتم معالجة الملفات تلقائياً.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div 
                    className="border-2 border-dashed border-primary/20 rounded-lg p-8 text-center hover:bg-primary/5 transition-colors cursor-pointer"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      type="file"
                      multiple
                      accept="image/*,.pdf"
                      className="hidden"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                    />
                    
                    <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground mb-2">اسحب وأفلت الملفات هنا أو انقر للاختيار</p>
                    <p className="text-xs text-muted-foreground">PNG, JPG, PDF حتى 100MB</p>
                  </div>
                  
                  {selectedFiles.length > 0 && (
                    <div className="mt-4">
                      <p className="font-medium mb-2">الملفات المختارة ({selectedFiles.length})</p>
                      <div className="space-y-2 max-h-52 overflow-y-auto pr-2">
                        {selectedFiles.map((file, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 bg-muted rounded">
                            <div className="flex items-center">
                              {file.type.includes("pdf") ? (
                                <FileText className="h-5 w-5 mr-2 text-red-500" />
                              ) : (
                                <Image className="h-5 w-5 mr-2 text-blue-500" />
                              )}
                              <span className="text-sm font-medium truncate max-w-[250px]">
                                {file.name}
                              </span>
                            </div>
                            <div className="flex items-center">
                              <span className="text-xs text-muted-foreground mr-2">
                                {(file.size / 1024 / 1024).toFixed(2)} MB
                              </span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedFiles(prev => prev.filter((_, i) => i !== idx));
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div>
                      <p className="text-sm font-medium mb-1">عدد الملفات</p>
                      <p className="text-2xl font-bold">{selectedFiles.length}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-1">حجم الدفعة</p>
                      <Select
                        value={importOptions.batchSize.toString()}
                        onValueChange={(value) => {
                          setImportOptions(prev => ({
                            ...prev,
                            batchSize: parseInt(value, 10)
                          }));
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10 ملفات</SelectItem>
                          <SelectItem value="20">20 ملف</SelectItem>
                          <SelectItem value="50">50 ملف</SelectItem>
                          <SelectItem value="100">100 ملف</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Plus className="mr-2 h-4 w-4" />
                    اختيار ملفات
                  </Button>
                  
                  <Button 
                    variant="secondary" 
                    onClick={() => {
                      if (selectedFiles.length > 0) {
                        setCurrentStep(2);
                      } else {
                        toast({
                          title: "لا توجد ملفات",
                          description: "الرجاء اختيار ملفات أولاً قبل المتابعة",
                          variant: "destructive"
                        });
                      }
                    }}
                    disabled={selectedFiles.length === 0}
                  >
                    متابعة
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="advanced" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>خيارات استيراد متقدمة</CardTitle>
                  <CardDescription>
                    ضبط إعدادات استيراد الكتاب لتحسين النتائج وتخصيص المعالجة.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bookTitle">عنوان الكتاب</Label>
                    <Input 
                      id="bookTitle" 
                      placeholder="أدخل عنوان الكتاب" 
                      value={bookDetails.title}
                      onChange={(e) => setBookDetails(prev => ({ ...prev, title: e.target.value }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="bookAuthor">اسم المؤلف</Label>
                    <Input 
                      id="bookAuthor" 
                      placeholder="أدخل اسم المؤلف" 
                      value={bookDetails.author}
                      onChange={(e) => setBookDetails(prev => ({ ...prev, author: e.target.value }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="bookLanguage">اللغة</Label>
                    <Select 
                      value={bookDetails.language}
                      onValueChange={(value) => setBookDetails(prev => ({ ...prev, language: value }))}
                    >
                      <SelectTrigger id="bookLanguage">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="en">الإنجليزية</SelectItem>
                        <SelectItem value="fr">الفرنسية</SelectItem>
                        <SelectItem value="ur">الأردية</SelectItem>
                        <SelectItem value="tr">التركية</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="bookCategory">التصنيف</Label>
                    <Select 
                      value={bookDetails.category}
                      onValueChange={(value) => setBookDetails(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger id="bookCategory">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="academic">أكاديمي</SelectItem>
                        <SelectItem value="religious">ديني</SelectItem>
                        <SelectItem value="scientific">علمي</SelectItem>
                        <SelectItem value="literary">أدبي</SelectItem>
                        <SelectItem value="historical">تاريخي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="pt-4">
                    <h3 className="font-medium mb-3">خيارات المعالجة</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="autoDetectChapters" className="font-medium">
                            الكشف التلقائي عن الفصول
                          </Label>
                          <p className="text-sm text-muted-foreground">
                            سيحاول النظام تحديد بداية الفصول تلقائياً
                          </p>
                        </div>
                        <Switch 
                          id="autoDetectChapters" 
                          checked={importOptions.autoDetectChapters}
                          onCheckedChange={(checked) => {
                            setImportOptions(prev => ({ ...prev, autoDetectChapters: checked }));
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="enhanceTextQuality" className="font-medium">
                            تحسين جودة النص
                          </Label>
                          <p className="text-sm text-muted-foreground">
                            تطبيق تحسينات على الصور لزيادة دقة استخراج النص
                          </p>
                        </div>
                        <Switch 
                          id="enhanceTextQuality" 
                          checked={importOptions.enhanceTextQuality}
                          onCheckedChange={(checked) => {
                            setImportOptions(prev => ({ ...prev, enhanceTextQuality: checked }));
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="extractImages" className="font-medium">
                            استخراج الصور
                          </Label>
                          <p className="text-sm text-muted-foreground">
                            استخراج الصور من الكتاب وحفظها بشكل منفصل
                          </p>
                        </div>
                        <Switch 
                          id="extractImages" 
                          checked={importOptions.extractImages}
                          onCheckedChange={(checked) => {
                            setImportOptions(prev => ({ ...prev, extractImages: checked }));
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="preserveLayout" className="font-medium">
                            الحفاظ على تخطيط الصفحة
                          </Label>
                          <p className="text-sm text-muted-foreground">
                            الحفاظ على التنسيق الأصلي للصفحات بدلاً من تحويلها إلى نص عادي
                          </p>
                        </div>
                        <Switch 
                          id="preserveLayout" 
                          checked={importOptions.preserveLayout}
                          onCheckedChange={(checked) => {
                            setImportOptions(prev => ({ ...prev, preserveLayout: checked }));
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button 
                    variant="secondary" 
                    onClick={() => {
                      // Переход к шагу 2 возможен, если заполнены минимальные детали
                      if (bookDetails.title && bookDetails.author) {
                        setCurrentStep(2);
                      } else {
                        toast({
                          title: "بيانات غير مكتملة",
                          description: "الرجاء إدخال عنوان الكتاب واسم المؤلف على الأقل",
                          variant: "destructive"
                        });
                      }
                    }}
                  >
                    متابعة
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </>
        )}
        
        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>معالجة الكتاب</CardTitle>
              <CardDescription>
                جاري معالجة الملفات وتحويلها إلى كتاب. هذه العملية قد تستغرق بعض الوقت حسب حجم الكتاب.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center p-6">
                  {processing ? (
                    <>
                      <RefreshCw className="h-16 w-16 mx-auto animate-spin text-primary mb-4" />
                      <h3 className="text-xl font-bold mb-2">جاري معالجة الملفات...</h3>
                      <p className="text-muted-foreground mb-4">
                        يرجى الانتظار أثناء معالجة {(selectedFiles.length || capturedImages.length)} ملف/صورة
                      </p>
                    </>
                  ) : (
                    <>
                      <BookCopy className="h-16 w-16 mx-auto text-primary mb-4" />
                      <h3 className="text-xl font-bold mb-2">جاهز للمعالجة</h3>
                      <p className="text-muted-foreground mb-4">
                        اضغط على زر "بدء المعالجة" لبدء استيراد وتحليل الكتاب
                      </p>
                    </>
                  )}
                  
                  <Progress value={progress} className="mb-2" />
                  <p className="text-sm text-muted-foreground">{progress}% مكتمل</p>
                </div>
                
                <div className="bg-muted/30 rounded-lg p-4">
                  <h4 className="font-medium mb-2">ملخص المعالجة</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">عدد الصفحات</p>
                      <p className="font-medium">{selectedFiles.length || capturedImages.length}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">حجم الدفعة</p>
                      <p className="font-medium">{importOptions.batchSize} صفحة</p>
                    </div>
                    
                    <div className="col-span-2">
                      <p className="text-sm text-muted-foreground">عنوان الكتاب</p>
                      <p className="font-medium">{bookDetails.title || "غير محدد"}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">المؤلف</p>
                      <p className="font-medium">{bookDetails.author || "غير محدد"}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">اللغة</p>
                      <p className="font-medium">
                        {bookDetails.language === "ar" ? "العربية" : 
                         bookDetails.language === "en" ? "الإنجليزية" : 
                         bookDetails.language === "fr" ? "الفرنسية" : 
                         bookDetails.language === "ur" ? "الأردية" : 
                         bookDetails.language === "tr" ? "التركية" : "غير محدد"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => setCurrentStep(1)}
                disabled={processing}
              >
                <ChevronRight className="ml-2 h-4 w-4" />
                رجوع
              </Button>
              
              {!processing ? (
                <Button 
                  onClick={handleBulkUpload}
                  disabled={selectedFiles.length === 0 && capturedImages.length === 0}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  بدء المعالجة
                </Button>
              ) : (
                <Button disabled>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  جاري المعالجة...
                </Button>
              )}
            </CardFooter>
          </Card>
        )}
        
        {currentStep === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>اكتمل الاستيراد</CardTitle>
              <CardDescription>
                تم استيراد الكتاب بنجاح وهو جاهز الآن للاستخدام في التطبيق.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center p-6">
                {processingResults?.success ? (
                  <>
                    <div className="bg-primary/10 p-4 rounded-full inline-block mb-4">
                      <Check className="h-16 w-16 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">تم الاستيراد بنجاح!</h3>
                    <p className="text-muted-foreground">
                      تم استيراد {processingResults.pageCount} صفحة بنجاح وإضافتها إلى المكتبة.
                    </p>
                  </>
                ) : (
                  <>
                    <div className="bg-destructive/10 p-4 rounded-full inline-block mb-4">
                      <Ban className="h-16 w-16 text-destructive" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">حدث خطأ أثناء الاستيراد</h3>
                    <p className="text-muted-foreground">
                      {processingResults?.errorMessage || "حدث خطأ غير معروف أثناء معالجة الكتاب."}
                    </p>
                  </>
                )}
              </div>
              
              {processingResults?.success && (
                <div className="bg-muted/30 rounded-lg p-4 mt-6">
                  <h4 className="font-medium mb-2">تفاصيل الكتاب المستورد</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <p className="text-sm text-muted-foreground">عنوان الكتاب</p>
                      <p className="font-medium">{bookDetails.title || "غير محدد"}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">المؤلف</p>
                      <p className="font-medium">{bookDetails.author || "غير محدد"}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">عدد الصفحات</p>
                      <p className="font-medium">{processingResults.pageCount}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">اللغة</p>
                      <p className="font-medium">
                        {bookDetails.language === "ar" ? "العربية" : 
                         bookDetails.language === "en" ? "الإنجليزية" : 
                         bookDetails.language === "fr" ? "الفرنسية" : 
                         bookDetails.language === "ur" ? "الأردية" : 
                         bookDetails.language === "tr" ? "التركية" : "غير محدد"}
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">التصنيف</p>
                      <p className="font-medium">
                        {bookDetails.category === "academic" ? "أكاديمي" : 
                         bookDetails.category === "religious" ? "ديني" : 
                         bookDetails.category === "scientific" ? "علمي" : 
                         bookDetails.category === "literary" ? "أدبي" : 
                         bookDetails.category === "historical" ? "تاريخي" : "غير محدد"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              {!processingResults?.success && (
                <Button 
                  variant="outline" 
                  onClick={() => setCurrentStep(2)}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  إعادة المحاولة
                </Button>
              )}
              
              <Button 
                onClick={handleComplete}
                className={processingResults?.success ? "w-full" : ""}
              >
                {processingResults?.success ? (
                  <>
                    <BookOpen className="mr-2 h-4 w-4" />
                    الانتقال إلى المكتبة
                  </>
                ) : (
                  "إغلاق"
                )}
              </Button>
            </CardFooter>
          </Card>
        )}
      </Tabs>
    </div>
  );
}