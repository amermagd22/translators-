import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { 
  Translation,
  fetchTranslationHistory
} from "@/lib/translation";
import { formatRelativeTime, getLanguageDirection, getLanguageFontClass } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { MoreVertical, Copy, Trash, Volume2 } from "lucide-react";
import { useSpeechSynthesis } from "@/hooks/use-speech";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useTranslation } from "react-i18next";

interface RecentTranslationsProps {
  limit?: number;
  showViewAll?: boolean;
}

export function RecentTranslations({
  limit = 2,
  showViewAll = true
}: RecentTranslationsProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { speak } = useSpeechSynthesis();
  
  const { data: translations, isLoading, error } = useQuery({
    queryKey: ["/api/translations", limit],
    queryFn: () => fetchTranslationHistory(limit),
    refetchOnWindowFocus: false
  });
  
  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        description: "تم نسخ النص",
      });
    } catch (err) {
      toast({
        title: "فشل نسخ النص",
        description: "يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    }
  };
  
  const handleDelete = async (id: number) => {
    // In a real implementation, we would call an API to delete the translation
    toast({
      description: "تم حذف الترجمة"
    });
    
    // Invalidate the query to refetch
    queryClient.invalidateQueries({ queryKey: ["/api/translations"] });
  };
  
  const handleSpeak = (text: string, language: string) => {
    speak(text, { language });
  };
  
  // Helper to get translation badge color
  const getBadgeColor = (source: string, target: string) => {
    if (source === 'ar') return 'bg-primary/10 text-primary';
    if (target === 'ar') return 'bg-secondary/10 text-secondary';
    return 'bg-accent/10 text-accent';
  };
  
  if (isLoading) {
    return (
      <div className="mt-8 mb-16">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">{t("translations.recent")}</h3>
          {showViewAll && (
            <Link href="/history">
              <Button variant="link" className="text-primary text-sm font-medium">
                {t("translations.viewAll")}
              </Button>
            </Link>
          )}
        </div>
        <div className="space-y-3">
          {[1, 2].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-full mb-4"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="mt-8 mb-16">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">{t("translations.recent")}</h3>
        </div>
        <Card>
          <CardContent className="p-6 text-center text-destructive">
            {t("translations.error")}
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (!translations || translations.length === 0) {
    return (
      <div className="mt-8 mb-16">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">{t("translations.recent")}</h3>
        </div>
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            {t("translations.empty")}
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="mt-8 mb-16">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">{t("translations.recent")}</h3>
        {showViewAll && translations.length > 0 && (
          <Link href="/history">
            <Button variant="link" className="text-primary text-sm font-medium">
              {t("translations.viewAll")}
            </Button>
          </Link>
        )}
      </div>
      
      <div className="space-y-3">
        {translations.map((translation) => {
          const sourceLangDirection = getLanguageDirection(translation.sourceLanguage);
          const targetLangDirection = getLanguageDirection(translation.targetLanguage);
          const sourceLangFont = getLanguageFontClass(translation.sourceLanguage);
          const targetLangFont = getLanguageFontClass(translation.targetLanguage);
          
          return (
            <Card key={translation.id} className="shadow-sm hover:shadow-md transition">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center">
                    <span className={`text-xs font-medium rounded-full px-2 py-0.5 ml-2 ${
                      getBadgeColor(translation.sourceLanguage, translation.targetLanguage)
                    }`}>
                      {translation.sourceLanguage} → {translation.targetLanguage}
                    </span>
                    <span className="text-xs text-gray-500">
                      {formatRelativeTime(translation.createdAt)}
                    </span>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleCopy(translation.sourceText)}>
                        <Copy className="ml-2 h-4 w-4" />
                        <span>{t("actions.copySource")}</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleCopy(translation.translatedText)}>
                        <Copy className="ml-2 h-4 w-4" />
                        <span>{t("actions.copyTranslation")}</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleSpeak(translation.sourceText, translation.sourceLanguage)}>
                        <Volume2 className="ml-2 h-4 w-4" />
                        <span>{t("actions.speakSource")}</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleSpeak(translation.translatedText, translation.targetLanguage)}>
                        <Volume2 className="ml-2 h-4 w-4" />
                        <span>{t("actions.speakTranslation")}</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDelete(translation.id)}>
                        <Trash className="ml-2 h-4 w-4" />
                        <span>{t("actions.delete")}</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="mb-2">
                  <p className={`text-sm text-gray-800 ${sourceLangFont}`} dir={sourceLangDirection}>
                    {translation.sourceText}
                  </p>
                </div>
                <div className="pt-2 border-t border-gray-100">
                  <p className={`text-sm text-gray-600 ${targetLangFont}`} dir={targetLangDirection}>
                    {translation.translatedText}
                  </p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
