import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { useCamera } from "@/hooks/use-camera";
import { useTranslation } from "react-i18next";
import { X, Camera, Image } from "lucide-react";

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (imageSrc: string) => void;
}

export function CameraModal({
  isOpen,
  onClose,
  onCapture
}: CameraModalProps) {
  const { t } = useTranslation();
  
  // Camera hook
  const {
    isActive,
    isCapturing,
    hasPermission,
    videoRef,
    previewUrl,
    startCamera,
    stopCamera,
    capturePhoto,
    discardPhoto,
    isSupported
  } = useCamera({
    onSuccess: (imageSrc) => {
      onCapture(imageSrc);
      onClose();
    }
  });
  
  // Start camera when modal opens
  useEffect(() => {
    if (isOpen && isSupported) {
      startCamera();
    }
    
    // Cleanup on close
    return () => {
      stopCamera();
    };
  }, [isOpen, isSupported, startCamera, stopCamera]);
  
  // Handle close
  const handleClose = () => {
    stopCamera();
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="sm:max-w-md p-0">
        <DialogHeader className="p-4 bg-black text-white">
          <DialogTitle>{t("camera.modalTitle")}</DialogTitle>
          <DialogClose asChild>
            <Button variant="ghost" size="icon" className="absolute right-4 top-4 text-white" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogClose>
        </DialogHeader>
        
        <div className="bg-black h-full flex flex-col">
          <div className="flex-1 flex items-center justify-center p-4">
            {!isSupported ? (
              <div className="text-center py-8 text-white">
                <Image className="h-16 w-16 mx-auto text-gray-500 mb-4" />
                <p>{t("camera.notSupported")}</p>
              </div>
            ) : hasPermission === false ? (
              <div className="text-center py-8 text-white">
                <Camera className="h-16 w-16 mx-auto text-gray-500 mb-4" />
                <p>{t("camera.permissionDenied")}</p>
                <Button className="mt-4" onClick={startCamera}>
                  {t("camera.requestPermission")}
                </Button>
              </div>
            ) : previewUrl ? (
              <div className="w-full">
                <img 
                  src={previewUrl} 
                  alt={t("camera.capturedImage")} 
                  className="w-full max-h-96 object-contain"
                />
              </div>
            ) : (
              <div className="relative w-full">
                {isActive ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-64 md:h-80 object-cover rounded-lg"
                  ></video>
                ) : (
                  <div className="w-full h-64 md:h-80 bg-gray-900 flex items-center justify-center rounded-lg">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="p-6 flex justify-center">
            {previewUrl ? (
              <div className="flex space-x-2">
                <Button variant="outline" onClick={discardPhoto} className="text-white border-white">
                  {t("camera.retake")}
                </Button>
                <Button onClick={() => onCapture(previewUrl)} className="bg-primary text-white">
                  {t("camera.use")}
                </Button>
              </div>
            ) : (
              isActive && (
                <Button 
                  onClick={capturePhoto} 
                  disabled={isCapturing}
                  className="w-16 h-16 bg-white rounded-full flex items-center justify-center"
                >
                  <div className="w-14 h-14 border-4 border-primary rounded-full"></div>
                </Button>
              )
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
