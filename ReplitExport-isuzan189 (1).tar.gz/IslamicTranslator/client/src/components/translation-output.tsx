import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getLanguageDirection, getLanguageFontClass } from "@/lib/utils";
import { Copy, Share2, Volume2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSpeechSynthesis } from "@/hooks/use-speech";

interface TranslationOutputProps {
  translatedText: string;
  targetLanguage: string;
  isTranslating: boolean;
}

export function TranslationOutput({
  translatedText,
  targetLanguage,
  isTranslating
}: TranslationOutputProps) {
  const [isShareSupported, setIsShareSupported] = useState(false);
  const { toast } = useToast();
  const { speak, isSpeaking } = useSpeechSynthesis({
    language: targetLanguage,
    onError: (error) => {
      toast({
        title: "خطأ في القراءة",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  useEffect(() => {
    // Check if Web Share API is supported
    setIsShareSupported(!!navigator.share);
  }, []);
  
  const handleCopy = async () => {
    if (!translatedText.trim()) return;
    
    try {
      await navigator.clipboard.writeText(translatedText);
      toast({
        description: "تم نسخ النص المترجم",
      });
    } catch (err) {
      toast({
        title: "فشل نسخ النص",
        description: "يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    }
  };
  
  const handleShare = async () => {
    if (!translatedText.trim() || !isShareSupported) return;
    
    try {
      await navigator.share({
        title: "مشاركة الترجمة",
        text: translatedText
      });
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        toast({
          title: "فشل المشاركة",
          description: (err as Error).message,
          variant: "destructive",
        });
      }
    }
  };
  
  const handleSpeak = () => {
    if (!translatedText.trim()) return;
    
    speak(translatedText);
  };
  
  const outputDirection = getLanguageDirection(targetLanguage);
  const outputFontClass = getLanguageFontClass(targetLanguage);
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-medium text-gray-700">الترجمة</h2>
      </div>
      
      <div className="relative">
        {isTranslating ? (
          <div className="w-full min-h-[120px] p-3 bg-gray-50 border border-gray-200 rounded-lg">
            <Skeleton className="h-6 w-3/4 mb-2" />
            <Skeleton className="h-6 w-1/2 mb-2" />
            <Skeleton className="h-6 w-5/6" />
          </div>
        ) : (
          <div
            className={`w-full min-h-[120px] max-h-[300px] p-3 bg-gray-50 border border-gray-200 rounded-lg overflow-y-auto ${outputFontClass}`}
            dir={outputDirection}
          >
            {translatedText ? (
              <p className="text-gray-800 whitespace-pre-line">{translatedText}</p>
            ) : (
              <p className="text-gray-500 italic">الترجمة ستظهر هنا...</p>
            )}
          </div>
        )}
        
        <div className="absolute bottom-3 right-3 flex space-x-reverse space-x-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCopy}
            disabled={!translatedText.trim() || isTranslating}
            className="text-gray-500 hover:text-primary"
          >
            <Copy className="h-4 w-4" />
          </Button>
          
          {isShareSupported && (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleShare}
              disabled={!translatedText.trim() || isTranslating}
              className="text-gray-500 hover:text-primary"
            >
              <Share2 className="h-4 w-4" />
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            onClick={handleSpeak}
            disabled={!translatedText.trim() || isTranslating}
            className={`text-gray-500 hover:text-primary ${isSpeaking ? 'text-primary' : ''}`}
          >
            <Volume2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
