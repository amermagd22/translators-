
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

export function Home() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>الدعوة الإسلامية</Text>
      
      <View style={styles.menuGrid}>
        <TouchableOpacity style={styles.menuItem}>
          <MaterialIcons name="question-answer" size={32} color="#4CAF50" />
          <Text style={styles.menuText}>الأسئلة الشائعة</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <MaterialIcons name="library-books" size={32} color="#2196F3" />
          <Text style={styles.menuText}>المكتبة الإسلامية</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <MaterialIcons name="people" size={32} color="#9C27B0" />
          <Text style={styles.menuText}>جهات الاتصال</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <MaterialIcons name="analytics" size={32} color="#FF9800" />
          <Text style={styles.menuText}>الإحصائيات</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.menuItem}>
          <MaterialIcons name="camera-alt" size={32} color="#795548" />
          <Text style={styles.menuText}>الترجمة بالكاميرا</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.menuItem}>
          <MaterialIcons name="mic" size={32} color="#607D8B" />
          <Text style={styles.menuText}>الترجمة الصوتية</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#000',
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  menuItem: {
    width: '45%',
    backgroundColor: '#f5f5f5',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
    elevation: 3,
  },
  menuText: {
    marginTop: 10,
    fontSize: 16,
    textAlign: 'center',
    color: '#333',
  },
});
