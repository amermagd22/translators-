
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';

import Home from './screens/Home';
import Conversation from './screens/Conversation';
import Camera from './screens/Camera';
import Profile from './screens/Profile';
import Settings from './screens/Settings';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;
              switch (route.name) {
                case 'الرئيسية':
                  iconName = 'home';
                  break;
                case 'المحادثة':
                  iconName = 'chat';
                  break;
                case 'الكاميرا':
                  iconName = 'camera';
                  break;
                case 'الملف':
                  iconName = 'person';
                  break;
                case 'الإعدادات':
                  iconName = 'settings';
                  break;
                default:
                  iconName = 'circle';
              }
              return <MaterialIcons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: '#4CAF50',
            tabBarInactiveTintColor: 'gray',
          })}
        >
          <Tab.Screen name="الرئيسية" component={Home} />
          <Tab.Screen name="المحادثة" component={Conversation} />
          <Tab.Screen name="الكاميرا" component={Camera} />
          <Tab.Screen name="الملف" component={Profile} />
          <Tab.Screen name="الإعدادات" component={Settings} />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
