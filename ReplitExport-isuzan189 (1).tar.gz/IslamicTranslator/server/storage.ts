import { 
  User, InsertUser, 
  Translation, InsertTranslation,
  Language, InsertLanguage, 
  Settings, InsertSettings,
  ProhibitedWord, InsertProhibitedWord,
  Stat, InsertStat,
  Lesson, InsertLesson,
  Quiz, InsertQuiz,
  Question, InsertQuestion,
  UserProgress, InsertUserProgress,
  languages, translations, users, settings, prohibitedWords, stats,
  lessons, quizzes, questions, userProgress
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Translation operations
  createTranslation(translation: InsertTranslation): Promise<Translation>;
  getTranslations(userId?: number, limit?: number): Promise<Translation[]>;
  getTranslationById(id: number): Promise<Translation | undefined>;
  
  // Language operations
  getLanguages(): Promise<Language[]>;
  getLanguageByCode(code: string): Promise<Language | undefined>;
  createLanguage(language: InsertLanguage): Promise<Language>;
  
  // Settings operations
  getSettings(userId: number): Promise<Settings | undefined>;
  createOrUpdateSettings(settings: InsertSettings): Promise<Settings>;
  
  // Content filtering
  getProhibitedWords(language?: string): Promise<ProhibitedWord[]>;
  createProhibitedWord(word: InsertProhibitedWord): Promise<ProhibitedWord>;
  
  // Stats
  updateStats(stat: InsertStat): Promise<Stat>;
  getDailyStats(days: number): Promise<Stat[]>;
  
  // Educational content operations
  // Lessons
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  getLessonsByBookId(bookId: string): Promise<Lesson[]>;
  getLessonById(id: number): Promise<Lesson | undefined>;
  updateLesson(id: number, lesson: Partial<InsertLesson>): Promise<Lesson>;
  deleteLesson(id: number): Promise<boolean>;
  
  // Quizzes
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  getQuizzesByBookId(bookId: string): Promise<Quiz[]>;
  getQuizzesByLessonId(lessonId: number): Promise<Quiz[]>;
  getQuizById(id: number): Promise<Quiz | undefined>;
  updateQuiz(id: number, quiz: Partial<InsertQuiz>): Promise<Quiz>;
  deleteQuiz(id: number): Promise<boolean>;
  
  // Questions
  createQuestion(question: InsertQuestion): Promise<Question>;
  getQuestionsByQuizId(quizId: number): Promise<Question[]>;
  getQuestionById(id: number): Promise<Question | undefined>;
  updateQuestion(id: number, question: Partial<InsertQuestion>): Promise<Question>;
  deleteQuestion(id: number): Promise<boolean>;
  
  // User Progress
  createOrUpdateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  getUserProgressByUserId(userId: number): Promise<UserProgress[]>;
  getUserProgressByBookId(userId: number, bookId: string): Promise<UserProgress | undefined>;
  getUserProgressByLessonId(userId: number, lessonId: number): Promise<UserProgress | undefined>;
  getUserProgressByQuizId(userId: number, quizId: number): Promise<UserProgress | undefined>;
  
  // Educational Media (presentations and videos)
  createEducationalMedia(media: InsertEducationalMedia): Promise<EducationalMedia>;
  getEducationalMediaByLessonId(lessonId: number): Promise<EducationalMedia[]>;
  getEducationalMediaById(id: number): Promise<EducationalMedia | undefined>;
  updateEducationalMedia(id: number, media: Partial<InsertEducationalMedia>): Promise<EducationalMedia>;
  deleteEducationalMedia(id: number): Promise<boolean>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private translations: Map<number, Translation>;
  private languagesList: Map<number, Language>;
  private userSettings: Map<number, Settings>;
  private prohibitedWordsList: Map<number, ProhibitedWord>;
  private statsList: Map<number, Stat>;
  
  // Educational content collections
  private lessonsList: Map<number, Lesson>;
  private quizzesList: Map<number, Quiz>;
  private questionsList: Map<number, Question>;
  private userProgressList: Map<number, UserProgress>;
  private educationalMediaList: Map<number, EducationalMedia>;
  
  private userCurrentId: number;
  private translationCurrentId: number;
  private languageCurrentId: number;
  private settingsCurrentId: number;
  private prohibitedWordCurrentId: number;
  private statsCurrentId: number;
  private lessonCurrentId: number;
  private quizCurrentId: number;
  private questionCurrentId: number;
  private userProgressCurrentId: number;
  private educationalMediaCurrentId: number;

  constructor() {
    this.users = new Map();
    this.translations = new Map();
    this.languagesList = new Map();
    this.userSettings = new Map();
    this.prohibitedWordsList = new Map();
    this.statsList = new Map();
    
    // Initialize educational content maps
    this.lessonsList = new Map();
    this.quizzesList = new Map();
    this.questionsList = new Map();
    this.userProgressList = new Map();
    this.educationalMediaList = new Map();
    
    this.userCurrentId = 1;
    this.translationCurrentId = 1;
    this.languageCurrentId = 1;
    this.settingsCurrentId = 1;
    this.prohibitedWordCurrentId = 1;
    this.statsCurrentId = 1;
    this.lessonCurrentId = 1;
    this.quizCurrentId = 1;
    this.questionCurrentId = 1;
    this.userProgressCurrentId = 1;
    this.educationalMediaCurrentId = 1;
    
    // Initialize with predefined languages
    this.initializeLanguages();
    // Initialize with predefined prohibited words
    this.initializeProhibitedWords();
  }

  // Initialize common languages
  private initializeLanguages() {
    const predefinedLanguages: InsertLanguage[] = [
      { code: 'ar', name: 'Arabic', nativeName: 'العربية', direction: 'rtl', flagCode: 'SA' },
      { code: 'en', name: 'English', nativeName: 'English', direction: 'ltr', flagCode: 'US' },
      { code: 'fr', name: 'French', nativeName: 'Français', direction: 'ltr', flagCode: 'FR' },
      { code: 'es', name: 'Spanish', nativeName: 'Español', direction: 'ltr', flagCode: 'ES' },
      { code: 'zh', name: 'Chinese', nativeName: '中文', direction: 'ltr', flagCode: 'CN' },
      { code: 'ur', name: 'Urdu', nativeName: 'اردو', direction: 'rtl', flagCode: 'PK' },
      { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', direction: 'ltr', flagCode: 'IN' },
      { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', direction: 'ltr', flagCode: 'TR' },
      { code: 'fa', name: 'Persian', nativeName: 'فارسی', direction: 'rtl', flagCode: 'IR' },
      { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', direction: 'ltr', flagCode: 'ID' },
    ];
    
    predefinedLanguages.forEach(lang => this.createLanguage(lang));
  }

  // Initialize prohibited words for content filtering based on Islamic values
  private initializeProhibitedWords() {
    const prohibitedWords: InsertProhibitedWord[] = [
      // English prohibited words
      { word: 'alcohol', language: 'en', category: 'substance', replacement: '[filtered substance]' },
      { word: 'pork', language: 'en', category: 'food', replacement: '[filtered food]' },
      { word: 'gambling', language: 'en', category: 'activity', replacement: '[filtered activity]' },
      { word: 'dating', language: 'en', category: 'relationship', replacement: 'meeting' },
      { word: 'boyfriend', language: 'en', category: 'relationship', replacement: 'friend' },
      { word: 'girlfriend', language: 'en', category: 'relationship', replacement: 'friend' },
      { word: 'beer', language: 'en', category: 'substance', replacement: '[filtered beverage]' },
      { word: 'wine', language: 'en', category: 'substance', replacement: '[filtered beverage]' },
      { word: 'vodka', language: 'en', category: 'substance', replacement: '[filtered beverage]' },
      { word: 'whiskey', language: 'en', category: 'substance', replacement: '[filtered beverage]' },
      { word: 'pork chop', language: 'en', category: 'food', replacement: '[filtered food]' },
      { word: 'bacon', language: 'en', category: 'food', replacement: '[filtered food]' },
      { word: 'ham', language: 'en', category: 'food', replacement: '[filtered food]' },
      { word: 'casino', language: 'en', category: 'place', replacement: '[filtered place]' },
      { word: 'lottery', language: 'en', category: 'activity', replacement: '[filtered activity]' },
      { word: 'bet', language: 'en', category: 'activity', replacement: '[filtered activity]' },
      
      // Arabic prohibited words
      { word: 'الكحول', language: 'ar', category: 'substance', replacement: '[مادة تم تصفيتها]' },
      { word: 'الخنزير', language: 'ar', category: 'food', replacement: '[طعام تم تصفيته]' },
      { word: 'القمار', language: 'ar', category: 'activity', replacement: '[نشاط تم تصفيته]' },
      { word: 'المواعدة', language: 'ar', category: 'relationship', replacement: 'لقاء' },
      { word: 'صديقي', language: 'ar', category: 'relationship', replacement: 'صديق' },
      { word: 'صديقتي', language: 'ar', category: 'relationship', replacement: 'صديقة' },
      { word: 'بيرة', language: 'ar', category: 'substance', replacement: '[مشروب تم تصفيته]' },
      { word: 'نبيذ', language: 'ar', category: 'substance', replacement: '[مشروب تم تصفيته]' },
      { word: 'فودكا', language: 'ar', category: 'substance', replacement: '[مشروب تم تصفيته]' },
      { word: 'ويسكي', language: 'ar', category: 'substance', replacement: '[مشروب تم تصفيته]' },
      { word: 'لحم خنزير', language: 'ar', category: 'food', replacement: '[طعام تم تصفيته]' },
      { word: 'مقامرة', language: 'ar', category: 'activity', replacement: '[نشاط تم تصفيته]' },
      { word: 'كازينو', language: 'ar', category: 'place', replacement: '[مكان تم تصفيته]' },
      { word: 'يانصيب', language: 'ar', category: 'activity', replacement: '[نشاط تم تصفيته]' },
      { word: 'رهان', language: 'ar', category: 'activity', replacement: '[نشاط تم تصفيته]' },
    ];
    
    prohibitedWords.forEach(word => this.createProhibitedWord(word));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  // Translation methods
  async createTranslation(translation: InsertTranslation): Promise<Translation> {
    const id = this.translationCurrentId++;
    const now = new Date();
    const newTranslation: Translation = { ...translation, id, createdAt: now };
    this.translations.set(id, newTranslation);
    return newTranslation;
  }

  async getTranslations(userId?: number, limit?: number): Promise<Translation[]> {
    let result = Array.from(this.translations.values());
    
    if (userId) {
      result = result.filter(t => t.userId === userId);
    }
    
    // Sort by creation date, newest first
    result.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (limit) {
      result = result.slice(0, limit);
    }
    
    return result;
  }

  async getTranslationById(id: number): Promise<Translation | undefined> {
    return this.translations.get(id);
  }

  // Language methods
  async getLanguages(): Promise<Language[]> {
    return Array.from(this.languagesList.values());
  }

  async getLanguageByCode(code: string): Promise<Language | undefined> {
    return Array.from(this.languagesList.values()).find(
      (lang) => lang.code === code,
    );
  }

  async createLanguage(language: InsertLanguage): Promise<Language> {
    const id = this.languageCurrentId++;
    const newLanguage: Language = { ...language, id };
    this.languagesList.set(id, newLanguage);
    return newLanguage;
  }

  // Settings methods
  async getSettings(userId: number): Promise<Settings | undefined> {
    return Array.from(this.userSettings.values()).find(
      (setting) => setting.userId === userId,
    );
  }

  async createOrUpdateSettings(setting: InsertSettings): Promise<Settings> {
    // Check if settings already exist for the user
    const existingSettings = await this.getSettings(setting.userId);
    
    if (existingSettings) {
      // Update existing settings
      const updatedSettings: Settings = { ...existingSettings, ...setting };
      this.userSettings.set(existingSettings.id, updatedSettings);
      return updatedSettings;
    } else {
      // Create new settings
      const id = this.settingsCurrentId++;
      const newSettings: Settings = { ...setting, id };
      this.userSettings.set(id, newSettings);
      return newSettings;
    }
  }

  // Content filtering methods
  async getProhibitedWords(language?: string): Promise<ProhibitedWord[]> {
    let words = Array.from(this.prohibitedWordsList.values());
    
    if (language) {
      words = words.filter(word => word.language === language);
    }
    
    return words;
  }

  async createProhibitedWord(word: InsertProhibitedWord): Promise<ProhibitedWord> {
    const id = this.prohibitedWordCurrentId++;
    const newWord: ProhibitedWord = { ...word, id };
    this.prohibitedWordsList.set(id, newWord);
    return newWord;
  }

  // Stats methods
  async updateStats(statData: InsertStat): Promise<Stat> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Find today's stats if they exist
    const todayStats = Array.from(this.statsList.values()).find(
      s => s.date.getTime() === today.getTime()
    );
    
    if (todayStats) {
      // Update existing stats
      const updatedStats: Stat = {
        ...todayStats,
        textTranslations: todayStats.textTranslations + (statData.textTranslations || 0),
        voiceTranslations: todayStats.voiceTranslations + (statData.voiceTranslations || 0),
        imageTranslations: todayStats.imageTranslations + (statData.imageTranslations || 0),
        totalCharacters: todayStats.totalCharacters + (statData.totalCharacters || 0),
        languageStats: { ...todayStats.languageStats, ...statData.languageStats }
      };
      this.statsList.set(todayStats.id, updatedStats);
      return updatedStats;
    } else {
      // Create new stats for today
      const id = this.statsCurrentId++;
      const newStats: Stat = {
        ...statData,
        id,
        date: today
      };
      this.statsList.set(id, newStats);
      return newStats;
    }
  }

  async getDailyStats(days: number): Promise<Stat[]> {
    const stats = Array.from(this.statsList.values());
    
    // Sort by date, newest first
    stats.sort((a, b) => b.date.getTime() - a.date.getTime());
    
    // Limit to requested number of days
    return stats.slice(0, days);
  }

  // Lesson methods
  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    const id = this.lessonCurrentId++;
    const now = new Date();
    const newLesson: Lesson = { ...lesson, id, createdAt: now };
    this.lessonsList.set(id, newLesson);
    return newLesson;
  }

  async getLessonsByBookId(bookId: string): Promise<Lesson[]> {
    return Array.from(this.lessonsList.values())
      .filter(lesson => lesson.bookId === bookId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getLessonById(id: number): Promise<Lesson | undefined> {
    return this.lessonsList.get(id);
  }

  async updateLesson(id: number, lessonUpdate: Partial<InsertLesson>): Promise<Lesson> {
    const existingLesson = this.lessonsList.get(id);
    if (!existingLesson) {
      throw new Error(`Lesson with id ${id} not found`);
    }

    const updatedLesson: Lesson = { ...existingLesson, ...lessonUpdate };
    this.lessonsList.set(id, updatedLesson);
    return updatedLesson;
  }

  async deleteLesson(id: number): Promise<boolean> {
    return this.lessonsList.delete(id);
  }

  // Quiz methods
  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const id = this.quizCurrentId++;
    const now = new Date();
    const newQuiz: Quiz = { ...quiz, id, createdAt: now };
    this.quizzesList.set(id, newQuiz);
    return newQuiz;
  }

  async getQuizzesByBookId(bookId: string): Promise<Quiz[]> {
    return Array.from(this.quizzesList.values())
      .filter(quiz => quiz.bookId === bookId);
  }

  async getQuizzesByLessonId(lessonId: number): Promise<Quiz[]> {
    return Array.from(this.quizzesList.values())
      .filter(quiz => quiz.lessonId === lessonId);
  }

  async getQuizById(id: number): Promise<Quiz | undefined> {
    return this.quizzesList.get(id);
  }

  async updateQuiz(id: number, quizUpdate: Partial<InsertQuiz>): Promise<Quiz> {
    const existingQuiz = this.quizzesList.get(id);
    if (!existingQuiz) {
      throw new Error(`Quiz with id ${id} not found`);
    }

    const updatedQuiz: Quiz = { ...existingQuiz, ...quizUpdate };
    this.quizzesList.set(id, updatedQuiz);
    return updatedQuiz;
  }

  async deleteQuiz(id: number): Promise<boolean> {
    return this.quizzesList.delete(id);
  }

  // Question methods
  async createQuestion(question: InsertQuestion): Promise<Question> {
    const id = this.questionCurrentId++;
    const now = new Date();
    const newQuestion: Question = { ...question, id, createdAt: now };
    this.questionsList.set(id, newQuestion);
    return newQuestion;
  }

  async getQuestionsByQuizId(quizId: number): Promise<Question[]> {
    return Array.from(this.questionsList.values())
      .filter(question => question.quizId === quizId)
      .sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
  }

  async getQuestionById(id: number): Promise<Question | undefined> {
    return this.questionsList.get(id);
  }

  async updateQuestion(id: number, questionUpdate: Partial<InsertQuestion>): Promise<Question> {
    const existingQuestion = this.questionsList.get(id);
    if (!existingQuestion) {
      throw new Error(`Question with id ${id} not found`);
    }

    const updatedQuestion: Question = { ...existingQuestion, ...questionUpdate };
    this.questionsList.set(id, updatedQuestion);
    return updatedQuestion;
  }

  async deleteQuestion(id: number): Promise<boolean> {
    return this.questionsList.delete(id);
  }

  // User Progress methods
  async createOrUpdateUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    // Try to find existing progress
    let existingProgress: UserProgress | undefined;
    
    if (progress.quizId) {
      existingProgress = await this.getUserProgressByQuizId(progress.userId, progress.quizId);
    } else if (progress.lessonId) {
      existingProgress = await this.getUserProgressByLessonId(progress.userId, progress.lessonId);
    } else if (progress.bookId) {
      existingProgress = await this.getUserProgressByBookId(progress.userId, progress.bookId);
    }
    
    if (existingProgress) {
      // Update existing progress
      const now = new Date();
      const updatedProgress: UserProgress = { 
        ...existingProgress, 
        ...progress,
        lastAccessedAt: now,
        completedAt: progress.completed ? (existingProgress.completedAt || now) : existingProgress.completedAt
      };
      this.userProgressList.set(existingProgress.id, updatedProgress);
      return updatedProgress;
    } else {
      // Create new progress
      const id = this.userProgressCurrentId++;
      const now = new Date();
      const newProgress: UserProgress = { 
        ...progress, 
        id, 
        createdAt: now,
        lastAccessedAt: now,
        completedAt: progress.completed ? now : null 
      };
      this.userProgressList.set(id, newProgress);
      return newProgress;
    }
  }

  async getUserProgressByUserId(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgressList.values())
      .filter(progress => progress.userId === userId)
      .sort((a, b) => b.lastAccessedAt.getTime() - a.lastAccessedAt.getTime());
  }

  async getUserProgressByBookId(userId: number, bookId: string): Promise<UserProgress | undefined> {
    return Array.from(this.userProgressList.values())
      .find(progress => progress.userId === userId && progress.bookId === bookId);
  }

  async getUserProgressByLessonId(userId: number, lessonId: number): Promise<UserProgress | undefined> {
    return Array.from(this.userProgressList.values())
      .find(progress => progress.userId === userId && progress.lessonId === lessonId);
  }

  async getUserProgressByQuizId(userId: number, quizId: number): Promise<UserProgress | undefined> {
    return Array.from(this.userProgressList.values())
      .find(progress => progress.userId === userId && progress.quizId === quizId);
  }

  // Educational Media methods
  async createEducationalMedia(media: InsertEducationalMedia): Promise<EducationalMedia> {
    const id = this.educationalMediaCurrentId++;
    const now = new Date();
    const newMedia: EducationalMedia = { ...media, id, createdAt: now };
    this.educationalMediaList.set(id, newMedia);
    return newMedia;
  }

  async getEducationalMediaByLessonId(lessonId: number): Promise<EducationalMedia[]> {
    return Array.from(this.educationalMediaList.values())
      .filter(media => media.lessonId === lessonId);
  }

  async getEducationalMediaById(id: number): Promise<EducationalMedia | undefined> {
    return this.educationalMediaList.get(id);
  }

  async updateEducationalMedia(id: number, mediaUpdate: Partial<InsertEducationalMedia>): Promise<EducationalMedia> {
    const existingMedia = this.educationalMediaList.get(id);
    if (!existingMedia) {
      throw new Error(`Educational media with id ${id} not found`);
    }

    const updatedMedia: EducationalMedia = { ...existingMedia, ...mediaUpdate };
    this.educationalMediaList.set(id, updatedMedia);
    return updatedMedia;
  }

  async deleteEducationalMedia(id: number): Promise<boolean> {
    return this.educationalMediaList.delete(id);
  }
}

// Export an instance of the storage
export const storage = new MemStorage();
