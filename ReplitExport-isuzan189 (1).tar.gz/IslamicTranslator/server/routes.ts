import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { translationService } from "./services/translation";
import { speechService } from "./services/speech";
import { visionService } from "./services/vision";
import { contextTranslationService } from "./services/contextTranslation";
import { filterService } from "./services/filter";
import { quranTranslatorService } from "./services/quranTranslator";
import { emotionAnalyzerService } from "./services/emotionAnalyzer";
import { arabicCalligraphyService } from "./services/arabicCalligraphy";
import { learningModuleService } from "./services/learningModule";
import { contentCheckerService } from "./services/contentChecker";
import { proverbTranslatorService } from "./services/proverbTranslator";
import { scientificMiraclesService } from "./services/scientificMiracles";
import { islamicDawahService } from "./services/islamicDawah";
import { dawahSocialManagerService } from "./services/dawahSocialManager";
import { socialMediaManagerService } from "./services/socialMediaManager";
import { aiDawahAssistantService } from "./services/aiDawahAssistant";
import { dawahAnalyticsService } from "./services/dawahAnalytics";
import { islamicLibraryService } from "./services/islamicLibrary";
import { perplexityService } from "./services/perplexityService";
import { 
  translationRequestSchema, 
  speechToTextRequestSchema, 
  textToSpeechRequestSchema, 
  imageToTextRequestSchema,
  insertUserSchema,
  insertSettingsSchema,
  insertLessonSchema,
  insertQuizSchema,
  insertQuestionSchema,
  insertUserProgressSchema,
  generateQuizRequestSchema,
  generateLessonAudioRequestSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { requireAdmin } from './middleware/adminAuth';

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();

  // Error handler middleware
  const handleError = (fn: Function) => async (req: any, res: any, next: any) => {
    try {
      await fn(req, res, next);
    } catch (error) {
      console.error(error);

      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }

      res.status(500).json({ message: error.message || "Internal server error" });
    }
  };

  // API Health check
  apiRouter.get("/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Translation API endpoints
  apiRouter.post("/translate", handleError(async (req, res) => {
    const { sourceText, sourceLanguage, targetLanguage } = translationRequestSchema.parse(req.body);

    const result = await translationService.translateText(
      sourceText,
      sourceLanguage,
      targetLanguage
    );

    // Save translation history if user is logged in
    if (req.session?.userId) {
      await storage.createTranslation({
        userId: req.session.userId,
        sourceText,
        translatedText: result.translatedText,
        sourceLanguage,
        targetLanguage,
        translationType: "text"
      });
    }

    res.json(result);
  }));

  // Advanced context-aware translation API endpoint
  apiRouter.post("/context-translate", handleError(async (req, res) => {
    const { 
      sourceText, 
      sourceLanguage, 
      targetLanguage, 
      domain, 
      preserveStyle,
      dialectHandling,
      formalityLevel,
      culturalAdaptation,
      preferredDialect
    } = req.body;

    // Validate required fields
    translationRequestSchema.parse({
      sourceText,
      sourceLanguage,
      targetLanguage
    });

    const result = await contextTranslationService.translateWithContext(
      sourceText,
      sourceLanguage,
      targetLanguage,
      {
        domain,
        preserveStyle,
        dialectHandling,
        formalityLevel,
        culturalAdaptation,
        preferredDialect
      }
    );

    // Save translation history if user is logged in
    if (req.session?.userId) {
      await storage.createTranslation({
        userId: req.session.userId,
        sourceText,
        translatedText: result.translatedText,
        sourceLanguage,
        targetLanguage,
        translationType: "context"
      });
    }

    res.json(result);
  }));

  // Specialized content translation API endpoint (poetry, technical, etc.)
  apiRouter.post("/specialized-translate", handleError(async (req, res) => {
    const { 
      sourceText, 
      sourceLanguage, 
      targetLanguage, 
      contentType
    } = req.body;

    // Validate required fields
    translationRequestSchema.parse({
      sourceText,
      sourceLanguage,
      targetLanguage
    });

    // Validate content type
    if (!['poetry', 'technical', 'academic', 'conversational', 'religious', 'literary'].includes(contentType)) {
      throw new Error("Invalid content type. Must be one of: poetry, technical, academic, conversational, religious, literary");
    }

    const translatedText = await contextTranslationService.translateSpecializedContent(
      sourceText,
      sourceLanguage,
      targetLanguage,
      contentType
    );

    // Save translation history if user is logged in
    if (req.session?.userId) {
      await storage.createTranslation({
        userId: req.session.userId,
        sourceText,
        translatedText,
        sourceLanguage,
        targetLanguage,
        translationType: "specialized"
      });
    }

    res.json({ translatedText, contentType });
  }));

  // Dialect detection API endpoint
  apiRouter.post("/detect-dialect", handleError(async (req, res) => {
    const { text } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    const dialectInfo = await contextTranslationService.detectDialect(text);
    res.json(dialectInfo);
  }));

  // Domain/topic detection API endpoint
  apiRouter.post("/detect-domain", handleError(async (req, res) => {
    const { text, language } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    if (!language || typeof language !== 'string') {
      throw new Error("Language is required");
    }

    const domainInfo = await contextTranslationService.detectDomain(text, language);
    res.json(domainInfo);
  }));

  // Speech-to-text API endpoint
  apiRouter.post("/speech-to-text", handleError(async (req, res) => {
    const { audioData, sourceLanguage } = speechToTextRequestSchema.parse(req.body);

    const result = await speechService.speechToText(audioData, sourceLanguage);

    res.json(result);
  }));

  // Text-to-speech API endpoint
  apiRouter.post("/text-to-speech", handleError(async (req, res) => {
    const { text, language, voiceGender, voiceSpeed } = textToSpeechRequestSchema.parse(req.body);

    const result = await speechService.textToSpeech(
      text,
      language,
      voiceGender,
      voiceSpeed
    );

    res.json(result);
  }));

  // Image-to-text API endpoint
  apiRouter.post("/image-to-text", handleError(async (req, res) => {
    const { imageData, sourceLanguage, targetLanguage } = imageToTextRequestSchema.parse(req.body);

    const result = await visionService.imageToText(
      imageData,
      sourceLanguage,
      targetLanguage
    );

    // Save translation history if user is logged in
    if (req.session?.userId) {
      await storage.createTranslation({
        userId: req.session.userId,
        sourceText: result.extractedText,
        translatedText: result.translatedText,
        sourceLanguage,
        targetLanguage,
        translationType: "image"
      });
    }

    res.json(result);
  }));

  // Languages API endpoint
  apiRouter.get("/languages", handleError(async (req, res) => {
    const languages = await storage.getLanguages();
    res.json(languages);
  }));

  // Translation history API endpoints
  apiRouter.get("/translations", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const translations = await storage.getTranslations(req.session.userId, limit);

    res.json(translations);
  }));

  // User API endpoints
  apiRouter.post("/register", handleError(async (req, res) => {
    const userData = insertUserSchema.parse(req.body);

    // Check if username already exists
    const existingUser = await storage.getUserByUsername(userData.username);
    if (existingUser) {
      return res.status(409).json({ message: "Username already exists" });
    }

    // Create user
    const user = await storage.createUser(userData);

    // Initialize user settings with defaults
    await storage.createOrUpdateSettings({
      userId: user.id,
      preferredSourceLanguage: "ar",
      preferredTargetLanguage: "en",
      voiceSpeed: 1,
      voiceGender: "FEMALE",
      theme: "light",
      filterLevel: "moderate"
    });

    // Set user session
    req.session.userId = user.id;

    res.status(201).json({ id: user.id, username: user.username });
  }));

  apiRouter.post("/login", handleError(async (req, res) => {
    const { username, password } = req.body;

    // Find user
    const user = await storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Set user session
    req.session.userId = user.id;

    res.json({ id: user.id, username: user.username, isAdmin: user.isAdmin });
  }));

  apiRouter.post("/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  apiRouter.post("/reset-password", handleError(async (req, res) => {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ message: "البريد الإلكتروني مطلوب" });
    }

    const success = await resetPassword(email);
    
    if (success) {
      res.json({ message: "تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني" });
    } else {
      res.status(404).json({ message: "البريد الإلكتروني غير مسجل في النظام" });
    }
  }));

  apiRouter.get("/user", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ id: user.id, username: user.username, isAdmin: user.isAdmin });
  }));

  // Settings API endpoints
  apiRouter.get("/settings", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const settings = await storage.getSettings(req.session.userId);
    if (!settings) {
      return res.status(404).json({ message: "Settings not found" });
    }

    res.json(settings);
  }));

  apiRouter.post("/settings", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const settingsData = insertSettingsSchema.parse({
      ...req.body,
      userId: req.session.userId
    });

    const settings = await storage.createOrUpdateSettings(settingsData);

    res.json(settings);
  }));

  // Admin API endpoints - protected by authentication
  apiRouter.get("/admin/stats", requireAdmin, handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Forbidden" });
    }

    const days = req.query.days ? parseInt(req.query.days as string) : 7;
    const stats = await storage.getDailyStats(days);

    res.json(stats);
  }));

  apiRouter.get("/admin/prohibited-words", requireAdmin, handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Forbidden" });
    }

    const language = req.query.language as string | undefined;
    const words = await storage.getProhibitedWords(language);

    res.json(words);
  }));

  apiRouter.post("/admin/prohibited-words", requireAdmin, handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Forbidden" });
    }

    const { word, language, category, replacement } = req.body;

    const newWord = await filterService.addProhibitedWord(
      word,
      language,
      category,
      replacement
    );

    res.status(201).json(newWord);
  }));

  // New endpoints for additional features

  // Quranic translation API endpoint
  apiRouter.post("/quran-translate", handleError(async (req, res) => {
    const { 
      sourceText, 
      sourceLanguage, 
      targetLanguage,
      includeTransliteration,
      includeTafsir,
      preferredTafsir,
      preserveStructure,
      includeSurahInfo
    } = req.body;

    // Validate required fields
    translationRequestSchema.parse({
      sourceText,
      sourceLanguage,
      targetLanguage
    });

    const result = await quranTranslatorService.translateQuranicText(
      sourceText,
      sourceLanguage,
      targetLanguage,
      {
        includeTransliteration,
        includeTafsir,
        preferredTafsir,
        preserveStructure,
        includeSurahInfo
      }
    );

    res.json(result);
  }));

  // Emotional analysis API endpoint
  apiRouter.post("/analyze-emotions", handleError(async (req, res) => {
    const { 
      text, 
      language,
      includeIntensity,
      includeExpressions,
      includeIslamicContext,
      detailedAnalysis
    } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    if (!language || typeof language !== 'string') {
      throw new Error("Language is required");
    }

    const result = await emotionAnalyzerService.analyzeEmotions(
      text,
      language,
      {
        includeIntensity,
        includeExpressions,
        includeIslamicContext,
        detailedAnalysis
      }
    );

    res.json(result);
  }));

  // Arabic calligraphy API endpoints
  apiRouter.get("/calligraphy/styles", handleError(async (req, res) => {
    const language = req.query.language as string || 'ar';
    const styles = arabicCalligraphyService.getCalligraphyStyles(language);
    res.json(styles);
  }));

  apiRouter.get("/calligraphy/decorations", handleError(async (req, res) => {
    const language = req.query.language as string || 'ar';
    const decorations = arabicCalligraphyService.getDecorativeElements(language);
    res.json(decorations);
  }));

  apiRouter.get("/calligraphy/palettes", handleError(async (req, res) => {
    const language = req.query.language as string || 'ar';
    const palettes = arabicCalligraphyService.getColorPalettes(language);
    res.json(palettes);
  }));

  apiRouter.post("/calligraphy/generate", handleError(async (req, res) => {
    const { 
      text, 
      style,
      decorations,
      colorPalette,
      includeBismillah,
      includeFrame,
      includeBackground,
      textSize,
      alignment
    } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    if (!style || typeof style !== 'string') {
      throw new Error("Calligraphy style is required");
    }

    const html = arabicCalligraphyService.generateStyledHTML(
      text,
      style,
      decorations,
      colorPalette,
      {
        includeBismillah,
        includeFrame,
        includeBackground,
        textSize,
        alignment
      }
    );

    // Also include the CSS needed to render the calligraphy
    const css = arabicCalligraphyService.getAllCSSClasses();

    res.json({ html, css });
  }));

  apiRouter.post("/calligraphy/svg", handleError(async (req, res) => {
    const { 
      text, 
      style,
      width,
      height,
      backgroundColor,
      foregroundColor,
      decorativeElement,
      useIllumination
    } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    if (!style || typeof style !== 'string') {
      throw new Error("Calligraphy style is required");
    }

    const svg = arabicCalligraphyService.generateSVG(
      text,
      style,
      {
        width,
        height,
        backgroundColor,
        foregroundColor,
        decorativeElement,
        useIllumination
      }
    );

    res.json({ svg });
  }));

  // Learning module generation API endpoint
  apiRouter.post("/generate-learning", handleError(async (req, res) => {
    const { 
      sourceText, 
      translatedText, 
      sourceLanguage, 
      targetLanguage,
      moduleType,
      level,
      includeExamples,
      includeExercises,
      includeAudio,
      focusOnIslamic,
      maxItems
    } = req.body;

    // Validate required fields
    if (!sourceText || !translatedText || !sourceLanguage || !targetLanguage || !moduleType || !level) {
      throw new Error("Missing required fields for learning module generation");
    }

    // Validate module type and level
    const validModuleTypes = [
      'vocabulary', 'grammar', 'phrases', 'cultural_context', 
      'islamic_terminology', 'pronunciation', 'reading_comprehension', 'writing_practice'
    ];

    const validLevels = ['beginner', 'intermediate', 'advanced', 'scholarly'];

    if (!validModuleTypes.includes(moduleType)) {
      throw new Error(`Invalid module type. Must be one of: ${validModuleTypes.join(', ')}`);
    }

    if (!validLevels.includes(level)) {
      throw new Error(`Invalid level. Must be one of: ${validLevels.join(', ')}`);
    }

    const result = await learningModuleService.generateLearningModule(
      sourceText,
      translatedText,
      sourceLanguage,
      targetLanguage,
      {
        moduleType,
        level,
        includeExamples,
        includeExercises,
        includeAudio,
        focusOnIslamic,
        maxItems
      }
    );

    res.json(result);
  }));

  // Islamic content verification API endpoint
  apiRouter.post("/verify-content", handleError(async (req, res) => {
    const { 
      originalText, 
      translatedText, 
      sourceLanguage, 
      targetLanguage,
      category,
      strictnessLevel,
      provideReferences,
      includeSuggestions,
      checkHonorificPhrases
    } = req.body;

    // Validate required fields
    if (!originalText || !translatedText || !sourceLanguage || !targetLanguage) {
      throw new Error("Missing required fields for content verification");
    }

    const result = await contentCheckerService.verifyIslamicContent(
      originalText,
      translatedText,
      sourceLanguage,
      targetLanguage,
      {
        category,
        strictnessLevel,
        provideReferences,
        includeSuggestions,
        checkHonorificPhrases
      }
    );

    res.json(result);
  }));

  // Theological claims detection endpoint
  apiRouter.post("/detect-theological", handleError(async (req, res) => {
    const { text, language } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    if (!language || typeof language !== 'string') {
      throw new Error("Language is required");
    }

    const result = await contentCheckerService.containsTheologicalClaims(text, language);
    res.json(result);
  }));

  // Proverb translation API endpoint
  apiRouter.post("/translate-proverb", handleError(async (req, res) => {
    const { 
      proverb, 
      sourceLanguage, 
      targetLanguage,
      includeContext,
      includeEquivalent,
      includeUsageExamples
    } = req.body;

    if (!proverb || typeof proverb !== 'string') {
      throw new Error("Proverb text is required");
    }

    if (!sourceLanguage || !targetLanguage) {
      throw new Error("Source and target languages are required");
    }

    const result = await proverbTranslatorService.translateProverb(
      proverb,
      sourceLanguage,
      targetLanguage,
      {
        includeContext,
        includeEquivalent,
        includeUsageExamples
      }
    );

    res.json(result);
  }));

  // Proverb categories API endpoint
  apiRouter.get("/proverb-categories", handleError(async (req, res) => {
    const categories = proverbTranslatorService.getProverbCategories();
    res.json(categories);
  }));

  // Proverbs by category API endpoint
  apiRouter.get("/proverbs", handleError(async (req, res) => {
    const category = req.query.category as string;
    const language = req.query.language as string || 'ar';
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;

    const proverbs = proverbTranslatorService.getProverbsByCategory(category, language, limit);
    res.json(proverbs);
  }));

  // Proverb detection API endpoint
  apiRouter.post("/detect-proverb", handleError(async (req, res) => {
    const { text, language } = req.body;

    if (!text || typeof text !== 'string') {
      throw new Error("Text is required");
    }

    if (!language || typeof language !== 'string') {
      throw new Error("Language is required");
    }

    const result = await proverbTranslatorService.detectProverb(text, language);
    res.json(result);
  }));

  // Scientific miracles API endpoints
  apiRouter.get("/scientific-miracles/categories", handleError(async (req, res) => {
    const categories = scientificMiraclesService.getMiracleCategories();
    res.json(categories);
  }));

  apiRouter.get("/scientific-miracles", handleError(async (req, res) => {
    const category = req.query.category as string || 'all';
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const includeReferences = req.query.references === 'true';
    const language = req.query.language as string || 'ar';
    const detailedExplanation = req.query.detailed === 'true';

    const miracles = scientificMiraclesService.getMiraclesByCategory(
      category,
      {
        limit,
        includeReferences,
        language,
        detailedExplanation
      }
    );

    res.json(miracles);
  }));

  apiRouter.get("/scientific-miracles/:id", handleError(async (req, res) => {
    const id = req.params.id;
    const includeReferences = req.query.references === 'true';
    const includeRelated = req.query.related === 'true';
    const language = req.query.language as string || 'ar';

    const miracle = scientificMiraclesService.getMiracleById(
      id,
      {
        includeReferences,
        includeRelated,
        language,
        detailedExplanation: true
      }
    );

    if (!miracle) {
      return res.status(404).json({ message: "Scientific miracle not found" });
    }

    res.json(miracle);
  }));

  apiRouter.post("/scientific-miracles/search", handleError(async (req, res) => {
    const { query, limit, includeReferences, language } = req.body;

    if (!query || typeof query !== 'string') {
      throw new Error("Search query is required");
    }

    const results = scientificMiraclesService.searchMiracles(
      query,
      {
        limit: limit || 10,
        includeReferences: includeReferences || false,
        language: language || 'ar'
      }
    );

    res.json(results);
  }));

  apiRouter.post("/scientific-miracles/explain", handleError(async (req, res) => {
    const { 
      topic, 
      depth, 
      audience, 
      language, 
      includeReferences,
      includeVerses 
    } = req.body;

    if (!topic || typeof topic !== 'string') {
      throw new Error("Topic is required");
    }

    const explanation = await scientificMiraclesService.generateMiracleExplanation(
      topic,
      {
        depth: depth || 'detailed',
        audience: audience || 'general',
        language: language || 'ar',
        includeReferences: includeReferences !== false,
        includeVerses: includeVerses !== false
      }
    );

    res.json(explanation);
  }));

  // Islamic dawah API endpoints
  apiRouter.get("/dawah/categories", handleError(async (req, res) => {
    const categories = islamicDawahService.getFaithCategories();
    res.json(categories);
  }));

  apiRouter.get("/dawah/common-questions", handleError(async (req, res) => {
    const category = req.query.category as string;
    const language = req.query.language as string || 'en';
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;

    const questions = islamicDawahService.getCommonQuestions(category, language, limit);
    res.json(questions);
  }));

  apiRouter.get("/dawah/misconceptions/:id", handleError(async (req, res) => {
    const id = req.params.id;
    const language = req.query.language as string || 'en';

    const response = islamicDawahService.getMisconceptionResponse(id, language);

    if (!response) {
      return res.status(404).json({ message: "Misconception response not found" });
    }

    res.json(response);
  }));

  apiRouter.get("/dawah/resources", handleError(async (req, res) => {
    const type = req.query.type as string;
    const level = req.query.level as string;
    const language = req.query.language as string || 'en';

    const resources = islamicDawahService.getDawahResources(type, level, language);
    res.json(resources);
  }));

  apiRouter.get("/dawah/conversion-stories", handleError(async (req, res) => {
    const factor = req.query.factor as string;
    const language = req.query.language as string || 'en';

    const stories = islamicDawahService.getConversionStories(factor, language);
    res.json(stories);
  }));

  apiRouter.post("/dawah/personalized", handleError(async (req, res) => {
    const { background, language } = req.body;

    if (!background || typeof background !== 'object') {
      throw new Error("Background information is required");
    }

    const personalized = await islamicDawahService.generatePersonalizedDawah(
      background,
      language || 'en'
    );

    res.json(personalized);
  }));

  apiRouter.post("/dawah/generate-response", handleError(async (req, res) => {
    const { 
      question, 
      detailLevel, 
      includeScriptural, 
      includeScholarly,
      audienceType,
      language 
    } = req.body;

    if (!question || typeof question !== 'string') {
      throw new Error("Question is required");
    }

    const response = await islamicDawahService.generateFaithResponse(
      question,
      {
        detailLevel: detailLevel || 'detailed',
        includeScriptural: includeScriptural !== false,
        includeScholarly: includeScholarly !== false,
        audienceType: audienceType || 'general',
        language: language || 'en'
      }
    );

    res.json(response);
  }));

  // Social media dawah API endpoints
  apiRouter.get("/dawah/social/platforms", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // In a real implementation, this would return the actual platforms from the service
    res.json([
      'facebook',
      'twitter',
      'instagram',
      'youtube',
      'tiktok',
      'telegram',
      'whatsapp'
    ]);
  }));

  apiRouter.post("/dawah/social/connect-account", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { platform, username, accessToken, refreshToken } = req.body;

    if (!platform || !username) {
      throw new Error("Platform and username are required");
    }

    const accountId = dawahSocialManagerService.connectAccount(
      req.session.userId,
      platform,
      username,
      accessToken,
      refreshToken
    );

    res.json({ 
      success: true, 
      accountId,
      message: `Successfully connected ${platform} account: ${username}`
    });
  }));

  apiRouter.post("/dawah/social/generate-reply", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { conversationId, tone, includeInvitation, includeScripture } = req.body;

    if (!conversationId) {
      throw new Error("Conversation ID is required");
    }

    const reply = await dawahSocialManagerService.generateReply(
      conversationId,
      {
        tone: tone || 'conversational',
        includeInvitation: includeInvitation !== false,
        includeScripture: includeScripture !== false
      }
    );

    res.json({ 
      success: true,
      reply
    });
  }));

  apiRouter.post("/dawah/social/monitor", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { accountId, keywords, respondAutomatically, maxResponses } = req.body;

    if (!accountId) {
      throw new Error("Account ID is required");
    }

    const result = await dawahSocialManagerService.monitorSocialMedia(
      accountId,
      {
        keywords,
        respondAutomatically: respondAutomatically || false,
        maxResponses: maxResponses || 5
      }
    );

    res.json(result);
  }));

  apiRouter.get("/dawah/social/report", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const report = dawahSocialManagerService.generateEngagementReport(req.session.userId);
    res.json(report);
  }));

  // AI Dawah Assistant Routes
  apiRouter.post("/dawah/conversation", handleError(async (req, res) => {
    const { userId, language, faithTopic, userBackground } = req.body;

    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }

    const conversationId = aiDawahAssistantService.createConversation(
      userId.toString(), 
      language || 'en',
      { faithTopic, userBackground }
    );

    res.status(201).json({ 
      conversationId,
      message: 'Dawah conversation created successfully' 
    });
  }));

  apiRouter.post("/dawah/conversation/:id/message", handleError(async (req, res) => {
    const { message } = req.body;
    const conversationId = req.params.id;

    if (!message) {
      return res.status(400).json({ message: "Message is required" });
    }

    try {
      const response = await aiDawahAssistantService.processMessage(conversationId, message);
      res.json(response);
    } catch (error) {
      res.status(404).json({ message: `Error processing message: ${error.message}` });
    }
  }));

  apiRouter.get("/dawah/conversation/:id", handleError(async (req, res) => {
    const conversationId = req.params.id;
    const result = aiDawahAssistantService.getConversationHistory(conversationId);

    if (result.error) {
      return res.status(404).json({ message: result.error });
    }

    res.json(result.conversation);
  }));

  apiRouter.get("/dawah/user/:userId/conversations", handleError(async (req, res) => {
    const userId = req.params.userId;
    const conversations = aiDawahAssistantService.getUserConversations(userId);
    res.json(conversations);
  }));

  // Social Media Manager Routes
  apiRouter.get("/social/platforms", handleError(async (req, res) => {
    const platforms = socialMediaManagerService.getAvailablePlatforms();
    res.json({ platforms });
  }));

  apiRouter.post("/social/post", handleError(async (req, res) => {
    const { platform, content, channelId, contentType, attachments, scheduledTime } = req.body;

    if (!platform || !content) {
      return res.status(400).json({ message: "Platform and content are required" });
    }

    const result = await socialMediaManagerService.postContent(platform, content, {
      channelId,
      contentType,
      attachments,
      scheduledTime: scheduledTime ? new Date(scheduledTime) : undefined
    });

    if (!result.success) {
      return res.status(400).json({ message: result.error });
    }

    res.status(201).json({ 
      success: true,
      postId: result.postId,
      message: `Content posted successfully to ${platform}`
    });
  }));

  apiRouter.get("/social/:platform/activity", handleError(async (req, res) => {
    const platform = req.params.platform;
    const { channelId, limit } = req.query;

    const result = await socialMediaManagerService.getRecentActivity(platform, {
      channelId: channelId?.toString(),
      limit: limit ? parseInt(limit.toString()) : undefined
    });

    if (!result.success) {
      return res.status(400).json({ message: result.error });
    }

    res.json({ 
      success: true,
      messages: result.messages
    });
  }));

  apiRouter.post("/social/:platform/analyze", handleError(async (req, res) => {
    const platform = req.params.platform;
    const { channelId, messageLimit, lookForQuestions, identifyMisconceptions } = req.body;

    const result = await socialMediaManagerService.analyzeDawahOpportunities(platform, {
      channelId,
      messageLimit,
      lookForQuestions,
      identifyMisconceptions
    });

    if (!result.success) {
      return res.status(400).json({ message: result.error });
    }

    res.json({ 
      success: true,
      opportunities: result.opportunities
    });
  }));

  apiRouter.post("/social/:platform/respond", handleError(async (req, res) => {
    const platform = req.params.platform;
    const { messageId, responseText, channelId } = req.body;

    if (!messageId || !responseText) {
      return res.status(400).json({ message: "Message ID and response text are required" });
    }

    const result = await socialMediaManagerService.respondToMessage(platform, messageId, responseText, {
      channelId
    });

    if (!result.success) {
      return res.status(400).json({ message: result.error });
    }

    res.status(201).json({ 
      success: true,
      responseId: result.responseId,
      message: 'Response sent successfully'
    });
  }));

  apiRouter.post("/social/:platform/schedule", handleError(async (req, res) => {
    const platform = req.params.platform;
    const { content, scheduledTime, channelId, contentType, recurring } = req.body;

    if (!content || !scheduledTime) {
      return res.status(400).json({ message: "Content and scheduled time are required" });
    }

    const result = await socialMediaManagerService.scheduleContent(
      platform, 
      content, 
      new Date(scheduledTime),
      {
        channelId,
        contentType,
        recurring
      }
    );

    if (!result.success) {
      return res.status(400).json({ message: result.error });
    }

    res.status(201).json({ 
      success: true,
      scheduleId: result.scheduleId,
      message: 'Content scheduled successfully'
    });
  }));

  apiRouter.get("/social/:platform/report", handleError(async (req, res) => {
    const platform = req.params.platform;
    const { channelId, daysPeriod, includeContentSuggestions } = req.query;

    const result = await socialMediaManagerService.generateDawahReport(platform, {
      channelId: channelId?.toString(),
      daysPeriod: daysPeriod ? parseInt(daysPeriod.toString()) : undefined,
      includeContentSuggestions: includeContentSuggestions === 'true'
    });

    if (!result.success) {
      return res.status(400).json({ message: result.error });
    }

    res.json(result.report);
  }));

  // Dawah Contact Management Routes
  apiRouter.get("/dawah/contacts", handleError(async (req, res) => {
    // En una implementación real, obtendríamos los contactos del servicio de almacenamiento
    // Aquí proporcionamos datos de ejemplo para la demostración
    const contacts = [
      {
        id: "1",
        name: "محمد أحمد",
        source: "فيسبوك",
        religion: "مسيحي",
        interests: ["العلم في القرآن", "تاريخ الإسلام"],
        status: "interested",
        interactions: [
          {
            date: new Date().toISOString(),
            type: "question_answered",
            topic: "معجزات القرآن العلمية",
            notes: "سأل عن الإعجاز العلمي في القرآن حول تطور الجنين"
          }
        ]
      },
      {
        id: "2",
        name: "سارة جونسون",
        source: "تويتر",
        religion: "ملحدة",
        interests: ["فلسفة الوجود", "الأدلة على وجود الله"],
        status: "learning",
        interactions: [
          {
            date: new Date(Date.now() - 86400000).toISOString(), // yesterday
            type: "material_shared",
            topic: "أدلة وجود الله",
            notes: "شاركت معها كتاب الحقائق الإيمانية في ضوء العلم الحديث"
          },
          {
            date: new Date().toISOString(),
            type: "conversation",
            topic: "النظام الكوني",
            notes: "نقاش حول دقة النظام الكوني كدليل على وجود خالق"
          }
        ]
      },
      {
        id: "3",
        name: "ديفيد ويلسون",
        source: "يوتيوب",
        religion: "لا أدري",
        interests: ["مقارنة الأديان", "أخلاقيات الإسلام"],
        status: "convinced",
        interactions: [
          {
            date: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
            type: "question_answered",
            topic: "مقارنة بين الأديان",
            notes: "سأل عن الفروق الأساسية بين الإسلام والمسيحية"
          },
          {
            date: new Date(Date.now() - 86400000).toISOString(), // yesterday
            type: "material_shared",
            topic: "الإسلام والمسيحية",
            notes: "شاركت معه مقارنة موضوعية بين العقائد الأساسية"
          },
          {
            date: new Date().toISOString(),
            type: "status_change",
            topic: "اقتناع بالإسلام",
            notes: "أظهر اقتناعاً بالإسلام بعد سلسلة من النقاشات حول عقيدة التوحيد"
          }
        ]
      },
      {
        id: "4",
        name: "ليزا تشانج",
        source: "إنستغرام",
        religion: "بوذية",
        interests: ["التصوف الإسلامي", "مكانة المرأة"],
        status: "converted",
        interactions: [
          {
            date: new Date(Date.now() - 2592000000).toISOString(), // 30 days ago
            type: "question_answered",
            topic: "المرأة في الإسلام",
            notes: "سألت عن حقوق المرأة في الإسلام"
          },
          {
            date: new Date(Date.now() - 1296000000).toISOString(), // 15 days ago
            type: "conversation",
            topic: "التصوف والروحانية",
            notes: "نقاش حول الجوانب الروحية في الإسلام"
          },
          {
            date: new Date(Date.now() - 604800000).toISOString(), // 7 days ago
            type: "status_change",
            topic: "مرحلة الاقتناع",
            notes: "وصلت لمرحلة الاقتناع بعد قراءة كتاب وحضور محاضرة"
          },
          {
            date: new Date().toISOString(),
            type: "status_change",
            topic: "إعلان الإسلام",
            notes: "نطقت الشهادتين وأعلنت إسلامها"
          }
        ]
      }
    ];

    res.json({ contacts });
  }));

  apiRouter.post("/dawah/contacts", handleError(async (req, res) => {
    // Validación y procesamiento de los datos del nuevo contacto
    const { name, source, religion, interests, notes } = req.body;

    if (!name || !source) {
      return res.status(400).json({ message: "الاسم والمصدر مطلوبان" });
    }

    // En una implementación real, guardaríamos el contacto en la base de datos
    // y devolveríamos el objeto creado con un ID generado
    const newContact = {
      id: Date.now().toString(),
      name,
      source,
      religion,
      interests: interests || [],
      notes,
      status: "initial_contact",
      interactions: [
        {
          date: new Date().toISOString(),
          type: "initial_contact",
          topic: "أول تواصل",
          notes: "تم إضافة جهة الاتصال من خلال النظام"
        }
      ]
    };

    res.status(201).json(newContact);
  }));

  apiRouter.post("/dawah/contacts/:id/interaction", handleError(async (req, res) => {
    const { id } = req.params;
    const { interactionType, topic, notes } = req.body;

    if (!interactionType || !topic || !notes) {
      return res.status(400).json({ message: "جميع حقول التفاعل مطلوبة" });
    }

    // En una implementación real, buscaríamos el contacto y agregaríamos la interacción
    const interaction = {
      date: new Date().toISOString(),
      type: interactionType,
      topic,
      notes
    };

    res.status(201).json({ interaction, message: "تمت إضافة التفاعل بنجاح" });
  }));

  apiRouter.put("/dawah/contacts/:id/status", handleError(async (req, res) => {
    const { id } = req.params;
    const { status, notes } = req.body;

    if (!status) {
      return res.status(400).json({ message: "الحالة مطلوبة" });
    }

    const validStatuses = [
      'initial_contact', 
      'interested', 
      'learning', 
      'convinced', 
      'converted', 
      'inactive'
    ];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: "حالة غير صالحة" });
    }

    // En una implementación real, actualizaríamos el estado del contacto
    // y agregaríamos una nueva interacción de tipo "status_change"
    const interaction = {
      date: new Date().toISOString(),
      type: "status_change",
      topic: `تغيير الحالة إلى ${status}`,
      notes: notes || "تم تحديث الحالة"
    };

    res.json({ 
      success: true, 
      message: "تم تحديث الحالة بنجاح",
      status,
      interaction
    });
  }));

  // Dawah Analytics Routes
  apiRouter.get("/dawah/analytics/conversion", handleError(async (req, res) => {
    const stats = dawahAnalyticsService.getConversionStats();
    res.json(stats);
  }));

  apiRouter.get("/dawah/analytics/regional", handleError(async (req, res) => {
    const { region, timeframe } = req.query;
    const stats = dawahAnalyticsService.getRegionalStats(
      region?.toString(),
      timeframe?.toString() as any || 'all'
    );
    res.json(stats);
  }));

  apiRouter.get("/dawah/analytics/topics", handleError(async (req, res) => {
    const { sortBy } = req.query;
    const insights = dawahAnalyticsService.getTopicInsights(
      sortBy?.toString() as any || 'conversion_effectiveness'
    );
    res.json(insights);
  }));

  apiRouter.get("/dawah/analytics/demographics", handleError(async (req, res) => {
    const insights = dawahAnalyticsService.getDemographicInsights();
    res.json(insights);
  }));

  apiRouter.get("/dawah/analytics/report", handleError(async (req, res) => {
    const report = dawahAnalyticsService.generateDawahReport();
    res.json(report);
  }));

  // Islamic Library Routes
  apiRouter.get("/library/books", handleError(async (req, res) => {
    const language = req.query.language as string;
    const category = req.query.category as string;
    const query = req.query.query as string;

    const filters = {
      language,
      category,
      query
    };

    const books = islamicLibraryService.getBooks(filters);
    res.json({ books });
  }));

  apiRouter.get("/library/videos", handleError(async (req, res) => {
    const language = req.query.language as string;
    const query = req.query.query as string;
    const translationAvailable = req.query.translationAvailable as string;

    const filters = {
      language,
      query,
      translationAvailable
    };

    const videos = islamicLibraryService.getVideos(filters);
    res.json({ videos });
  }));

  apiRouter.get("/library/book/:id", handleError(async (req, res) => {
    const { id } = req.params;
    const book = islamicLibraryService.getBookById(id);

    if (!book) {
      return res.status(404).json({ message: "الكتاب غير موجود" });
    }

    res.json({ book });
  }));

  apiRouter.get("/library/video/:id", handleError(async (req, res) => {
    const { id } = req.params;
    const video = islamicLibraryService.getVideoById(id);

    if (!video) {
      return res.status(404).json({ message: "الفيديو غير موجود" });
    }

    res.json({ video });
  }));

  apiRouter.get("/library/categories", handleError(async (req, res) => {
    const categories = islamicLibraryService.getBookCategories();
    res.json({ categories });
  }));

  apiRouter.get("/library/languages", handleError(async (req, res) => {
    const languages = islamicLibraryService.getLanguages();
    res.json({ languages });
  }));

  apiRouter.post("/library/books/upload", handleError(async (req, res) => {
    const { title, author, language, category, description, coverImage } = req.body;

    if (!title || !author) {
      return res.status(400).json({ message: "العنوان والمؤلف مطلوبان" });
    }

    try {
      const newBook = await islamicLibraryService.addBook({
        title,
        author,
        language,
        category,
        coverImage,
        description,
        pages: parseInt(req.body.pages) || 100,
        pdfUrl: req.body.pdfUrl || `/books/${Date.now().toString()}.pdf`
      });

      res.status(201).json({ book: newBook });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }));

  apiRouter.post("/library/videos/upload", handleError(async (req, res) => {
    const { title, originalLanguage, thumbnailUrl, videoUrl, uploadDate } = req.body;

    if (!title) {
      return res.status(400).json({ message: "عنوان الفيديو مطلوب" });
    }

    try {
      const newVideo = await islamicLibraryService.addVideo({
        title,
        originalLanguage: originalLanguage || 'ar',
        thumbnailUrl,
        uploadDate: uploadDate || new Date().toISOString().split('T')[0],
        videoUrl: videoUrl || `/videos/${Date.now().toString()}.mp4`
      });

      res.status(201).json({ video: newVideo });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }));

  apiRouter.post("/library/books/:id/audio", handleError(async (req, res) => {
    const { id } = req.params;

    try {
      const result = await islamicLibraryService.generateBookAudio(id);
      res.json(result);
    } catch (error) {
      res.status(404).json({ message: error.message });
    }
  }));

  apiRouter.post("/library/videos/:id/translate", handleError(async (req, res) => {
    const { id } = req.params;
    const { targetLanguage } = req.body;

    if (!targetLanguage) {
      return res.status(400).json({ message: "اللغة المستهدفة مطلوبة" });
    }

    try {
      const result = await islamicLibraryService.generateVideoTranslation(id, targetLanguage);
      res.json(result);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }));

  apiRouter.post("/library/image-search", handleError(async (req, res) => {
    const { imageData } = req.body;

    if (!imageData) {
      return res.status(400).json({ message: "بيانات الصورة مطلوبة" });
    }

    try {
      const books = await islamicLibraryService.searchBookByImage(imageData);
      res.json({ books });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }));

  apiRouter.post("/library/extract-text", handleError(async (req, res) => {
    const { imageData, language } = req.body;

    if (!imageData) {
      return res.status(400).json({ message: "بيانات الصورة مطلوبة" });
    }

    try {
      const text = await islamicLibraryService.extractTextFromImage(imageData, language || 'ar');
      res.json({ text });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }));

  // Educational content endpoints
  // Lessons API endpoints
  apiRouter.post("/lessons", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const lessonData = insertLessonSchema.parse(req.body);
    const lesson = await storage.createLesson(lessonData);

    res.status(201).json(lesson);
  }));

  apiRouter.get("/lessons/book/:bookId", handleError(async (req, res) => {
    const { bookId } = req.params;
    const lessons = await storage.getLessonsByBookId(bookId);

    res.json(lessons);
  }));

  apiRouter.get("/lessons/:id", handleError(async (req, res) => {
    const lessonId = parseInt(req.params.id);
    const lesson = await storage.getLessonById(lessonId);

    if (!lesson) {
      return res.status(404).json({ message: "Lesson not found" });
    }

    res.json(lesson);
  }));

  apiRouter.put("/lessons/:id", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const lessonId = parseInt(req.params.id);
    const existingLesson = await storage.getLessonById(lessonId);

    if (!existingLesson) {
      return res.status(404).json({ message: "Lesson not found" });
    }

    const updateData = insertLessonSchema.partial().parse(req.body);
    const updatedLesson = await storage.updateLesson(lessonId, updateData);

    res.json(updatedLesson);
  }));

  apiRouter.delete("/lessons/:id", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const lessonId = parseInt(req.params.id);
    const success = await storage.deleteLesson(lessonId);

    if (!success) {
      return res.status(404).json({ message: "Lesson not found" });
    }

    res.json({ message: "Lesson deleted successfully" });
  }));

  // Quizzes API endpoints
  apiRouter.post("/quizzes", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const quizData = insertQuizSchema.parse(req.body);
    const quiz = await storage.createQuiz(quizData);

    res.status(201).json(quiz);
  }));

  apiRouter.get("/quizzes/book/:bookId", handleError(async (req, res) => {
    const { bookId } = req.params;
    const quizzes = await storage.getQuizzesByBookId(bookId);

    res.json(quizzes);
  }));

  apiRouter.get("/quizzes/lesson/:lessonId", handleError(async (req, res) => {
    const lessonId = parseInt(req.params.lessonId);
    const quizzes = await storage.getQuizzesByLessonId(lessonId);

    res.json(quizzes);
  }));

  apiRouter.get("/quizzes/:id", handleError(async (req, res) => {
    const quizId = parseInt(req.params.id);
    const quiz = await storage.getQuizById(quizId);

    if (!quiz) {
      return res.status(404).json({ message: "Quiz not found" });
    }

    res.json(quiz);
  }));

  apiRouter.put("/quizzes/:id", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const quizId = parseInt(req.params.id);
    const existingQuiz = await storage.getQuizById(quizId);

    if (!existingQuiz) {
      return res.status(404).json({ message: "Quiz not found" });
    }

    const updateData = insertQuizSchema.partial().parse(req.body);
    const updatedQuiz = await storage.updateQuiz(quizId, updateData);

    res.json(updatedQuiz);
  }));

  apiRouter.delete("/quizzes/:id", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const quizId = parseInt(req.params.id);
    const success = await storage.deleteQuiz(quizId);

    if (!success) {
      return res.status(404).json({ message: "Quiz not found" });
    }

    res.json({ message: "Quiz deleted successfully" });
  }));

  // Questions API endpoints
  apiRouter.post("/questions", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const questionData = insertQuestionSchema.parse(req.body);
    const question = await storage.createQuestion(questionData);

    res.status(201).json(question);
  }));

  apiRouter.get("/questions/quiz/:quizId", handleError(async (req, res) => {
    const quizId = parseInt(req.params.quizId);
    const questions = await storage.getQuestionsByQuizId(quizId);

    res.json(questions);
  }));

  apiRouter.get("/questions/:id", handleError(async (req, res) => {
    const questionId = parseInt(req.params.id);
    const question = await storage.getQuestionById(questionId);

    if (!question) {
      return res.status(404).json({ message: "Question not found" });
    }

    res.json(question);
  }));

  apiRouter.put("/questions/:id", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const questionId = parseInt(req.params.id);
    const existingQuestion = await storage.getQuestionById(questionId);

    if (!existingQuestion) {
      return res.status(404).json({ message: "Question not found" });
    }

    const updateData = insertQuestionSchema.partial().parse(req.body);
    const updatedQuestion = await storage.updateQuestion(questionId, updateData);

    res.json(updatedQuestion);
  }));

  apiRouter.delete("/questions/:id", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const questionId = parseInt(req.params.id);
    const success = await storage.deleteQuestion(questionId);

    if (!success) {
      return res.status(404).json({ message: "Question not found" });
    }

    res.json({ message: "Question deleted successfully" });
  }));

  // User Progress API endpoints
  apiRouter.post("/user-progress", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const progressData = insertUserProgressSchema.parse({
      ...req.body,
      userId: req.session.userId
    });

    const progress = await storage.createOrUpdateUserProgress(progressData);

    res.status(201).json(progress);
  }));

  apiRouter.get("/user-progress", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const progress = await storage.getUserProgressByUserId(req.session.userId);

    res.json(progress);
  }));

  apiRouter.get("/user-progress/book/:bookId", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { bookId } = req.params;
    const progress = await storage.getUserProgressByBookId(req.session.userId, bookId);

    if (!progress) {
      return res.json(null);
    }

    res.json(progress);
  }));

  apiRouter.get("/user-progress/lesson/:lessonId", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const lessonId = parseInt(req.params.lessonId);
    const progress = await storage.getUserProgressByLessonId(req.session.userId, lessonId);

    if (!progress) {
      return res.json(null);
    }

    res.json(progress);
  }));

  apiRouter.get("/user-progress/quiz/:quizId", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const quizId = parseInt(req.params.quizId);
    const progress = await storage.getUserProgressByQuizId(req.session.userId, quizId);

    if (!progress) {
      return res.json(null);
    }

    res.json(progress);
  }));

  // Educational Media API Routes

  // Create educational media
  apiRouter.post("/educational-media", handleError(async (req, res) => {
    const mediaData = insertEducationalMediaSchema.parse(req.body);
    const media = await storage.createEducationalMedia(mediaData);
    res.status(201).json(media);
  }));

  // Get educational media by lesson ID
  apiRouter.get("/educational-media/lesson/:lessonId", handleError(async (req, res) => {
    const lessonId = parseInt(req.params.lessonId);
    const mediaList = await storage.getEducationalMediaByLessonId(lessonId);
    res.json(mediaList);
  }));

  // Get media counts by lesson ID for badges
  apiRouter.get("/educational-media/counts/:lessonId", handleError(async (req, res) => {
    const lessonId = parseInt(req.params.lessonId);
    const mediaList = await storage.getEducationalMediaByLessonId(lessonId);

    const videoCount = mediaList.filter(item => item.mediaType === "video").length;
    const presentationCount = mediaList.filter(item => item.mediaType === "presentation").length;

    res.json({
      videoCount,
      presentationCount,
      totalCount: mediaList.length
    });
  }));

  // Get educational media by ID
  apiRouter.get("/educational-media/:id", handleError(async (req, res) => {
    const id = parseInt(req.params.id);
    const media = await storage.getEducationalMediaById(id);

    if (!media) {
      return res.status(404).json({ message: "Educational media not found" });
    }

    res.json(media);
  }));

  // Update educational media
  apiRouter.patch("/educational-media/:id", handleError(async (req, res) => {
    const id = parseInt(req.params.id);
    const mediaData = insertEducationalMediaSchema.partial().parse(req.body);

    try {
      const media = await storage.updateEducationalMedia(id, mediaData);
      res.json(media);
    } catch (error) {
      res.status(404).json({ message: "Educational media not found" });
    }
  }));

  // Delete educational media
  apiRouter.delete("/educational-media/:id", handleError(async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteEducationalMedia(id);

    if (!success) {
      return res.status(404).json({ message: "Educational media not found" });
    }

    res.status(204).send();
  }));

  // Quiz generation API endpoint
  apiRouter.post("/generate-quiz", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { 
      bookId,
      lessonId,
      contentText,
      difficulty,
      questionTypes,
      numberOfQuestions
    } = generateQuizRequestSchema.parse(req.body);

    // If lessonId is provided, get the lesson content
    let content = contentText;
    if (lessonId && !contentText) {
      const lesson = await storage.getLessonById(lessonId);
      if (!lesson) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      content = lesson.content;
    }

    if (!content) {
      return res.status(400).json({ message: "Either lessonId or contentText must be provided" });
    }

    // Generate the quiz using an AI service
    // This is just a placeholder - we would normally integrate with an AI service here
    const quiz = {
      title: `Quiz on ${lessonId ? `Lesson ${lessonId}` : 'Custom Content'}`,
      description: `Auto-generated quiz with ${numberOfQuestions} questions`,
      difficulty: difficulty,
      bookId: bookId,
      lessonId: lessonId,
      timeLimit: 15, // Default time limit in minutes
      passingScore: 70 // Default passing score
    };

    const createdQuiz = await storage.createQuiz(quiz);

    // Now generate questions for the quiz
    // This is a placeholder for AI-generated questions
    const questions = [];

    // Save the generated questions
    for (let i = 0; i < numberOfQuestions; i++) {
      const questionType = questionTypes[i % questionTypes.length];

      const questionData = {
        quizId: createdQuiz.id,
        lessonId: lessonId,
        questionType,
        questionText: `Question ${i + 1} about the content`,
        options: questionType === 'multiple-choice' ? ['Option A', 'Option B', 'Option C', 'Option D'] : null,
        correctAnswers: questionType === 'multiple-choice' ? ['Option A'] : 
                      questionType === 'true-false' ? ['true'] : ['Sample answer'],
        explanation: 'Explanation for the answer',
        points: 1,
        orderIndex: i
      };

      const question = await storage.createQuestion(questionData);
      questions.push(question);
    }

    res.status(201).json({
      quiz: createdQuiz,
      questions
    });
  }));

  // Lesson audio generation API endpoint
  apiRouter.post("/generate-lesson-audio", handleError(async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { 
      lessonId,
      voiceType,
      speed,
      includeExplanations
    } = generateLessonAudioRequestSchema.parse(req.body);

    const lesson = await storage.getLessonById(lessonId);
    if (!lesson) {
      return res.status(404).json({ message: "Lesson not found" });
    }

    // Here we would normally generate audio using a text-to-speech service
    // This is just a placeholder response
    const audioUrl = `/api/static/audio/lessons/lesson-${lessonId}.mp3`;
    const duration = Math.floor((lesson.content.length / 20) * (1 / speed)); // Rough estimate

    // Update lesson with audio URL and duration
    const updatedLesson = await storage.updateLesson(lessonId, {
      audioUrl,
      duration
    });

    res.json({
      lesson: updatedLesson,
      audioUrl,
      duration
    });
  }));

  // Perplexity AI Islamic Knowledge API endpoints
  apiRouter.post("/islamic-questions", handleError(async (req, res) => {
    if (!perplexityService.isAvailable()) {
      return res.status(503).json({ message: "Perplexity API not available" });
    }

    const { 
      question, 
      language = 'en',
      focusArea = 'general'
    } = req.body;

    if (!question || typeof question !== 'string') {
      throw new Error("Question is required");
    }

    // If we have a focus area, use the search API with the question as a query
    if (focusArea && focusArea !== 'general') {
      const result = await perplexityService.searchIslamicKnowledge(
        question,
        focusArea as 'quran' | 'hadith' | 'fiqh',
        language
      );

      return res.json({
        answer: result.results,
        citations: result.citations
      });
    }

    // Otherwise use the question answering API
    const result = await perplexityService.answerIslamicQuestion(
      question,
      language
    );

    res.json(result);
  }));

  apiRouter.post("/islamic-knowledge-search", handleError(async (req, res) => {
    if (!perplexityService.isAvailable()) {
      return res.status(503).json({ message: "Perplexity API not available" });
    }

    const { 
      query, 
      focusArea = 'general', 
      language = 'en' 
    } = req.body;

    if (!query || typeof query !== 'string') {
      throw new Error("Search query is required");
    }

    if (!['quran', 'hadith', 'fiqh', 'general'].includes(focusArea)) {
      throw new Error("Invalid focus area. Must be one of: quran, hadith, fiqh, general");
    }

    const result = await perplexityService.searchIslamicKnowledge(
      query,
      focusArea as 'quran' | 'hadith' | 'fiqh' | 'general',
      language
    );

    res.json(result);
  }));

  apiRouter.post("/validate-islamic-content", handleError(async (req, res) => {
    if (!perplexityService.isAvailable()) {
      return res.status(503).json({ message: "Perplexity API not available" });
    }

    const { content, language = 'en' } = req.body;

    if (!content || typeof content !== 'string') {
      throw new Error("Content is required");
    }

    const result = await perplexityService.validateIslamicContent(
      content,
      language
    );

    res.json(result);
  }));

  // Mount the API router
  app.use("/api", apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}