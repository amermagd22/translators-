import express from 'express';
import { Anthropic } from '@anthropic-ai/sdk';
import express, { type Express } from "express";
import { createServer } from "http";
import { registerRoutes } from './routes';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// إعداد Anthropic
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || '',
});

// تسجيل المسارات وبدء الخادم
(async () => {
  const server = await registerRoutes(app);

  const PORT = process.env.PORT || 5000;

  function startServer(port: number) {
    const server = app.listen(port, '0.0.0.0', () => {
      console.log(`Server running on port ${port}`);
    }).on('error', (err: any) => {
      if (err.code === 'EADDRINUSE') {
        console.log(`Port ${port} is busy, trying ${port + 1}`);
        startServer(port + 1);
      } else {
        console.error('Server error:', err);
      }
    });
  }

  startServer(PORT);
})();

// Error Handling (from original code, adapted)
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
});