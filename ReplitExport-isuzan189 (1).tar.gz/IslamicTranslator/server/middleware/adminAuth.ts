import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';

// رمز المصادقة الخاص - يجب تغييره إلى رمز آمن خاص بك
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'MasMasMas56@';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'suzan';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'amermagd00@gmail.com';

// وظيفة لإعادة تعيين كلمة المرور
export async function resetPassword(email: string): Promise<boolean> {
  if (email === ADMIN_EMAIL) {
    // إرسال رسالة إعادة تعيين كلمة المرور إلى البريد الإلكتروني
    // هذه مجرد محاكاة للعملية
    console.log(`تم إرسال رابط إعادة تعيين كلمة المرور إلى ${email}`);
    return true;
  }
  return false;
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: "غير مصرح - الرمز مفقود" });
  }

  const token = authHeader.split(' ')[1];

  if (token !== ADMIN_TOKEN) {
    return res.status(403).json({ message: "ممنوع - رمز غير صالح" });
  }

  next();
}

export function isAdmin(username: string): boolean {
  return username === ADMIN_USERNAME;
}