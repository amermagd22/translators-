import { openaiService } from "./openai";
import { islamicContentDetector } from "./islamicContentDetector";

// Specialized service for Quranic translations with high accuracy and tafsir integration
export class QuranTranslatorService {
  // Respected Quran translations sources
  private translationSources = {
    'en': [
      'Sahih International',
      'Pickthall',
      'Yusuf Ali',
      'Dr. Mustafa Khattab',
      'Dr. Mohsin Khan'
    ],
    'fr': [
      'Muhammad Hamidullah',
      'Le Complexe du Roi Fahd'
    ],
    'de': [
      'Bubenheim & Elyas',
      'Zaidan'
    ],
    'tr': [
      'Diyanet İşleri',
      'Ali Ünal'
    ],
    'ur': [
      'Ahmed Ali',
      'Jalandhry',
      'Maududi'
    ]
  };

  // Respected tafsir sources
  private tafsirSources = [
    'Ibn Kathir',
    'Al-Tabari',
    'Al-Qurtubi',
    'Al-Saadi',
    'Al-Baghawi',
    'Maariful Quran',
    'Tafsir Al-Jalalayn'
  ];

  // Important Quranic terms that should be preserved
  private preservedTerms = {
    'Allah': true,
    'Salah': true,
    'Zakat': true,
    'Sawm': true,
    'Hajj': true,
    'Sunnah': true,
    'Hadith': true,
    'Taqwa': true,
    'Iman': true,
    'Kufr': true,
    'Shirk': true,
    'Tawhid': true,
    'Jannah': true,
    'Jahannam': true,
    'Akhirah': true,
    'Dunya': true
  };

  // Check if text contains Quranic verses
  async detectQuranicContent(text: string, language: string): Promise<{
    isQuran: boolean;
    confidence: number;
    detectedSurah?: string;
    containsDiacritics: boolean;
    containsBasmala: boolean;
  }> {
    // Check for diacritics (common in Quranic text)
    const containsDiacritics = /[\u064B-\u065F\u0670]/.test(text);
    
    // Check for Basmala
    const containsBasmala = text.includes('بسم الله الرحمن الرحيم') || 
                            text.includes('In the name of Allah, the Most Gracious, the Most Merciful');
    
    // Common patterns that indicate Quranic text
    const quranicPatterns = [
      'سورة',
      'آية',
      'قال تعالى',
      'قال الله تعالى',
      'Surah',
      'Ayah',
      'Verse',
      'Allah says',
    ];

    // Check for these patterns
    let patternMatches = 0;
    for (const pattern of quranicPatterns) {
      if (text.includes(pattern)) {
        patternMatches++;
      }
    }

    // Surah name detection (simplified)
    const surahNames = [
      'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف',
      'Al-Fatihah', 'Al-Baqarah', 'Ali-Imran', 'An-Nisa', 'Al-Maidah', 'Al-Anam', 'Al-Araf'
    ];
    
    let detectedSurah = undefined;
    for (const surah of surahNames) {
      if (text.includes(surah)) {
        detectedSurah = surah;
        break;
      }
    }

    // Use Islamic content detector as additional verification
    const islamicAnalysis = await islamicContentDetector.detectIslamicContent(text, language);
    
    // Determine if it's Quranic with a confidence score
    const isQuran = (containsBasmala || 
                     containsDiacritics || 
                     patternMatches >= 2 || 
                     detectedSurah !== undefined ||
                     (islamicAnalysis.isIslamic && islamicAnalysis.hasQuranicVerses));
    
    // Calculate confidence score
    let confidence = 0.5;
    if (containsBasmala) confidence += 0.3;
    if (containsDiacritics) confidence += 0.2;
    if (patternMatches >= 2) confidence += 0.15;
    if (detectedSurah) confidence += 0.25;
    if (islamicAnalysis.hasQuranicVerses) confidence += 0.3;
    
    // Cap confidence at 0.95
    confidence = Math.min(0.95, confidence);

    return {
      isQuran,
      confidence,
      detectedSurah,
      containsDiacritics,
      containsBasmala
    };
  }

  // Specialized Quranic translation with tafsir integration
  async translateQuranicText(
    text: string,
    sourceLanguage: string,
    targetLanguage: string,
    options: {
      includeTransliteration?: boolean;
      includeTafsir?: boolean;
      preferredTafsir?: string;
      preserveStructure?: boolean;
      includeSurahInfo?: boolean;
    } = {}
  ): Promise<{
    translatedText: string;
    transliteration?: string;
    tafsir?: string;
    surahInfo?: {
      name: string;
      number?: number;
      theme?: string;
    };
    sourceUsed?: string;
  }> {
    try {
      // First, verify it's actually Quranic text
      const quranicCheck = await this.detectQuranicContent(text, sourceLanguage);
      
      if (!quranicCheck.isQuran) {
        throw new Error("The provided text does not appear to be Quranic in nature.");
      }
      
      // For this implementation we'll use OpenAI with specialized prompting
      // In a production app, this would connect to specific Quran translation APIs
      // or databases containing verified translations
      
      // Prepare specialized translation prompt
      let systemPrompt = `You are a highly respected Quranic translator with expertise in tafsir and Islamic scholarship. 
Your task is to provide the most accurate translation of the Quranic text, adhering to these guidelines:

1. Preserve all Islamic terminology without translation (Allah, salah, zakat, etc.)
2. Maintain the poetic structure and rhythm of the text where possible
3. Be extremely precise and faithful to the original meaning
4. Add respectful phrases after mentions of Allah or prophets
5. Base your translation on respected sources like ${this.getPreferredSources(targetLanguage).join(', ')}
6. Never simplify or omit any part of the text
7. Maintain the depth and nuance of the original Arabic`;

      // Add tafsir guidelines if requested
      if (options.includeTafsir) {
        const preferredTafsir = options.preferredTafsir || this.tafsirSources[0];
        systemPrompt += `\n8. Include a brief tafsir explanation based on ${preferredTafsir} to clarify difficult concepts
9. Separate the translation and tafsir clearly`;
      }
      
      // Add transliteration guidelines if requested
      if (options.includeTransliteration) {
        systemPrompt += `\n10. Provide an accurate transliteration that follows scholarly conventions
11. Use diacritical marks in the transliteration to aid pronunciation`;
      }

      // Translate the Quranic text using the specialized prompt
      const translationResponse = await openaiService.enhanceTranslation(
        text,
        sourceLanguage,
        targetLanguage,
        true, // Always preserve Islamic terms in Quranic translation
        systemPrompt
      );
      
      // For demonstration purposes, we'll create a basic structure
      // In a real implementation, this would be more sophisticated and
      // connected to Quranic databases
      let result: {
        translatedText: string;
        transliteration?: string;
        tafsir?: string;
        surahInfo?: {
          name: string;
          number?: number;
          theme?: string;
        };
        sourceUsed?: string;
      } = {
        translatedText: translationResponse,
        sourceUsed: this.getPreferredSources(targetLanguage)[0]
      };
      
      // Add surah info if detected and requested
      if (options.includeSurahInfo && quranicCheck.detectedSurah) {
        result.surahInfo = {
          name: quranicCheck.detectedSurah,
          // In a real app, we would look up the actual number and theme
          theme: "This would contain the theme of the surah from authentic sources"
        };
      }
      
      // In a real implementation, we would extract the transliteration and tafsir
      // from specialized APIs or databases. For this demo, we'll indicate where they would be.
      if (options.includeTransliteration) {
        result.transliteration = "This would contain the scholarly transliteration of the Quranic text";
      }
      
      if (options.includeTafsir) {
        result.tafsir = "This would contain tafsir from the selected source, explaining the deeper meaning and context of the verses";
      }
      
      return result;
    } catch (error) {
      console.error("Error translating Quranic text:", error);
      throw new Error("Failed to translate Quranic text: " + (error as Error).message);
    }
  }

  // Get preferred translation sources for target language
  private getPreferredSources(language: string): string[] {
    return this.translationSources[language as keyof typeof this.translationSources] || 
           this.translationSources['en']; // Default to English sources
  }

  // Helper method to preserve Islamic terms
  private preserveIslamicTerms(text: string): string {
    const words = text.split(/\s+/);
    const preservedWords = words.map(word => {
      const cleanWord = word.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
      if (this.preservedTerms[cleanWord]) {
        return word; // Keep as is
      }
      return word; // Would be replaced with translation in a real implementation
    });
    
    return preservedWords.join(' ');
  }
}

export const quranTranslatorService = new QuranTranslatorService();