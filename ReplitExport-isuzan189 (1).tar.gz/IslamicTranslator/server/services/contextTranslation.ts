import { openaiService } from "./openai";
import { filterService } from "./filter";
import { islamicContentDetector } from "./islamicContentDetector";

// Advanced contextual translation service
export class ContextTranslationService {
  // Supported dialects for Arabic language
  private arabicDialects = [
    { code: 'ar-standard', name: 'الفصحى', description: 'Arabic (Modern Standard)' },
    { code: 'ar-eg', name: 'مصري', description: 'Egyptian Arabic' },
    { code: 'ar-gulf', name: 'خليجي', description: 'Gulf Arabic' },
    { code: 'ar-levant', name: 'شامي', description: 'Levantine Arabic' },
    { code: 'ar-maghreb', name: 'مغربي', description: 'Maghrebi Arabic' },
    { code: 'ar-classical', name: 'فصحى كلاسيكية', description: 'Classical Arabic' }
  ];

  // Special domains with specialized vocabulary
  private specializedDomains = [
    'scientific',
    'medical',
    'legal',
    'technical',
    'religious',
    'academic',
    'literature',
    'business',
    'media',
    'diplomatic'
  ];

  // Technical terminology dictionaries (simplified example)
  private domainTerminology = {
    medical: {
      ar: {
        'blood pressure': 'ضغط الدم',
        'cardiovascular': 'قلبي وعائي',
        'immune system': 'جهاز المناعة'
      },
      en: {
        'ضغط الدم': 'blood pressure',
        'قلبي وعائي': 'cardiovascular',
        'جهاز المناعة': 'immune system'
      }
    },
    scientific: {
      ar: {
        'quantum': 'كمي',
        'relativity': 'النسبية',
        'gravity': 'الجاذبية'
      },
      en: {
        'كمي': 'quantum',
        'النسبية': 'relativity',
        'الجاذبية': 'gravity'
      }
    },
    religious: {
      ar: {
        'prayer': 'صلاة',
        'fasting': 'صيام',
        'pilgrimage': 'حج'
      },
      en: {
        'صلاة': 'prayer (salah)',
        'صيام': 'fasting (sawm)',
        'حج': 'pilgrimage (hajj)'
      }
    }
  };

  // Cultural expressions and idioms
  private culturalExpressions = {
    ar: {
      'break a leg': 'بالتوفيق',
      'speak of the devil': 'اللي بنحكي عنه جه',
      'piece of cake': 'سهل جدًا',
      'under the weather': 'متوعك'
    },
    en: {
      'إن شاء الله': 'God willing (in-sha-Allah)',
      'ما شاء الله': 'What God has willed (ma-sha-Allah)',
      'على راسي': 'It would be my honor (literally: on my head)',
      'يسلمو إيديك': 'Bless your hands (thank you for making something)'
    }
  };

  // Detect dialectal variations in Arabic text
  async detectDialect(text: string): Promise<{
    standardArabic: boolean;
    detectedDialect?: string;
    dialectScore: number;
    formalityLevel: 'formal' | 'informal' | 'neutral';
  }> {
    // Dialectal markers (simplified)
    const dialectMarkers = {
      'egyptian': ['إيه', 'فين', 'إزيك', 'عايز', 'دلوقتي', 'بتاع'],
      'gulf': ['شلونك', 'وين', 'مطيّر', 'زين', 'هواية'],
      'levantine': ['كيفك', 'شو', 'هلأ', 'هيك', 'بدي'],
      'maghrebi': ['واش', 'فين', 'بزاف', 'لابأس']
    };

    // Features of classical vs. modern standard Arabic
    const classicalMarkers = ['إنّ', 'إذ', 'لعمرك', 'أمّا بعد', 'إنّي', 'ولقد'];

    let dialectCounts: {[key: string]: number} = {
      'standard': 0,
      'classical': 0,
      'egyptian': 0, 
      'gulf': 0,
      'levantine': 0,
      'maghrebi': 0
    };

    // Count dialect markers
    for (const [dialect, markers] of Object.entries(dialectMarkers)) {
      for (const marker of markers) {
        if (text.includes(marker)) {
          dialectCounts[dialect]++;
        }
      }
    }

    // Check classical Arabic markers
    for (const marker of classicalMarkers) {
      if (text.includes(marker)) {
        dialectCounts['classical']++;
      }
    }

    // Determine formality level
    const informalMarkers = ['حبيبي', 'يا غالي', 'عزيزي', 'يسطا', 'ياخي'];
    const formalMarkers = ['حضرتك', 'سيادتكم', 'سعادتكم', 'معالي', 'فضيلة'];
    
    let formalCount = 0;
    let informalCount = 0;

    for (const marker of informalMarkers) {
      if (text.includes(marker)) informalCount++;
    }
    
    for (const marker of formalMarkers) {
      if (text.includes(marker)) formalCount++;
    }

    // Determine most likely dialect
    let maxDialect = 'standard';
    let maxCount = 0;
    
    for (const [dialect, count] of Object.entries(dialectCounts)) {
      if (count > maxCount) {
        maxCount = count;
        maxDialect = dialect;
      }
    }

    // If no specific dialect markers found, default to standard
    const standardArabic = maxDialect === 'standard' || maxDialect === 'classical';
    const dialectScore = maxCount > 0 ? (maxCount / text.split(' ').length) : 0;

    // Determine formality level
    let formalityLevel: 'formal' | 'informal' | 'neutral' = 'neutral';
    if (formalCount > informalCount) {
      formalityLevel = 'formal';
    } else if (informalCount > formalCount) {
      formalityLevel = 'informal';
    }

    return {
      standardArabic,
      detectedDialect: standardArabic ? undefined : maxDialect,
      dialectScore,
      formalityLevel
    };
  }

  // Detect domain/topic of the text
  async detectDomain(text: string, language: string): Promise<{
    domain: string;
    confidence: number;
    specializedTerminology: boolean;
  }> {
    // Technical domain keywords
    const domainKeywords: {[key: string]: string[]} = {
      'medical': ['patient', 'doctor', 'disease', 'treatment', 'hospital', 'مريض', 'طبيب', 'مرض', 'علاج', 'مستشفى'],
      'scientific': ['research', 'experiment', 'theory', 'analysis', 'بحث', 'تجربة', 'نظرية', 'تحليل'],
      'legal': ['court', 'law', 'judge', 'evidence', 'محكمة', 'قانون', 'قاضي', 'دليل'],
      'religious': ['prayer', 'God', 'worship', 'faith', 'صلاة', 'الله', 'عبادة', 'إيمان'],
      'technical': ['computer', 'software', 'system', 'data', 'حاسوب', 'برمجيات', 'نظام', 'بيانات'],
      'business': ['company', 'market', 'profit', 'sales', 'شركة', 'سوق', 'ربح', 'مبيعات']
    };

    // Count domain keywords
    const domainCounts: {[key: string]: number} = {};
    for (const [domain, keywords] of Object.entries(domainKeywords)) {
      domainCounts[domain] = 0;
      for (const keyword of keywords) {
        if (text.toLowerCase().includes(keyword.toLowerCase())) {
          domainCounts[domain]++;
        }
      }
    }

    // Find the domain with highest count
    let maxDomain = 'general';
    let maxCount = 0;
    
    for (const [domain, count] of Object.entries(domainCounts)) {
      if (count > maxCount) {
        maxCount = count;
        maxDomain = domain;
      }
    }

    // Check for specialized terminology
    const specializedTerminology = maxCount > 3;
    const confidence = maxCount > 0 ? Math.min(0.9, (maxCount / 10)) : 0.5;

    return {
      domain: maxCount > 2 ? maxDomain : 'general',
      confidence,
      specializedTerminology
    };
  }

  // Convert between dialects
  async convertDialect(text: string, sourceDialect: string, targetDialect: string): Promise<string> {
    // In a production app, this would use a specialized model for dialect conversion
    try {
      const result = await openaiService.enhanceTranslation(
        text,
        `ar-${sourceDialect}`,
        `ar-${targetDialect}`,
        false
      );
      return result;
    } catch (error) {
      console.error("Dialect conversion error:", error);
      return text; // Return original if conversion fails
    }
  }

  // Perform context-aware translation
  async translateWithContext(
    text: string,
    sourceLanguage: string,
    targetLanguage: string,
    contextOptions: {
      domain?: string;
      preserveStyle?: boolean;
      dialectHandling?: 'preserve' | 'standardize';
      formalityLevel?: 'formal' | 'informal' | 'auto';
      culturalAdaptation?: boolean;
      preferredDialect?: string;
    } = {}
  ): Promise<{
    translatedText: string;
    detectedDomain?: string;
    detectedDialect?: string;
    adaptedCulturalExpressions?: boolean;
    appliedSpecializedTerminology?: boolean;
    preservedFormatting?: boolean;
    religiousContentHandled?: boolean;
  }> {
    try {
      // Detect if content has Islamic references
      const islamicContent = await islamicContentDetector.detectIslamicContent(text, sourceLanguage);

      // Detect source dialect if it's Arabic
      let dialectInfo: {
        standardArabic: boolean; 
        detectedDialect?: string; 
        dialectScore?: number; 
        formalityLevel: 'formal' | 'informal' | 'neutral'
      } = { 
        standardArabic: true, 
        formalityLevel: 'neutral' 
      };
      
      if (sourceLanguage === 'ar') {
        dialectInfo = await this.detectDialect(text);
      }

      // Detect domain/topic
      const domainInfo = await this.detectDomain(text, sourceLanguage);
      const detectedDomain = domainInfo.domain;

      // Determine which domain to use (detected or specified)
      const activeDomain = contextOptions.domain || detectedDomain;

      // Apply specialized terminology if available for the domain
      let enhancedText = text;
      let appliedSpecializedTerminology = false;
      
      if (domainInfo.specializedTerminology && this.domainTerminology[activeDomain as keyof typeof this.domainTerminology]) {
        // Get the terminology dictionary for the active domain
        const terminologyDict = this.domainTerminology[activeDomain as keyof typeof this.domainTerminology][sourceLanguage as 'ar' | 'en'];
        if (terminologyDict) {
          for (const [term, translation] of Object.entries(terminologyDict)) {
            const regex = new RegExp(`\\b${term}\\b`, 'gi');
            enhancedText = enhancedText.replace(regex, translation);
          }
          appliedSpecializedTerminology = true;
        }
      }

      // Handle dialectal variations if requested and source is Arabic
      if (sourceLanguage === 'ar' && contextOptions.dialectHandling) {
        if (contextOptions.dialectHandling === 'standardize' && !dialectInfo.standardArabic) {
          // Convert dialect to MSA (Modern Standard Arabic)
          enhancedText = await this.convertDialect(
            enhancedText, 
            dialectInfo.detectedDialect || 'standard', 
            'standard'
          );
        }
      }

      // Determine formality level
      let formalityLevel = dialectInfo.formalityLevel;
      if (contextOptions.formalityLevel && contextOptions.formalityLevel !== 'auto') {
        formalityLevel = contextOptions.formalityLevel;
      }

      // Filter content according to Islamic values
      enhancedText = await filterService.filterContent(enhancedText, sourceLanguage);

      // Detect culturally-specific expressions
      let adaptedCulturalExpressions = false;
      if (contextOptions.culturalAdaptation) {
        const culturalDict = this.culturalExpressions[sourceLanguage as 'ar' | 'en'];
        if (culturalDict) {
          for (const [expression, adaptation] of Object.entries(culturalDict)) {
            if (enhancedText.includes(expression)) {
              const regex = new RegExp(`\\b${expression}\\b`, 'g');
              enhancedText = enhancedText.replace(regex, adaptation);
              adaptedCulturalExpressions = true;
            }
          }
        }
      }

      // Special handling for religious content
      let religiousContentHandled = false;
      if (islamicContent.isIslamic) {
        enhancedText = await islamicContentDetector.enhanceWithRespectfulPhrases(
          enhancedText, sourceLanguage
        );
        religiousContentHandled = true;
      }

      // Now perform the main translation using OpenAI
      const translationResult = await openaiService.enhanceTranslation(
        enhancedText,
        sourceLanguage,
        targetLanguage,
        islamicContent.isIslamic // Preserve Islamic terms if religious content
      );
      
      // Handle dialect in the translation if Arabic is the target language
      let finalTranslation = translationResult;
      if (targetLanguage === 'ar' && contextOptions.preferredDialect && contextOptions.preferredDialect !== 'standard') {
        finalTranslation = await this.convertDialect(
          finalTranslation,
          'standard',
          contextOptions.preferredDialect
        );
      }

      // Return the enhanced context-aware translation with metadata
      return {
        translatedText: finalTranslation,
        detectedDomain: domainInfo.domain,
        detectedDialect: dialectInfo.detectedDialect,
        adaptedCulturalExpressions,
        appliedSpecializedTerminology,
        preservedFormatting: contextOptions.preserveStyle || false,
        religiousContentHandled
      };
    } catch (error) {
      console.error("Context-aware translation error:", error);
      throw new Error("Failed to perform context-aware translation");
    }
  }

  // Specialized translations for various content types
  async translateSpecializedContent(
    text: string,
    sourceLanguage: string,
    targetLanguage: string,
    contentType: 'poetry' | 'technical' | 'academic' | 'conversational' | 'religious' | 'literary'
  ): Promise<string> {
    try {
      // Different prompt strategies based on content type
      let preserveStyle = false;
      let domain: string | undefined;
      let dialectHandling: 'preserve' | 'standardize' = 'standardize';
      let formalityLevel: 'formal' | 'informal' | 'auto' = 'auto';
      
      switch (contentType) {
        case 'poetry':
          preserveStyle = true;
          dialectHandling = 'preserve';
          break;
          
        case 'technical':
          domain = 'technical';
          formalityLevel = 'formal';
          break;
          
        case 'academic':
          domain = 'academic';
          formalityLevel = 'formal';
          break;
          
        case 'conversational':
          dialectHandling = 'preserve';
          formalityLevel = 'informal';
          break;
          
        case 'religious':
          domain = 'religious';
          formalityLevel = 'formal';
          break;
          
        case 'literary':
          preserveStyle = true;
          formalityLevel = 'formal';
          break;
      }
      
      // Use the context-aware translation with the appropriate settings
      const result = await this.translateWithContext(
        text,
        sourceLanguage,
        targetLanguage,
        {
          domain,
          preserveStyle,
          dialectHandling,
          formalityLevel,
          culturalAdaptation: true
        }
      );
      
      return result.translatedText;
    } catch (error) {
      console.error(`Error in specialized ${contentType} translation:`, error);
      throw new Error(`Failed to translate ${contentType} content`);
    }
  }
}

export const contextTranslationService = new ContextTranslationService();