import OpenAI from "openai";
import { storage } from "../storage";

// Enhanced OpenAI service for improved translation, text analysis, and image processing
export class OpenAIService {
  private openai: OpenAI;
  
  constructor() {
    // Initialize OpenAI client with API key from environment variables
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  // Enhanced translation using GPT model
  async enhanceTranslation(
    sourceText: string,
    sourceLanguage: string,
    targetLanguage: string,
    preserveIslamicTerms: boolean = true
  ): Promise<string> {
    try {
      // Create system prompt that sets translation guidelines
      let systemPrompt = `You are an expert translator from ${sourceLanguage} to ${targetLanguage} with deep knowledge of Islamic terminology and cultural nuances.`;
      
      if (preserveIslamicTerms) {
        systemPrompt += ` Preserve Islamic religious terms in their original form with proper transliteration where appropriate.
          For example, keep 'Allah' instead of translating to 'God', 'salah' or 'salat' instead of just 'prayer',
          and add respectful phrases like 'peace be upon him' after mentions of prophets if they're not already present.`;
      }
      
      // Add cultural sensitivity instruction
      systemPrompt += ` Ensure translations are culturally appropriate and aligned with Islamic values.
        Avoid using terms or expressions that conflict with Islamic principles when translating cultural concepts.`;

      // Send request to OpenAI
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { 
            role: "user", 
            content: `Translate the following ${sourceLanguage} text to ${targetLanguage}:\n\n${sourceText}`
          }
        ],
        temperature: 0.3, // Lower temperature for more consistent translations
      });

      return response.choices[0].message.content || sourceText;
    } catch (error) {
      console.error("OpenAI translation enhancement error:", error);
      // Return original text if translation fails
      return sourceText;
    }
  }

  // Text analysis for content filtering
  async analyzeContentForFiltering(text: string, language: string): Promise<{
    containsProhibitedContent: boolean;
    categories: string[];
    filteredText: string;
  }> {
    try {
      // Define system prompt for content analysis
      const systemPrompt = `You are an AI assistant specialized in Islamic content moderation.
        Your task is to identify and filter content that would be inappropriate according to Islamic values.
        Analyze the text for prohibited content such as:
        1. References to alcohol or intoxicants
        2. Inappropriate relationships or sexual content
        3. Gambling references
        4. Blasphemous or disrespectful mentions of religion
        5. Profanity or vulgar language
        Return your analysis in JSON format with the following fields:
        - containsProhibitedContent: boolean (true if any prohibited content is found)
        - categories: array of strings (categories of prohibited content found)
        - filteredText: string (the original text with prohibited content replaced with appropriate alternatives)`;

      // Send request to OpenAI
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Analyze and filter this ${language} text: ${text}` }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2,
      });

      // Parse the response
      const analysisResult = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        containsProhibitedContent: analysisResult.containsProhibitedContent || false,
        categories: analysisResult.categories || [],
        filteredText: analysisResult.filteredText || text
      };
    } catch (error) {
      console.error("OpenAI content analysis error:", error);
      // Return safe defaults if analysis fails
      return {
        containsProhibitedContent: false,
        categories: [],
        filteredText: text
      };
    }
  }

  // Image to text extraction with enhanced accuracy
  async extractTextFromImage(imageBase64: string, sourceLanguage: string): Promise<string> {
    try {
      // Send request to OpenAI Vision
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an expert in text extraction from images. Extract all visible text from the image accurately.
              If the text appears to be in ${sourceLanguage}, pay special attention to language-specific characters and formatting.
              If you detect any Islamic content, such as Quranic verses or religious texts, handle them respectfully and preserve their exact wording.`
          },
          {
            role: "user",
            content: [
              { type: "text", text: `Extract all text from this image in the original language:` },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${imageBase64}`
                }
              }
            ],
          },
        ],
        max_tokens: 1000,
      });

      return response.choices[0].message.content || "";
    } catch (error) {
      console.error("OpenAI image text extraction error:", error);
      return "Error: Could not extract text from the image.";
    }
  }

  // Cultural context analysis for more accurate translations
  async analyzeCulturalContext(text: string, language: string): Promise<{
    culturalContext: string;
    religiousContext: boolean;
    formalityLevel: string;
    recommendations: string[];
  }> {
    try {
      // Send request to OpenAI
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an expert in cultural and linguistic analysis with special expertise in Islamic culture and values.
              Analyze the provided text and identify its cultural context, whether it has religious significance,
              the level of formality, and provide recommendations for culturally appropriate translation.`
          },
          { role: "user", content: `Analyze this ${language} text: ${text}` }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
      });

      // Parse the response
      const analysisResult = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        culturalContext: analysisResult.culturalContext || "general",
        religiousContext: analysisResult.religiousContext || false,
        formalityLevel: analysisResult.formalityLevel || "neutral",
        recommendations: analysisResult.recommendations || []
      };
    } catch (error) {
      console.error("OpenAI cultural context analysis error:", error);
      // Return defaults if analysis fails
      return {
        culturalContext: "general",
        religiousContext: false,
        formalityLevel: "neutral",
        recommendations: []
      };
    }
  }
}

export const openaiService = new OpenAIService();