import { openaiService } from "./openai";
import { islamicContentDetector } from "./islamicContentDetector";
import { filterService } from "./filter";

// Advanced Islamic content verification and validation service
export class ContentCheckerService {
  // Categories of content that require verification
  private verificationCategories = [
    'aqeedah', // Islamic creed/beliefs
    'fiqh', // Islamic jurisprudence
    'tafsir', // Quranic interpretation
    'hadith', // Prophetic traditions
    'general', // General Islamic concepts
    'history', // Islamic history
    'terminology' // Islamic terms and concepts
  ];

  // Common issues to check for
  private checkIssues = [
    'inaccurate_translation',
    'disrespectful_tone',
    'missing_honorifics',
    'theological_error',
    'sectarian_bias',
    'prohibited_content',
    'misquoted_scripture',
    'cultural_insensitivity',
    'incorrect_terminology'
  ];

  // Respected scholarly sources for verification
  private scholarlyReferences = [
    {
      name: 'Tafsir Ibn Kathir',
      category: 'tafsir',
      priority: 'high'
    },
    {
      name: 'Sahih Al-Bukhari',
      category: 'hadith',
      priority: 'high'
    },
    {
      name: 'Sahih Muslim',
      category: 'hadith',
      priority: 'high'
    },
    {
      name: 'Fiqh-us-Sunnah',
      category: 'fiqh',
      priority: 'medium'
    },
    {
      name: 'Aqeedah at-Tahawiyyah',
      category: 'aqeedah',
      priority: 'high'
    }
  ];

  // Verify translated content for Islamic accuracy
  async verifyIslamicContent(
    originalText: string,
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string,
    options: {
      category?: string;
      strictnessLevel?: 'standard' | 'strict' | 'scholarly';
      provideReferences?: boolean;
      includeSuggestions?: boolean;
      checkHonorificPhrases?: boolean;
    } = {}
  ): Promise<{
    isCorrect: boolean;
    issues: {
      type: string;
      description: string;
      severity: 'low' | 'medium' | 'high';
      location?: { start: number; end: number };
    }[];
    suggestedCorrections?: {
      original: string;
      corrected: string;
      explanation: string;
    }[];
    references?: {
      source: string;
      citation: string;
      relevance: 'direct' | 'supporting' | 'general';
    }[];
    score: number;
    verifiedBy: string;
  }> {
    try {
      // First, check if the content has Islamic references
      const islamicCheckOriginal = await islamicContentDetector.detectIslamicContent(
        originalText,
        sourceLanguage
      );
      
      const islamicCheckTranslated = await islamicContentDetector.detectIslamicContent(
        translatedText,
        targetLanguage
      );
      
      // Only perform detailed verification if Islamic content is detected
      if (!islamicCheckOriginal.isIslamic && !islamicCheckTranslated.isIslamic) {
        return {
          isCorrect: true,
          issues: [],
          score: 1.0,
          verifiedBy: 'automated-check'
        };
      }
      
      // Determine the category for verification
      const category = options.category || 
                       (islamicCheckOriginal.categories?.[0] || 'general');
      
      // Check for prohibited content first
      const hasProhibitedContent = await filterService.containsProhibitedContent(
        translatedText,
        targetLanguage
      );
      
      let issues: any[] = [];
      if (hasProhibitedContent) {
        issues.push({
          type: 'prohibited_content',
          description: 'The translated text contains content that may conflict with Islamic values',
          severity: 'high'
        });
      }
      
      // Check for missing honorific phrases if requested
      if (options.checkHonorificPhrases !== false) {
        const honorificIssues = await this.checkHonorificPhrases(
          originalText,
          translatedText,
          sourceLanguage,
          targetLanguage
        );
        
        issues = [...issues, ...honorificIssues];
      }
      
      // Use Islamic content detector for specialized verification
      const islamicVerification = await islamicContentDetector.verifyIslamicTranslation(
        originalText,
        translatedText,
        sourceLanguage,
        targetLanguage
      );
      
      if (!islamicVerification.isCompliant) {
        issues = [
          ...issues,
          ...islamicVerification.issues.map(issue => ({
            type: 'theological_accuracy',
            description: issue,
            severity: 'medium'
          }))
        ];
      }
      
      // For scholarly level verification, perform additional checks
      if (options.strictnessLevel === 'scholarly') {
        const scholarlyIssues = await this.performScholarlyVerification(
          originalText,
          translatedText,
          sourceLanguage,
          targetLanguage,
          category
        );
        
        issues = [...issues, ...scholarlyIssues];
      }
      
      // Prepare suggested corrections if requested
      let suggestedCorrections;
      if (options.includeSuggestions && islamicVerification.suggestedCorrections?.length > 0) {
        suggestedCorrections = islamicVerification.suggestedCorrections.map(correction => ({
          original: correction.original,
          corrected: correction.suggested,
          explanation: 'This correction ensures proper Islamic terminology and respect'
        }));
      }
      
      // Prepare references if requested
      let references;
      if (options.provideReferences) {
        references = this.getRelevantReferences(category, issues.length > 0);
      }
      
      // Calculate overall score based on issues
      const score = this.calculateScoreFromIssues(issues);
      
      return {
        isCorrect: issues.length === 0,
        issues,
        suggestedCorrections,
        references,
        score,
        verifiedBy: options.strictnessLevel === 'scholarly' ? 'scholarly-check' : 'standard-check'
      };
    } catch (error) {
      console.error("Error verifying Islamic content:", error);
      return {
        isCorrect: false,
        issues: [{
          type: 'verification_error',
          description: 'An error occurred during verification',
          severity: 'medium'
        }],
        score: 0.5,
        verifiedBy: 'error-handler'
      };
    }
  }

  // Check for proper honorific phrases
  private async checkHonorificPhrases(
    originalText: string,
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string
  ): Promise<any[]> {
    const issues: any[] = [];
    
    // Check for mentions of Allah without proper phrase
    if (targetLanguage === 'ar') {
      if (translatedText.includes('الله') && 
          !translatedText.includes('سبحانه وتعالى') && 
          !translatedText.includes('عز وجل') &&
          !translatedText.includes('جل جلاله')) {
        issues.push({
          type: 'missing_honorifics',
          description: 'Mention of Allah without honorific phrase (سبحانه وتعالى/عز وجل)',
          severity: 'medium'
        });
      }
      
      if (translatedText.includes('محمد') && 
          !translatedText.includes('صلى الله عليه وسلم') &&
          !translatedText.includes('عليه الصلاة والسلام')) {
        issues.push({
          type: 'missing_honorifics',
          description: 'Mention of Prophet Muhammad without honorific phrase (صلى الله عليه وسلم)',
          severity: 'medium'
        });
      }
    } else if (targetLanguage === 'en') {
      if (translatedText.includes('Allah') && 
          !translatedText.includes('Glorified and Exalted') && 
          !translatedText.includes('the Almighty') &&
          !translatedText.includes('Subhanahu wa Ta\'ala')) {
        issues.push({
          type: 'missing_honorifics',
          description: 'Mention of Allah without honorific phrase (Glorified and Exalted/the Almighty)',
          severity: 'medium'
        });
      }
      
      if (translatedText.includes('Muhammad') && 
          !translatedText.includes('peace be upon him') &&
          !translatedText.includes('PBUH') &&
          !translatedText.includes('(SAW)')) {
        issues.push({
          type: 'missing_honorifics',
          description: 'Mention of Prophet Muhammad without honorific phrase (peace be upon him/PBUH)',
          severity: 'medium'
        });
      }
    }
    
    return issues;
  }

  // Perform scholarly-level verification
  private async performScholarlyVerification(
    originalText: string,
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string,
    category: string
  ): Promise<any[]> {
    // In a real implementation, this would connect to scholarly databases
    // and advanced analysis systems for detailed verification
    
    // Simplified implementation for demonstration purposes
    try {
      // Use OpenAI (or another AI service) for sophisticated analysis
      const analysisPrompt = `As an Islamic scholar specializing in ${category}, 
analyze this translation from ${sourceLanguage} to ${targetLanguage}:

Original: ${originalText}

Translation: ${translatedText}

Identify any theological errors, mistranslations of Islamic concepts, or issues with respectful language.
Focus on accuracy of Islamic terminology, proper conveyance of religious concepts, and adherence to scholarly consensus.`;

      // This would use a real AI call in a production implementation
      const scholarlyIssues = [];
      
      // Placeholder for demonstration - in a real app we would parse AI response
      // and extract structured issues
      
      return scholarlyIssues;
    } catch (error) {
      console.error("Error in scholarly verification:", error);
      return [{
        type: 'verification_error',
        description: 'An error occurred during scholarly verification',
        severity: 'low'
      }];
    }
  }

  // Get relevant scholarly references for verification
  private getRelevantReferences(category: string, hasIssues: boolean): any[] {
    // Filter references by category
    const categoryReferences = this.scholarlyReferences.filter(ref => 
      ref.category === category || ref.category === 'general'
    );
    
    // Sort by priority
    const sortedReferences = [...categoryReferences].sort((a, b) => {
      const priorityValues = { 'high': 3, 'medium': 2, 'low': 1 };
      return priorityValues[b.priority as keyof typeof priorityValues] - 
             priorityValues[a.priority as keyof typeof priorityValues];
    });
    
    // Return top references with simulated citations
    return sortedReferences.slice(0, 3).map(ref => ({
      source: ref.name,
      citation: `This would be a specific citation from ${ref.name} relevant to the content`,
      relevance: hasIssues ? 'supporting' : 'general'
    }));
  }

  // Calculate verification score based on issues
  private calculateScoreFromIssues(issues: any[]): number {
    if (issues.length === 0) return 1.0;
    
    // Count issues by severity
    const highSeverityCount = issues.filter(issue => issue.severity === 'high').length;
    const mediumSeverityCount = issues.filter(issue => issue.severity === 'medium').length;
    const lowSeverityCount = issues.filter(issue => issue.severity === 'low').length;
    
    // Calculate weighted score
    const score = 1.0 - (
      (highSeverityCount * 0.3) +
      (mediumSeverityCount * 0.15) +
      (lowSeverityCount * 0.05)
    );
    
    // Ensure score is between 0 and 1
    return Math.max(0, Math.min(1, score));
  }

  // Check if a text contains theological claims
  async containsTheologicalClaims(text: string, language: string): Promise<{
    containsClaims: boolean;
    claims?: string[];
    requiresVerification: boolean;
    sensitivityLevel: 'low' | 'medium' | 'high';
  }> {
    try {
      // Use Islamic content detector to analyze the text
      const islamicAnalysis = await islamicContentDetector.detectIslamicContent(text, language);
      
      // Consider theological claims present if it detects Islamic content
      // with high confidence and specific categories
      const theologicalCategories = ['theological', 'quranic', 'jurisprudential'];
      const containsTheologicalCategory = islamicAnalysis.isIslamic && 
        islamicAnalysis.categories.some(category => theologicalCategories.includes(category));
      
      // Determine if verification is required
      const requiresVerification = islamicAnalysis.isIslamic && 
        (islamicAnalysis.confidence > 0.7 || containsTheologicalCategory);
      
      // Determine sensitivity level
      let sensitivityLevel: 'low' | 'medium' | 'high' = 'low';
      if (islamicAnalysis.isIslamic) {
        if (islamicAnalysis.hasQuranicVerses || containsTheologicalCategory) {
          sensitivityLevel = 'high';
        } else if (islamicAnalysis.confidence > 0.7) {
          sensitivityLevel = 'medium';
        }
      }
      
      let claims;
      if (islamicAnalysis.isIslamic && requiresVerification) {
        // In a real implementation, we would extract specific claims
        // This is a placeholder
        claims = [
          'This text appears to make statements about Islamic beliefs or practices',
          'The content may include references to Quranic verses or Hadith'
        ];
      }
      
      return {
        containsClaims: islamicAnalysis.isIslamic,
        claims,
        requiresVerification,
        sensitivityLevel
      };
    } catch (error) {
      console.error("Error checking for theological claims:", error);
      // Default to requiring verification in case of error
      return {
        containsClaims: false,
        requiresVerification: false,
        sensitivityLevel: 'low'
      };
    }
  }
}

export const contentCheckerService = new ContentCheckerService();