import { storage } from "../storage";
import { openaiService } from "./openai";

// Service for filtering content based on Islamic values
export class FilterService {
  // Prohibited content categories
  private prohibitedCategories = [
    "إباحي",
    "عنف",
    "كفر",
    "إساءة للأديان",
    "مخدرات",
    "كحول",
    "قمار",
    "موسيقى محرمة",
    "إسلاموفوبيا",
    "تشبه بالنساء/الرجال",
    "سب وشتم",
    "سحر وشعوذة"
  ];

  // Keyword lists for bad content detection (simplified version)
  private prohibitedKeywords = {
    'ar': [
      // كلمات إباحية - سيتم تعبئتها بعبارات عامة فقط
      'محتوى إباحي',
      'محتوى للبالغين',
      // كلمات العنف
      'قتل',
      'اغتصاب',
      'انتحار',
      // إساءة للأديان
      'سب الدين',
      'سب الله',
      'سب الرسول',
      // كحول ومخدرات
      'خمر',
      'حشيش',
      'مخدرات',
      'كوكايين',
      'هيروين',
      // قمار
      'قمار',
      'كازينو',
      'بوكر',
      'روليت',
      // ألفاظ سيئة
      'شتيمة',
      'لعن',
      'سب'
    ],
    'en': [
      // Adult content - keeping these generic only
      'adult content',
      'explicit content',
      // Violence
      'kill',
      'murder',
      'suicide',
      'rape',
      // Religious offense
      'blasphemy',
      'insult religion',
      'insult prophet',
      // Alcohol and drugs
      'alcohol',
      'wine',
      'beer',
      'vodka',
      'weed',
      'marijuana',
      'cocaine',
      'heroin',
      // Gambling
      'gambling',
      'casino',
      'poker',
      'roulette',
      'betting',
      // Bad language
      'curse',
      'f-word',
      'b-word'
    ]
  };

  // Analyze content for prohibited material
  async containsProhibitedContent(text: string, language: string): Promise<boolean> {
    // Basic keyword check
    const keywords = language === 'ar' ? this.prohibitedKeywords.ar : this.prohibitedKeywords.en;
    const lowerText = text.toLowerCase();
    
    for (const keyword of keywords) {
      if (language === 'ar') {
        if (text.includes(keyword)) return true;
      } else {
        if (lowerText.includes(keyword.toLowerCase())) return true;
      }
    }
    
    // Advanced check using OpenAI
    try {
      const result = await openaiService.analyzeContentForFiltering(text, language);
      return result.containsProhibitedContent;
    } catch (error) {
      console.error("Error analyzing content for prohibited material:", error);
      // Fall back to basic detection if AI check fails
      return this.basicCheck(text, language);
    }
  }
  
  // Filter content to remove prohibited material
  async filterContent(text: string, language: string): Promise<string> {
    try {
      // Get all prohibited words for the language
      const prohibitedWords = await storage.getProhibitedWords(language);
      let filteredText = text;
      
      // Basic filtering using known prohibited words
      for (const word of prohibitedWords) {
        const regex = new RegExp(`\\b${word.word}\\b`, 'gi');
        filteredText = filteredText.replace(regex, word.replacement || '[تم التصفية]');
      }
      
      // Advanced filtering using OpenAI
      try {
        const result = await openaiService.analyzeContentForFiltering(filteredText, language);
        if (result.containsProhibitedContent) {
          filteredText = result.filteredText;
        }
      } catch (error) {
        console.error("Advanced filtering error:", error);
        // Keep current filtered text if advanced filtering fails
      }
      
      return filteredText;
    } catch (error) {
      console.error("Error filtering content:", error);
      // Basic filtering as fallback
      return this.basicFilter(text, language);
    }
  }
  
  // Add a new prohibited word to the database
  async addProhibitedWord(word: string, language: string, category: string, replacement?: string) {
    try {
      const newProhibitedWord = await storage.createProhibitedWord({
        word,
        language,
        category,
        replacement: replacement || '[تم التصفية]'
      });
      
      return newProhibitedWord;
    } catch (error) {
      console.error("Error adding prohibited word:", error);
      throw new Error("Failed to add prohibited word");
    }
  }
  
  // Get all prohibited words, optionally filtered by language
  async getProhibitedWords(language?: string) {
    try {
      return await storage.getProhibitedWords(language);
    } catch (error) {
      console.error("Error getting prohibited words:", error);
      return [];
    }
  }
  
  // Basic check for prohibited content (fallback method)
  private basicCheck(text: string, language: string): boolean {
    const keywords = language === 'ar' ? this.prohibitedKeywords.ar : this.prohibitedKeywords.en;
    const lowerText = text.toLowerCase();
    
    for (const keyword of keywords) {
      if (language === 'ar') {
        if (text.includes(keyword)) return true;
      } else {
        if (lowerText.includes(keyword.toLowerCase())) return true;
      }
    }
    
    return false;
  }
  
  // Basic filter for prohibited content (fallback method)
  private basicFilter(text: string, language: string): string {
    const keywords = language === 'ar' ? this.prohibitedKeywords.ar : this.prohibitedKeywords.en;
    let filteredText = text;
    
    for (const keyword of keywords) {
      if (language === 'ar') {
        const regex = new RegExp(keyword, 'g');
        filteredText = filteredText.replace(regex, '[تم التصفية]');
      } else {
        const regex = new RegExp(keyword, 'gi');
        filteredText = filteredText.replace(regex, '[FILTERED]');
      }
    }
    
    return filteredText;
  }
}

export const filterService = new FilterService();