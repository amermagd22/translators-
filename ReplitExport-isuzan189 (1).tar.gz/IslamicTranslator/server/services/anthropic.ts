import Anthropic from '@anthropic-ai/sdk';

// Enhanced Anthropic service for advanced translation features
export class AnthropicService {
  private anthropic: Anthropic | null = null;
  
  constructor() {
    // Initialize Anthropic client with API key from environment variables if available
    if (process.env.ANTHROPIC_API_KEY) {
      this.anthropic = new Anthropic({
        apiKey: process.env.ANTHROPIC_API_KEY,
      });
      console.log("Anthropic service initialized");
    } else {
      console.log("Anthropic API key not found, service will fall back to OpenAI");
    }
  }

  // Check if the service is available
  isAvailable(): boolean {
    return this.anthropic !== null;
  }

  // Enhanced translation with cultural context understanding
  async enhancedTranslation(
    sourceText: string,
    sourceLanguage: string,
    targetLanguage: string,
    preserveIslamicTerms: boolean = true
  ): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error("Anthropic service not available");
    }
    
    try {
      // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
      const prompt = this.buildTranslationPrompt(sourceText, sourceLanguage, targetLanguage, preserveIslamicTerms);
      
      const message = await this.anthropic!.messages.create({
        model: 'claude-3-7-sonnet-20250219',
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.3,
      });

      // Access the content text safely
      if (message.content && message.content[0] && 'text' in message.content[0]) {
        return message.content[0].text || sourceText;
      }
      return sourceText;
    } catch (error) {
      console.error("Anthropic translation error:", error);
      throw error;
    }
  }

  // Analyze multilingual content for deeper cultural understanding
  async analyzeMultilingualContent(
    text: string, 
    language: string
  ): Promise<{
    dialectIdentification: string;
    culturalNuances: string[];
    formalityLevel: string;
    religiousContext: boolean;
    recommendations: string[];
  }> {
    if (!this.isAvailable()) {
      throw new Error("Anthropic service not available");
    }
    
    try {
      const systemPrompt = `You're a cultural linguistics expert specializing in ${language}. 
        Analyze the provided text for dialect identification, cultural nuances, formality level, 
        religious context, and provide recommendations for culturally appropriate translation.
        Return your analysis in JSON format.`;
      
      const response = await this.anthropic!.messages.create({
        model: 'claude-3-7-sonnet-20250219',
        max_tokens: 1024,
        system: systemPrompt,
        messages: [
          { role: 'user', content: `Analyze this ${language} text: ${text}` }
        ],
      });

      try {
        // Parse the JSON response safely
        if (response.content && response.content[0] && 'text' in response.content[0]) {
          const text = response.content[0].text;
          const jsonMatch = text.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const result = JSON.parse(jsonMatch[0]);
            return {
              dialectIdentification: result.dialectIdentification || "standard",
              culturalNuances: result.culturalNuances || [],
              formalityLevel: result.formalityLevel || "neutral",
              religiousContext: result.religiousContext || false,
              recommendations: result.recommendations || []
            };
          }
        }
      } catch (parseError) {
        console.error("Error parsing JSON from Anthropic response:", parseError);
      }

      // Default response if JSON parsing fails
      return {
        dialectIdentification: "standard",
        culturalNuances: [],
        formalityLevel: "neutral",
        religiousContext: false,
        recommendations: []
      };
    } catch (error) {
      console.error("Anthropic content analysis error:", error);
      throw error;
    }
  }

  // Generate culturally appropriate content with Islamic values
  async generateCulturallyAppropriateContent(
    prompt: string,
    language: string,
    contentType: "greeting" | "response" | "cultural_explanation" | "religious_explanation"
  ): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error("Anthropic service not available");
    }
    
    try {
      const systemPrompt = `You are an AI specialized in generating culturally appropriate content 
        in ${language} that respects Islamic values. The content should be respectful, 
        informative, and aligned with Islamic principles. Avoid generating content that contains 
        prohibited elements or conflicts with Islamic values.`;
      
      const message = await this.anthropic!.messages.create({
        model: 'claude-3-7-sonnet-20250219',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [
          { 
            role: 'user', 
            content: `Generate a ${contentType} in ${language} about: ${prompt}` 
          }
        ],
      });

      // Access content safely
      if (message.content && message.content[0] && 'text' in message.content[0]) {
        return message.content[0].text || "";
      }
      return "";
    } catch (error) {
      console.error("Anthropic content generation error:", error);
      throw error;
    }
  }

  // Build a translation prompt with cultural context
  private buildTranslationPrompt(
    sourceText: string,
    sourceLanguage: string,
    targetLanguage: string,
    preserveIslamicTerms: boolean
  ): string {
    let prompt = `Translate the following ${sourceLanguage} text to ${targetLanguage}:

${sourceText}

Translation guidelines:
- Maintain the original meaning and tone
- Preserve formatting and paragraph structure
- Keep names and proper nouns unchanged`;

    if (preserveIslamicTerms) {
      prompt += `
- Preserve Islamic religious terms in their original form with proper transliteration
- Keep 'Allah' instead of translating to 'God'
- Maintain appropriate honorifics like 'peace be upon him' after mentions of prophets
- Ensure translations are culturally appropriate and aligned with Islamic values`;
    }

    return prompt;
  }
}

export const anthropicService = new AnthropicService();