import { openaiService } from "./openai";

// Service for translating and explaining proverbs, idioms, and wisdom
export class ProverbTranslatorService {
  // Collection of Arabic proverbs and wisdom
  private arabicProverbs = [
    {
      text: 'العلم في الصغر كالنقش على الحجر',
      literal: 'Learning in youth is like carving in stone',
      meaning: 'What we learn when young stays with us permanently, like a carving in stone',
      equivalent: 'You can\'t teach an old dog new tricks',
      category: 'education'
    },
    {
      text: 'اطلب العلم من المهد إلى اللحد',
      literal: 'Seek knowledge from the cradle to the grave',
      meaning: 'Learning is a lifelong process that never ends',
      equivalent: 'Never stop learning',
      category: 'education'
    },
    {
      text: 'يد واحدة لا تصفق',
      literal: 'One hand cannot clap',
      meaning: 'Cooperation is essential to accomplish tasks',
      equivalent: 'It takes two to tango',
      category: 'cooperation'
    },
    {
      text: 'الصديق وقت الضيق',
      literal: 'A friend in time of hardship',
      meaning: 'True friends are those who stand by you in difficult times',
      equivalent: 'A friend in need is a friend indeed',
      category: 'friendship'
    },
    {
      text: 'الوقت كالسيف إن لم تقطعه قطعك',
      literal: 'Time is like a sword: if you don\'t cut it, it cuts you',
      meaning: 'If you don\'t use time wisely, it will slip away and you will regret wasting it',
      equivalent: 'Time waits for no one',
      category: 'time'
    },
    {
      text: 'العين بصيرة واليد قصيرة',
      literal: 'The eye sees but the hand can\'t reach',
      meaning: 'We may see opportunities but lack the means to grasp them',
      equivalent: 'So near and yet so far',
      category: 'limitation'
    },
    {
      text: 'على قدر أهل العزم تأتي العزائم',
      literal: 'Determination comes according to one\'s resolve',
      meaning: 'Great achievements come to those with strong determination',
      equivalent: 'Where there\'s a will, there\'s a way',
      category: 'determination'
    },
    {
      text: 'من طلب العلا سهر الليالي',
      literal: 'Whoever seeks greatness stays up nights',
      meaning: 'Success requires hard work and sacrifice',
      equivalent: 'No pain, no gain',
      category: 'success'
    },
    {
      text: 'الحاجة أم الاختراع',
      literal: 'Necessity is the mother of invention',
      meaning: 'Difficult situations inspire ingenious solutions',
      equivalent: 'Necessity is the mother of invention',
      category: 'innovation'
    },
    {
      text: 'من جد وجد ومن زرع حصد',
      literal: 'Who strives shall succeed, and who sows shall reap',
      meaning: 'Hard work leads to success, and actions have consequences',
      equivalent: 'You reap what you sow',
      category: 'work'
    }
  ];

  // Collection of Islamic wisdom and sayings
  private islamicWisdom = [
    {
      text: 'الدنيا متاع وخير متاعها المرأة الصالحة',
      source: 'حديث شريف',
      meaning: 'The world is a provision, and the best provision in the world is a righteous wife',
      context: 'Highlights the importance of a good spouse in Islamic life',
      category: 'family'
    },
    {
      text: 'خيركم خيركم لأهله وأنا خيركم لأهلي',
      source: 'حديث شريف',
      meaning: 'The best of you are those who are best to their families, and I am the best to my family',
      context: 'Emphasizes kind treatment of family members',
      category: 'family'
    },
    {
      text: 'لا تغضب ولك الجنة',
      source: 'حديث شريف',
      meaning: 'Do not get angry, and Paradise will be yours',
      context: 'Highlights the importance of controlling anger',
      category: 'self-control'
    },
    {
      text: 'إنما الأعمال بالنيات',
      source: 'حديث شريف',
      meaning: 'Deeds are judged by intentions',
      context: 'Emphasizes the importance of sincere intention in Islam',
      category: 'intention'
    },
    {
      text: 'رحم الله امرءا عرف قدر نفسه',
      source: 'أثر إسلامي',
      meaning: 'May Allah have mercy on one who knows his own worth',
      context: 'Encourages self-awareness and humility',
      category: 'self-awareness'
    },
    {
      text: 'الدال على الخير كفاعله',
      source: 'حديث شريف',
      meaning: 'One who guides to something good has a reward similar to that of its doer',
      context: 'Encourages sharing knowledge and guiding others to good',
      category: 'good deeds'
    },
    {
      text: 'خير الناس أنفعهم للناس',
      source: 'حديث شريف',
      meaning: 'The best of people are those who are most beneficial to people',
      context: 'Emphasizes the importance of serving others',
      category: 'service'
    },
    {
      text: 'من سلك طريقا يلتمس فيه علما سهل الله له طريقا إلى الجنة',
      source: 'حديث شريف',
      meaning: 'Whoever takes a path to seek knowledge, Allah makes the path to Paradise easy for him',
      context: 'Highlights the high status of seeking knowledge in Islam',
      category: 'knowledge'
    }
  ];

  // Translate and explain proverbs with cultural context
  async translateProverb(
    proverb: string,
    sourceLanguage: string,
    targetLanguage: string,
    options: {
      includeContext?: boolean;
      includeEquivalent?: boolean;
      includeUsageExamples?: boolean;
    } = {}
  ): Promise<{
    originalProverb: string;
    literalTranslation: string;
    meaningTranslation: string;
    culturalContext?: string;
    equivalent?: string;
    usageExamples?: string[];
    category?: string;
    source?: string;
  }> {
    try {
      // First check if it's in our database
      let knownProverb = this.findKnownProverb(proverb, sourceLanguage);
      
      // If found in database, use that information
      if (knownProverb) {
        // Prepare response based on the found proverb
        const result: any = {
          originalProverb: proverb,
          literalTranslation: sourceLanguage === 'ar' ? knownProverb.literal : knownProverb.text,
          meaningTranslation: knownProverb.meaning,
          category: knownProverb.category
        };
        
        // Add optional information if requested
        if (options.includeContext) {
          result.culturalContext = 'This proverb is commonly used in Arabic culture ' + 
                                  (knownProverb.context || 'to emphasize wisdom about ' + knownProverb.category);
        }
        
        if (options.includeEquivalent && knownProverb.equivalent) {
          result.equivalent = knownProverb.equivalent;
        }
        
        if (options.includeUsageExamples) {
          result.usageExamples = [
            'Example usage would be provided here in a real implementation',
            'Another contextual example of when to use this proverb'
          ];
        }
        
        // Add source for Islamic wisdom
        if ('source' in knownProverb) {
          result.source = knownProverb.source;
        }
        
        return result;
      }
      
      // If not found in database, use OpenAI to translate and explain
      return this.aiBasedProverbTranslation(
        proverb,
        sourceLanguage,
        targetLanguage,
        options
      );
    } catch (error) {
      console.error("Error translating proverb:", error);
      
      // Return simplified response in case of error
      return {
        originalProverb: proverb,
        literalTranslation: 'Translation unavailable',
        meaningTranslation: 'Meaning unavailable'
      };
    }
  }

  // Find a known proverb in our database
  private findKnownProverb(text: string, language: string): any {
    // Clean up the text for comparison
    const cleanText = text.trim().replace(/[.،,;؛!?؟]/g, '');
    
    // Search in appropriate collection
    if (language === 'ar') {
      // Look in Arabic proverbs
      const foundProverb = this.arabicProverbs.find(p => 
        p.text.includes(cleanText) || cleanText.includes(p.text)
      );
      
      if (foundProverb) return foundProverb;
      
      // Look in Islamic wisdom
      const foundWisdom = this.islamicWisdom.find(w => 
        w.text.includes(cleanText) || cleanText.includes(w.text)
      );
      
      if (foundWisdom) return foundWisdom;
    } else if (language === 'en') {
      // For English, check if it matches any translations or equivalents
      const foundProverb = this.arabicProverbs.find(p => 
        p.literal === cleanText || p.equivalent === cleanText
      );
      
      if (foundProverb) return foundProverb;
      
      // Check in Islamic wisdom translations
      const foundWisdom = this.islamicWisdom.find(w => 
        w.meaning === cleanText
      );
      
      if (foundWisdom) return foundWisdom;
    }
    
    // Not found in our database
    return null;
  }

  // Use AI to translate and explain proverbs not in our database
  private async aiBasedProverbTranslation(
    proverb: string,
    sourceLanguage: string,
    targetLanguage: string,
    options: any
  ): Promise<any> {
    // In a real implementation, this would use a specialized AI model
    // or prompt to handle proverbs appropriately
    
    // First, get a literal translation
    const literalTranslation = await openaiService.enhanceTranslation(
      proverb,
      sourceLanguage,
      targetLanguage,
      false,
      "Provide a literal, word-for-word translation of this proverb or saying"
    );
    
    // Then, get the meaning and cultural context
    const meaningPrompt = `Explain the meaning of this ${sourceLanguage} proverb or saying:
"${proverb}"

Provide:
1. The deeper meaning
2. Cultural context
3. Equivalent proverb in ${targetLanguage} (if one exists)
4. Examples of when it would be used`;

    // In a real implementation, this would parse a proper JSON response
    // from the AI model. This is a simplified placeholder.
    const meaningTranslation = "AI would provide meaning explanation here";
    
    // Build the result
    const result: any = {
      originalProverb: proverb,
      literalTranslation,
      meaningTranslation
    };
    
    // Add optional fields if requested
    if (options.includeContext) {
      result.culturalContext = "AI would provide cultural context here";
    }
    
    if (options.includeEquivalent) {
      result.equivalent = "AI would provide equivalent proverb here";
    }
    
    if (options.includeUsageExamples) {
      result.usageExamples = [
        "AI would provide usage example 1",
        "AI would provide usage example 2"
      ];
    }
    
    return result;
  }

  // Get proverbs by category
  getProverbsByCategory(
    category: string,
    language: string = 'ar',
    limit: number = 10
  ): {
    proverbs: {
      text: string;
      meaning: string;
    }[];
    total: number;
  } {
    // Combine both collections
    const allProverbs = [
      ...this.arabicProverbs.map(p => ({
        text: p.text,
        meaning: p.meaning,
        category: p.category
      })),
      ...this.islamicWisdom.map(w => ({
        text: w.text,
        meaning: w.meaning,
        category: w.category,
        source: w.source
      }))
    ];
    
    // Filter by category if provided
    const filtered = category ? 
      allProverbs.filter(p => p.category === category) : 
      allProverbs;
    
    // Return requested number
    return {
      proverbs: filtered.slice(0, limit).map(p => ({
        text: p.text,
        meaning: p.meaning
      })),
      total: filtered.length
    };
  }

  // Get all available categories
  getProverbCategories(): string[] {
    // Extract unique categories from both collections
    const categories = new Set([
      ...this.arabicProverbs.map(p => p.category),
      ...this.islamicWisdom.map(w => w.category)
    ]);
    
    return [...categories];
  }

  // Detect if text contains a proverb or wise saying
  async detectProverb(text: string, language: string): Promise<{
    containsProverb: boolean;
    detectedProverbs: {
      text: string;
      confidence: number;
    }[];
  }> {
    try {
      // Simple search in our database first
      const possibleProverbs = [];
      
      // Split text into sentences
      const sentences = text.split(/[.!?؟،;]/);
      
      for (const sentence of sentences) {
        if (sentence.trim().length < 5) continue;
        
        // Check against our database
        const knownProverb = this.findKnownProverb(sentence, language);
        
        if (knownProverb) {
          possibleProverbs.push({
            text: knownProverb.text || sentence,
            confidence: 0.9
          });
          continue;
        }
        
        // Look for structural patterns common in proverbs
        // This is simplified; a real implementation would be more sophisticated
        const hasProverbStructure = this.hasProverbStructure(sentence, language);
        
        if (hasProverbStructure) {
          possibleProverbs.push({
            text: sentence,
            confidence: 0.6
          });
        }
      }
      
      return {
        containsProverb: possibleProverbs.length > 0,
        detectedProverbs: possibleProverbs
      };
    } catch (error) {
      console.error("Error detecting proverbs:", error);
      return {
        containsProverb: false,
        detectedProverbs: []
      };
    }
  }

  // Check if text has structural patterns common in proverbs
  private hasProverbStructure(text: string, language: string): boolean {
    if (language === 'ar') {
      // Common Arabic proverb patterns
      const arabicPatterns = [
        /من .+ .+/,       // "Whoever/he who" pattern
        /لا .+ إلا .+/,   // "No X except Y" pattern
        /خير .+ .+/,      // "The best X is Y" pattern
        /كما .+ كذلك .+/, // "As X, so Y" pattern
        /إذا .+ .+/       // "If X, then Y" pattern
      ];
      
      return arabicPatterns.some(pattern => pattern.test(text));
    } else if (language === 'en') {
      // Common English proverb patterns
      const englishPatterns = [
        /Better .+ than .+/i,      // "Better X than Y" pattern
        /A .+ is worth .+/i,       // "A X is worth Y" pattern
        /No .+ without .+/i,       // "No X without Y" pattern
        /The .+ of .+ is .+/i,     // "The X of Y is Z" pattern
        /One .+, another .+/i      // "One X, another Y" pattern
      ];
      
      return englishPatterns.some(pattern => pattern.test(text));
    }
    
    return false;
  }
}

export const proverbTranslatorService = new ProverbTranslatorService();