import { openaiService } from "./openai";
import { anthropicService } from "./anthropic";
import { scientificMiraclesService } from "./scientificMiracles";
import { islamicContentDetector } from "./islamicContentDetector";

// Service for Islamic dawah (invitation to Islam) with scientific evidence
export class IslamicDawahService {
  // Faith questioning categories
  private faithCategories = [
    'existence_of_god',
    'authenticity_of_quran',
    'prophethood_of_muhammad',
    'scientific_miracles',
    'comparative_religion',
    'purpose_of_life',
    'ethics_and_morality',
    'islamic_practices',
    'misconceptions',
    'personal_guidance'
  ];

  // Common questions about Islam with verified answers
  private commonQuestions = [
    {
      id: 'islam_basic',
      category: 'basics',
      question: {
        en: 'What is Islam?',
        ar: 'ما هو الإسلام؟'
      },
      answer: {
        en: 'Islam is a monotheistic faith based on revelations to the Prophet Muhammad (peace be upon him) through the angel Gabriel. The word "Islam" means voluntary submission to God. A Muslim is someone who practices Islam and submits to God\'s will. Islam teaches that there is only one God (Allah) and that Muhammad is His final prophet. The holy book of Islam is the Quran, which Muslims believe contains the unaltered word of God as revealed to Muhammad.',
        ar: 'الإسلام هو دين التوحيد المبني على الوحي الذي نزل على النبي محمد صلى الله عليه وسلم بواسطة الملاك جبريل. كلمة "إسلام" تعني الاستسلام الطوعي لله. المسلم هو من يمارس الإسلام ويخضع لإرادة الله. يعلم الإسلام أن هناك إله واحد فقط (الله) وأن محمدًا هو نبيه الأخير. الكتاب المقدس للإسلام هو القرآن، الذي يؤمن المسلمون بأنه يحتوي على كلام الله غير المحرف كما أوحي به إلى محمد.'
      },
      sources: [
        {
          scholar: 'Dr. Zakir Naik',
          reference: 'Concept of God in Major Religions',
          type: 'scholarly'
        },
        {
          scholar: 'Oxford Islamic Studies Online',
          reference: 'Introduction to Islam',
          type: 'academic'
        }
      ],
      related_questions: ['pillars_of_islam', 'quran_authenticity', 'prophet_muhammad']
    },
    {
      id: 'pillars_of_islam',
      category: 'basics',
      question: {
        en: 'What are the Five Pillars of Islam?',
        ar: 'ما هي أركان الإسلام الخمسة؟'
      },
      answer: {
        en: 'The Five Pillars of Islam are the foundation of Muslim life. They are: 1) Shahada (Faith): Declaring one\'s faith in God and Muhammad as His prophet. 2) Salat (Prayer): Performing ritual prayers five times daily. 3) Zakat (Charity): Giving a portion of one\'s wealth to those in need. 4) Sawm (Fasting): Fasting during the month of Ramadan. 5) Hajj (Pilgrimage): Pilgrimage to Mecca at least once in a lifetime for those who are able.',
        ar: 'أركان الإسلام الخمسة هي أساس حياة المسلم. وهي: 1) الشهادة (الإيمان): إعلان إيمان المرء بالله ومحمد كنبيه. 2) الصلاة: أداء الصلوات الخمس يوميًا. 3) الزكاة (الصدقة): إعطاء جزء من ثروة المرء للمحتاجين. 4) الصوم: الصيام خلال شهر رمضان. 5) الحج: الحج إلى مكة مرة واحدة على الأقل في العمر لمن استطاع إليه سبيلا.'
      },
      sources: [
        {
          scholar: 'Al-Bukhari',
          reference: 'Sahih al-Bukhari, Book of Faith',
          type: 'hadith'
        },
        {
          scholar: 'Dr. Mustafa Khattab',
          reference: 'The Clear Quran',
          type: 'scholarly'
        }
      ],
      related_questions: ['islam_basic', 'islamic_practices', 'salat_importance']
    },
    {
      id: 'quran_authenticity',
      category: 'authenticity_of_quran',
      question: {
        en: 'How do we know the Quran is authentic and preserved?',
        ar: 'كيف نعرف أن القرآن أصيل ومحفوظ؟'
      },
      answer: {
        en: 'The Quran\'s authenticity is established through multiple channels: 1) Memorization: Since its revelation, millions of Muslims have memorized the entire Quran, passing it down orally from generation to generation. 2) Written preservation: The Quran was written down during the lifetime of Prophet Muhammad under his supervision. 3) Textual consistency: Manuscripts from the first century of Islam match today\'s Quran. 4) Historical documentation: The compilation process is well-documented historically. 5) Divine promise: The Quran itself contains Allah\'s promise to preserve it (Quran 15:9). 6) Linguistic inimitability: The Quran\'s unique linguistic style serves as an internal evidence of its divine origin.',
        ar: 'تم إثبات أصالة القرآن من خلال قنوات متعددة: 1) الحفظ: منذ نزوله، حفظ ملايين المسلمين القرآن بأكمله، ونقلوه شفهياً من جيل إلى جيل. 2) الحفظ المكتوب: تم تدوين القرآن خلال حياة النبي محمد تحت إشرافه. 3) الاتساق النصي: المخطوطات من القرن الأول للإسلام تتطابق مع القرآن اليوم. 4) التوثيق التاريخي: عملية التجميع موثقة تاريخياً بشكل جيد. 5) الوعد الإلهي: يحتوي القرآن نفسه على وعد الله بحفظه (القرآن 15:9). 6) الإعجاز اللغوي: الأسلوب اللغوي الفريد للقرآن يمثل دليلاً داخلياً على أصله الإلهي.'
      },
      sources: [
        {
          scholar: 'Dr. Muhammad Mustafa Al-Azami',
          reference: 'The History of the Quranic Text',
          type: 'scholarly'
        },
        {
          scholar: 'Dr. Yasir Qadhi',
          reference: 'An Introduction to the Sciences of the Quran',
          type: 'scholarly'
        }
      ],
      related_questions: ['quran_scientific_miracles', 'quran_memorization', 'quran_compilation']
    },
    {
      id: 'prophet_muhammad',
      category: 'prophethood_of_muhammad',
      question: {
        en: 'Who was Prophet Muhammad?',
        ar: 'من كان النبي محمد؟'
      },
      answer: {
        en: 'Muhammad (peace be upon him) was born in Mecca in 570 CE. Orphaned at a young age, he was known for his truthfulness and integrity, earning the title "Al-Amin" (The Trustworthy). At age 40, he received his first revelation from Allah through the angel Gabriel. He spent 23 years spreading the message of Islam, facing severe persecution before eventually establishing the first Islamic state in Medina. His character exemplified the Quranic teachings, and his sayings and actions (Hadith) form the second source of Islamic law. He passed away in 632 CE after completing his mission. Muslims believe he was the final prophet sent to humanity, completing and perfecting the message brought by previous prophets including Abraham, Moses, and Jesus.',
        ar: 'ولد محمد (صلى الله عليه وسلم) في مكة عام 570 ميلادية. أصبح يتيمًا في سن مبكرة، وكان معروفًا بصدقه ونزاهته، مما أكسبه لقب "الأمين". في سن الأربعين، تلقى أول وحي من الله من خلال الملاك جبريل. قضى 23 عامًا في نشر رسالة الإسلام، وواجه اضطهادًا شديدًا قبل أن يؤسس أخيرًا أول دولة إسلامية في المدينة المنورة. جسدت شخصيته تعاليم القرآن، وتشكل أقواله وأفعاله (الحديث) المصدر الثاني للشريعة الإسلامية. توفي عام 632 ميلادية بعد إتمام مهمته. يعتقد المسلمون أنه كان النبي الأخير المرسل للبشرية، مكملًا ومتممًا للرسالة التي جاء بها الأنبياء السابقون بما في ذلك إبراهيم وموسى وعيسى.'
      },
      sources: [
        {
          scholar: 'Martin Lings',
          reference: 'Muhammad: His Life Based on the Earliest Sources',
          type: 'biographical'
        },
        {
          scholar: 'Dr. Tariq Ramadan',
          reference: 'In the Footsteps of the Prophet',
          type: 'scholarly'
        }
      ],
      related_questions: ['prophetic_miracles', 'prophet_character', 'prophethood_proofs']
    },
    {
      id: 'quran_scientific_miracles',
      category: 'scientific_miracles',
      question: {
        en: 'Does the Quran contain scientific miracles?',
        ar: 'هل يحتوي القرآن على معجزات علمية؟'
      },
      answer: {
        en: 'The Quran contains numerous statements about natural phenomena that were beyond the scientific knowledge of the 7th century when it was revealed, yet align with modern scientific discoveries. Examples include: 1) Embryonic development described in stages that match modern embryology (23:12-14). 2) The expanding universe (51:47), discovered only in the 20th century. 3) The protective nature of the atmosphere (21:32). 4) The description of deep sea darkness and internal waves (24:40). 5) The water cycle and the role of winds in cloud formation (30:48). 6) The description of mountains as stabilizers for the earth (78:6-7). These correlations suggest knowledge that could not have been available to humans at the time of revelation, pointing to the divine origin of the Quran.',
        ar: 'يحتوي القرآن على عدة بيانات حول الظواهر الطبيعية التي كانت خارج نطاق المعرفة العلمية في القرن السابع عندما تم نزوله، ومع ذلك تتوافق مع الاكتشافات العلمية الحديثة. تشمل الأمثلة: 1) تطور الأجنة الموصوف في مراحل تتطابق مع علم الأجنة الحديث (23:12-14). 2) توسع الكون (51:47)، الذي تم اكتشافه فقط في القرن العشرين. 3) الطبيعة الواقية للغلاف الجوي (21:32). 4) وصف ظلام أعماق البحار والأمواج الداخلية (24:40). 5) دورة المياه ودور الرياح في تكوين السحب (30:48). 6) وصف الجبال كمثبتات للأرض (78:6-7). تشير هذه الارتباطات إلى معرفة لم تكن متاحة للبشر في وقت الوحي، مما يشير إلى الأصل الإلهي للقرآن.'
      },
      sources: [
        {
          scholar: 'Dr. Maurice Bucaille',
          reference: 'The Bible, the Quran and Science',
          type: 'scholarly'
        },
        {
          scholar: 'Dr. Zakir Naik',
          reference: 'The Quran and Modern Science: Compatible or Incompatible?',
          type: 'scholarly'
        },
        {
          scholar: 'Dr. Keith Moore',
          reference: 'The Developing Human with Islamic Additions',
          type: 'scientific'
        }
      ],
      related_questions: ['quran_authenticity', 'embryology_quran', 'expanding_universe_quran']
    }
  ];

  // Responses for addressing misconceptions about Islam
  private misconceptionResponses = [
    {
      id: 'islam_violence',
      misconception: {
        en: 'Islam promotes violence',
        ar: 'الإسلام يروج للعنف'
      },
      correction: {
        en: 'Islam explicitly prohibits aggression and emphasizes peace. The Quran states: "Whoever kills a soul unless for a soul or for corruption in the land - it is as if he had slain mankind entirely" (5:32). The word "Islam" itself is derived from the Arabic root "salama" which means peace and security. Islamic teachings only permit fighting in self-defense or to protect the oppressed. The Prophet Muhammad instructed armies never to harm civilians, women, children, the elderly, or religious figures, and not to destroy property or vegetation — principles that predated modern war conventions by over 1000 years. Muslims are instructed to respond to hostility with reconciliation: "Repel evil with that which is better" (Quran 41:34).',
        ar: 'يحظر الإسلام صراحة العدوان ويؤكد على السلام. يقول القرآن: "مَن قَتَلَ نَفْسًا بِغَيْرِ نَفْسٍ أَوْ فَسَادٍ فِي الْأَرْضِ فَكَأَنَّمَا قَتَلَ النَّاسَ جَمِيعًا" (5:32). كلمة "إسلام" نفسها مشتقة من الجذر العربي "سلم" الذي يعني السلام والأمان. التعاليم الإسلامية تسمح بالقتال فقط في حالة الدفاع عن النفس أو لحماية المظلومين. أوصى النبي محمد الجيوش بعدم إيذاء المدنيين أو النساء أو الأطفال أو المسنين أو رجال الدين، وعدم تدمير الممتلكات أو النباتات — وهي مبادئ سبقت اتفاقيات الحرب الحديثة بأكثر من 1000 عام. يُطلب من المسلمين الرد على العداء بالمصالحة: "ادْفَعْ بِالَّتِي هِيَ أَحْسَنُ" (القرآن 41:34).'
      },
      sources: [
        {
          scholar: 'Dr. Jamal Badawi',
          reference: 'Islam and Peace',
          type: 'scholarly'
        },
        {
          scholar: 'Dr. Tahir ul-Qadri',
          reference: 'Fatwa on Terrorism and Suicide Bombings',
          type: 'scholarly'
        }
      ],
      scriptural_evidence: [
        {
          text: 'وَإِن جَنَحُوا لِلسَّلْمِ فَاجْنَحْ لَهَا وَتَوَكَّلْ عَلَى اللَّهِ',
          reference: 'Quran 8:61',
          translation: 'And if they incline to peace, then incline to it and rely upon Allah'
        },
        {
          text: 'لَا إِكْرَاهَ فِي الدِّينِ ۖ قَد تَّبَيَّنَ الرُّشْدُ مِنَ الْغَيِّ',
          reference: 'Quran 2:256',
          translation: 'There shall be no compulsion in religion; the right way has become distinct from the wrong way'
        }
      ]
    },
    {
      id: 'women_rights',
      misconception: {
        en: 'Islam oppresses women',
        ar: 'الإسلام يضطهد المرأة'
      },
      correction: {
        en: 'Islam elevated women\'s status in the 7th century by granting them rights that many societies didn\'t recognize until recent centuries. The Quran explicitly states that men and women are spiritually equal (4:124, 33:35). Islam granted women economic independence, allowing them to earn, own property, inherit, and manage their wealth 1200 years before similar rights were recognized in Western societies. The first university was founded by a Muslim woman, Fatima Al-Fihri. Women in early Islamic history were scholars, businesswomen, and political advisors. Cultural practices that oppress women, such as forced marriages or honor killings, contradict Islamic teachings. The Prophet Muhammad said: "The best of you are those who are best to their wives," emphasizing kind treatment and mutual respect in marriage.',
        ar: 'رفع الإسلام مكانة المرأة في القرن السابع من خلال منحها حقوقًا لم تعترف بها العديد من المجتمعات حتى القرون الأخيرة. ينص القرآن صراحة على أن الرجال والنساء متساوون روحيًا (4:124، 33:35). منح الإسلام المرأة الاستقلال الاقتصادي، والسماح لها بالكسب وامتلاك الممتلكات والميراث وإدارة ثرواتها قبل 1200 عام من الاعتراف بحقوق مماثلة في المجتمعات الغربية. تأسست أول جامعة على يد امرأة مسلمة، فاطمة الفهري. كانت النساء في التاريخ الإسلامي المبكر عالمات ورجال أعمال ومستشارات سياسيات. الممارسات الثقافية التي تضطهد المرأة، مثل الزواج القسري أو جرائم الشرف، تتعارض مع التعاليم الإسلامية. قال النبي محمد: "خيركم خيركم لأهله"، مؤكدًا على المعاملة الطيبة والاحترام المتبادل في الزواج.'
      },
      sources: [
        {
          scholar: 'Dr. Ingrid Mattson',
          reference: 'Women in Islam',
          type: 'scholarly'
        },
        {
          scholar: 'Dr. Jasser Auda',
          reference: 'Reclaiming the Mosque: Women in Islamic Jurisprudence',
          type: 'scholarly'
        }
      ],
      scriptural_evidence: [
        {
          text: 'وَمَن يَعْمَلْ مِنَ الصَّالِحَاتِ مِن ذَكَرٍ أَوْ أُنثَىٰ وَهُوَ مُؤْمِنٌ فَأُولَٰئِكَ يَدْخُلُونَ الْجَنَّةَ وَلَا يُظْلَمُونَ نَقِيرًا',
          reference: 'Quran 4:124',
          translation: 'And whoever does righteous deeds, whether male or female, while being a believer - those will enter Paradise and will not be wronged, [even as much as] the speck on a date seed'
        },
        {
          text: 'إِنَّ الْمُسْلِمِينَ وَالْمُسْلِمَاتِ وَالْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ وَالْقَانِتِينَ وَالْقَانِتَاتِ وَالصَّادِقِينَ وَالصَّادِقَاتِ وَالصَّابِرِينَ وَالصَّابِرَاتِ وَالْخَاشِعِينَ وَالْخَاشِعَاتِ وَالْمُتَصَدِّقِينَ وَالْمُتَصَدِّقَاتِ وَالصَّائِمِينَ وَالصَّائِمَاتِ وَالْحَافِظِينَ فُرُوجَهُمْ وَالْحَافِظَاتِ وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا',
          reference: 'Quran 33:35',
          translation: 'Indeed, the Muslim men and Muslim women, the believing men and believing women, the obedient men and obedient women, the truthful men and truthful women, the patient men and patient women, the humble men and humble women, the charitable men and charitable women, the fasting men and fasting women, the men who guard their private parts and the women who do so, and the men who remember Allah often and the women who do so - for them Allah has prepared forgiveness and a great reward'
        }
      ]
    }
  ];

  // Resources for dawah practitioners
  private dawahResources = [
    {
      id: 'conversation_guides',
      title: {
        en: 'Effective Dawah Conversation Guides',
        ar: 'أدلة محادثة الدعوة الفعالة'
      },
      content: {
        en: 'Guidelines for effective, respectful dawah conversations that focus on understanding the other person\'s perspective, addressing their concerns, and presenting Islam in a clear and compassionate manner.',
        ar: 'إرشادات لمحادثات دعوية فعالة ومحترمة تركز على فهم وجهة نظر الشخص الآخر، ومعالجة مخاوفه، وتقديم الإسلام بطريقة واضحة ورحيمة.'
      },
      type: 'guide',
      level: 'beginner',
      languages: ['en', 'ar', 'fr', 'ur']
    },
    {
      id: 'scientific_evidence',
      title: {
        en: 'Scientific Evidence in the Quran and Sunnah',
        ar: 'الأدلة العلمية في القرآن والسنة'
      },
      content: {
        en: 'A collection of scientifically verified miracles from the Quran and Sunnah, with explanations from scholars and scientists.',
        ar: 'مجموعة من المعجزات المثبتة علميًا من القرآن والسنة، مع شروحات من العلماء والعلماء.'
      },
      type: 'reference',
      level: 'intermediate',
      languages: ['en', 'ar', 'fr', 'ur']
    },
    {
      id: 'comparative_religion',
      title: {
        en: 'Comparative Religion for Dawah',
        ar: 'مقارنة الأديان للدعوة'
      },
      content: {
        en: 'A respectful comparison of major world religions with Islam, focusing on common ground and addressing key differences.',
        ar: 'مقارنة محترمة للأديان العالمية الرئيسية مع الإسلام، مع التركيز على القواسم المشتركة ومعالجة الاختلافات الرئيسية.'
      },
      type: 'guide',
      level: 'advanced',
      languages: ['en', 'ar']
    }
  ];

  // Conversion success stories
  private conversionStories = [
    {
      id: 'scientist_conversion',
      title: {
        en: 'From Atheism to Islam: A Scientist\'s Journey',
        ar: 'من الإلحاد إلى الإسلام: رحلة عالِم'
      },
      story: {
        en: 'Dr. Jeffrey Lang, a mathematics professor, describes his journey from atheism to Islam. He was particularly moved by the Quran\'s logical approach and its scientific inimitability. Dr. Lang stated, "The Quran\'s description of natural phenomena led me to reflect on the source of this knowledge, which couldn\'t have been available 1400 years ago."',
        ar: 'يصف الدكتور جيفري لانغ، أستاذ الرياضيات، رحلته من الإلحاد إلى الإسلام. تأثر بشكل خاص بالنهج المنطقي للقرآن وإعجازه العلمي. قال الدكتور لانغ: "وصف القرآن للظواهر الطبيعية قادني إلى التفكير في مصدر هذه المعرفة، والتي لم تكن متاحة قبل 1400 عام."'
      },
      factors: ['scientific_evidence', 'logical_coherence', 'spiritual_fulfillment'],
      resource: 'Even Angels Ask: A Journey to Islam in America by Dr. Jeffrey Lang'
    },
    {
      id: 'former_priest_conversion',
      title: {
        en: 'A Former Priest Finds Truth in Islam',
        ar: 'قس سابق يجد الحقيقة في الإسلام'
      },
      story: {
        en: 'Yusuf Estes, a former Christian minister and federal prison chaplain, converted to Islam after theological discussions with a Muslim. His study of history and comparative religion led him to recognize the pure monotheism of Islam. He was particularly impressed by the Quran\'s preservation and the Prophet Muhammad\'s biography.',
        ar: 'يوسف إستس، وهو وزير مسيحي سابق وقس اتحادي للسجون، اعتنق الإسلام بعد مناقشات لاهوتية مع مسلم. قادته دراسته للتاريخ والأديان المقارنة إلى الاعتراف بالتوحيد الخالص للإسلام. أعجب بشكل خاص بحفظ القرآن وسيرة النبي محمد.'
      },
      factors: ['monotheism', 'textual_preservation', 'historical_evidence'],
      resource: 'My Journey to Islam by Yusuf Estes'
    }
  ];

  // Statistics tracking for dawah activities
  private dawahStats = {
    interactions: 0,
    questions_answered: 0,
    materials_shared: 0,
    potential_converts: 0,
    conversions: 0,
    top_questions: {} as Record<string, number>,
    active_regions: {} as Record<string, number>
  };

  // Training resources for dawah practitioners
  private trainingModules = [
    {
      id: 'dawah_ethics',
      title: 'Ethics of Dawah',
      description: 'Training on the ethical principles of Islamic dawah, emphasizing respect, honesty, and non-coercion.',
      level: 'beginner'
    },
    {
      id: 'scientific_approach',
      title: 'Scientific Approach to Dawah',
      description: 'How to effectively present scientific miracles in the Quran and Sunnah with academic integrity.',
      level: 'intermediate'
    },
    {
      id: 'addressing_misconceptions',
      title: 'Addressing Common Misconceptions',
      description: 'Strategies for respectfully addressing common misconceptions about Islam with evidence and wisdom.',
      level: 'intermediate'
    }
  ];

  // Initialize contacts database for dawah tracking
  private contacts: {
    id: string;
    name: string;
    source: string;
    religion?: string;
    interests?: string[];
    interactions: {
      date: string;
      type: string;
      topic: string;
      notes: string;
    }[];
    status: 'initial_contact' | 'interested' | 'learning' | 'convinced' | 'converted' | 'inactive';
    follow_up_date?: string;
  }[] = [];

  // Get faith inquiry categories
  getFaithCategories(): string[] {
    return this.faithCategories;
  }

  // Get common questions about Islam
  getCommonQuestions(
    category?: string,
    language: string = 'en',
    limit: number = 5
  ): {
    questions: any[];
    total: number;
  } {
    // Filter questions by category if provided
    let filteredQuestions = this.commonQuestions;
    if (category) {
      filteredQuestions = this.commonQuestions.filter(q => q.category === category);
    }
    
    // Process questions according to language
    const processedQuestions = filteredQuestions.map(question => ({
      id: question.id,
      category: question.category,
      question: question.question[language as keyof typeof question.question] || question.question.en,
      answer: question.answer[language as keyof typeof question.answer] || question.answer.en,
      sources: question.sources,
      related_questions: question.related_questions
    }));
    
    // Apply limit
    const limitedQuestions = processedQuestions.slice(0, limit);
    
    return {
      questions: limitedQuestions,
      total: filteredQuestions.length
    };
  }

  // Get response to a specific misconception
  getMisconceptionResponse(
    id: string,
    language: string = 'en'
  ): any {
    const misconception = this.misconceptionResponses.find(m => m.id === id);
    if (!misconception) return null;
    
    return {
      id: misconception.id,
      misconception: misconception.misconception[language as keyof typeof misconception.misconception] || 
                     misconception.misconception.en,
      correction: misconception.correction[language as keyof typeof misconception.correction] || 
                  misconception.correction.en,
      sources: misconception.sources,
      scriptural_evidence: misconception.scriptural_evidence
    };
  }

  // Get dawah resources
  getDawahResources(
    type?: string,
    level?: string,
    language: string = 'en'
  ): any[] {
    // Filter resources by type and level if provided
    let filteredResources = this.dawahResources;
    
    if (type) {
      filteredResources = filteredResources.filter(r => r.type === type);
    }
    
    if (level) {
      filteredResources = filteredResources.filter(r => r.level === level);
    }
    
    // Filter by language availability
    filteredResources = filteredResources.filter(r => r.languages.includes(language));
    
    // Process resources according to language
    return filteredResources.map(resource => ({
      id: resource.id,
      title: resource.title[language as keyof typeof resource.title] || resource.title.en,
      content: resource.content[language as keyof typeof resource.content] || resource.content.en,
      type: resource.type,
      level: resource.level
    }));
  }

  // Get conversion stories
  getConversionStories(
    factor?: string,
    language: string = 'en'
  ): any[] {
    // Filter stories by conversion factor if provided
    let filteredStories = this.conversionStories;
    
    if (factor) {
      filteredStories = filteredStories.filter(s => s.factors.includes(factor));
    }
    
    // Process stories according to language
    return filteredStories.map(story => ({
      id: story.id,
      title: story.title[language as keyof typeof story.title] || story.title.en,
      story: story.story[language as keyof typeof story.story] || story.story.en,
      factors: story.factors,
      resource: story.resource
    }));
  }

  // Get dawah statistics
  getDawahStats(): any {
    return this.dawahStats;
  }

  // Add new contact for dawah follow-up
  addContact(
    name: string,
    source: string,
    religion?: string,
    interests?: string[],
    notes?: string
  ): string {
    const id = `contact_${Date.now()}`;
    
    this.contacts.push({
      id,
      name,
      source,
      religion,
      interests,
      interactions: [
        {
          date: new Date().toISOString(),
          type: 'initial_contact',
          topic: 'Introduction',
          notes: notes || 'Initial contact'
        }
      ],
      status: 'initial_contact'
    });
    
    // Update stats
    this.dawahStats.interactions++;
    
    return id;
  }

  // Update contact with new interaction
  addInteraction(
    contactId: string,
    interactionType: string,
    topic: string,
    notes: string
  ): boolean {
    const contactIndex = this.contacts.findIndex(c => c.id === contactId);
    if (contactIndex === -1) return false;
    
    this.contacts[contactIndex].interactions.push({
      date: new Date().toISOString(),
      type: interactionType,
      topic,
      notes
    });
    
    // Update stats
    this.dawahStats.interactions++;
    if (interactionType === 'question_answered') {
      this.dawahStats.questions_answered++;
      
      // Update top questions
      const topicKey = topic.toLowerCase().replace(/\s+/g, '_');
      this.dawahStats.top_questions[topicKey] = (this.dawahStats.top_questions[topicKey] || 0) + 1;
    } else if (interactionType === 'material_shared') {
      this.dawahStats.materials_shared++;
    }
    
    return true;
  }

  // Update contact status
  updateContactStatus(
    contactId: string,
    status: 'initial_contact' | 'interested' | 'learning' | 'convinced' | 'converted' | 'inactive',
    notes?: string
  ): boolean {
    const contactIndex = this.contacts.findIndex(c => c.id === contactId);
    if (contactIndex === -1) return false;
    
    const oldStatus = this.contacts[contactIndex].status;
    this.contacts[contactIndex].status = status;
    
    // Add interaction for status change
    this.contacts[contactIndex].interactions.push({
      date: new Date().toISOString(),
      type: 'status_change',
      topic: `Status changed from ${oldStatus} to ${status}`,
      notes: notes || 'Status updated'
    });
    
    // Update stats
    if (status === 'interested' || status === 'learning') {
      this.dawahStats.potential_converts++;
    } else if (status === 'converted') {
      this.dawahStats.conversions++;
    }
    
    return true;
  }

  // Get all contacts with optional filters
  getContacts(
    status?: string,
    source?: string
  ): any[] {
    let filteredContacts = this.contacts;
    
    if (status) {
      filteredContacts = filteredContacts.filter(c => c.status === status);
    }
    
    if (source) {
      filteredContacts = filteredContacts.filter(c => c.source === source);
    }
    
    return filteredContacts;
  }

  // Generate personalized dawah content based on a person's background and interests
  async generatePersonalizedDawah(
    background: {
      religion?: string;
      education?: string;
      interests?: string[];
      objections?: string[];
    },
    language: string = 'en'
  ): Promise<{
    approach: string;
    key_points: string[];
    recommended_resources: string[];
    scientific_evidences?: {
      topic: string;
      evidence: string;
      source: string;
    }[];
  }> {
    try {
      // Identify the most relevant approach based on background
      let approach = 'general';
      let relevantTopics: string[] = [];
      
      // Determine approach based on background religion
      if (background.religion) {
        const religion = background.religion.toLowerCase();
        
        if (religion.includes('christ') || religion.includes('catholic') || religion.includes('protestant')) {
          approach = 'christian_background';
          relevantTopics = ['monotheism', 'jesus_in_islam', 'scripture_preservation'];
        } else if (religion.includes('jew')) {
          approach = 'jewish_background';
          relevantTopics = ['monotheism', 'prophets_in_islam', 'dietary_laws'];
        } else if (religion.includes('hindu')) {
          approach = 'hindu_background';
          relevantTopics = ['oneness_of_god', 'purpose_of_life', 'karma_and_afterlife'];
        } else if (religion.includes('buddhis')) {
          approach = 'buddhist_background';
          relevantTopics = ['spiritual_peace', 'ethics', 'purpose_of_life'];
        } else if (religion.includes('atheis') || religion.includes('agnost')) {
          approach = 'atheist_background';
          relevantTopics = ['scientific_evidence', 'logical_arguments', 'purpose_of_life'];
        }
      }
      
      // Add topics based on interests
      if (background.interests && background.interests.length > 0) {
        for (const interest of background.interests) {
          const normalizedInterest = interest.toLowerCase();
          
          if (normalizedInterest.includes('science') || normalizedInterest.includes('physics') || 
              normalizedInterest.includes('biology') || normalizedInterest.includes('astronomy')) {
            relevantTopics.push('scientific_miracles');
          } else if (normalizedInterest.includes('philosophy') || normalizedInterest.includes('ethics') || 
                     normalizedInterest.includes('moral')) {
            relevantTopics.push('islamic_ethics', 'philosophy_in_islam');
          } else if (normalizedInterest.includes('history') || normalizedInterest.includes('civilization')) {
            relevantTopics.push('islamic_history', 'contributions_to_civilization');
          } else if (normalizedInterest.includes('social') || normalizedInterest.includes('justice') || 
                     normalizedInterest.includes('community')) {
            relevantTopics.push('social_justice', 'community_in_islam');
          }
        }
      }
      
      // Make topics unique
      const uniqueTopics = new Set(relevantTopics);
      relevantTopics = Array.from(uniqueTopics);
      
      // Get scientific miracles if relevant
      let scientific_evidences;
      if (relevantTopics.includes('scientific_miracles')) {
        const miracles = await scientificMiraclesService.getMiraclesByCategory('all', {
          limit: 3,
          includeReferences: true,
          detailedExplanation: true
        });
        
        scientific_evidences = miracles.miracles.map(miracle => ({
          topic: miracle.id.replace(/_/g, ' '),
          evidence: miracle.description,
          source: miracle.references?.[0]?.source || 'Quran and Science'
        }));
      }
      
      // Prepare approach description based on background
      let approachDescription;
      switch (approach) {
        case 'christian_background':
          approachDescription = 'Focus on the commonalities between Christianity and Islam, particularly monotheism, reverence for Jesus, and shared ethical values. Address misconceptions about Islamic beliefs regarding Jesus and the Trinity with gentleness and respect.';
          break;
        case 'jewish_background':
          approachDescription = 'Emphasize the shared Abrahamic heritage, the importance of Moses in Islam, and the consistency of moral laws. Highlight the historical positive relations between Muslims and Jews throughout history.';
          break;
        case 'hindu_background':
          approachDescription = 'Discuss the concept of Tawhid (Islamic monotheism) in relation to the ultimate reality, connecting it to the search for truth in Hindu traditions. Address the practical aspects of Islamic lifestyle and community.';
          break;
        case 'buddhist_background':
          approachDescription = 'Connect Islamic spiritual practices to mindfulness, emphasizing Islam\'s balanced approach to spiritual and material life. Discuss how Islamic ethics address suffering and the path to inner peace.';
          break;
        case 'atheist_background':
          approachDescription = 'Present logical arguments for God\'s existence and scientific evidences from the Quran. Focus on rationality in Islamic thought and address common philosophical objections with intellectual rigor.';
          break;
        default:
          approachDescription = 'Introduce the core beliefs and practices of Islam, emphasizing its comprehensive approach to life and spirituality. Focus on the universal aspects of the message and its relevance to contemporary challenges.';
      }
      
      // Get recommended resources
      const recommendedResources = this.dawahResources
        .filter(resource => 
          relevantTopics.some(topic => 
            resource.content.en.toLowerCase().includes(topic.toLowerCase())
          ) && resource.languages.includes(language)
        )
        .map(resource => resource.title[language as keyof typeof resource.title] || resource.title.en)
        .slice(0, 3);
      
      // If we don't have enough targeted resources, add general ones
      if (recommendedResources.length < 3) {
        const generalResources = this.dawahResources
          .filter(resource => !recommendedResources.includes(resource.title.en) && resource.languages.includes(language))
          .map(resource => resource.title[language as keyof typeof resource.title] || resource.title.en)
          .slice(0, 3 - recommendedResources.length);
        
        recommendedResources.push(...generalResources);
      }
      
      // Key points based on relevant topics
      const keyPoints = relevantTopics.map(topic => {
        switch (topic) {
          case 'monotheism':
            return 'Islam emphasizes the pure oneness of God (Tawhid), with no partners or intermediaries.';
          case 'jesus_in_islam':
            return 'Jesus (peace be upon him) is revered in Islam as a mighty prophet, born miraculously to the Virgin Mary.';
          case 'scripture_preservation':
            return 'The Quran has been preserved exactly as revealed, without any additions or deletions for over 1400 years.';
          case 'prophets_in_islam':
            return 'Islam honors all biblical prophets including Adam, Noah, Abraham, Moses, and Jesus, with Muhammad being the final messenger.';
          case 'scientific_miracles':
            return 'The Quran contains numerous scientific facts that were unknown at the time of its revelation, pointing to its divine origin.';
          case 'purpose_of_life':
            return 'Islam provides clear purpose: to know, worship and serve God, and to develop ourselves spiritually while contributing positively to creation.';
          case 'islamic_ethics':
            return 'Islamic ethics emphasize justice, compassion, honesty, and respect for all life, providing a comprehensive framework for moral conduct.';
          default:
            return 'Islam is a comprehensive way of life that addresses spiritual, social, economic, and personal aspects with divine guidance.';
        }
      });
      
      return {
        approach: approachDescription,
        key_points: keyPoints,
        recommended_resources: recommendedResources,
        scientific_evidences
      };
    } catch (error) {
      console.error("Error generating personalized dawah content:", error);
      
      // Return a generic response in case of error
      return {
        approach: "General introduction to Islam focusing on core beliefs and practices.",
        key_points: [
          "Islam teaches the oneness of God (Tawhid).",
          "The Quran is the unchanged word of God revealed to Prophet Muhammad.",
          "Islam provides guidance for all aspects of life."
        ],
        recommended_resources: [
          "Introduction to Islam",
          "The Scientific Miracles of the Quran",
          "Common Questions about Islam"
        ]
      };
    }
  }

  // Generate response to a faith question using AI
  async generateFaithResponse(
    question: string,
    options: {
      detailLevel?: 'brief' | 'detailed' | 'comprehensive';
      includeScriptural?: boolean;
      includeScholarly?: boolean;
      audienceType?: 'general' | 'seekers' | 'academic' | 'interfaith';
      language?: string;
    } = {}
  ): Promise<{
    answer: string;
    scriptural_evidence?: {
      text: string;
      reference: string;
      translation?: string;
    }[];
    scholarly_references?: {
      scholar: string;
      reference: string;
      type: string;
    }[];
    related_topics?: string[];
  }> {
    try {
      // Default options
      const defaultOptions = {
        detailLevel: 'detailed' as const,
        includeScriptural: true,
        includeScholarly: true,
        audienceType: 'general' as const,
        language: 'en'
      };
      
      // Merge with provided options
      const settings = { ...defaultOptions, ...options };
      
      // Check if this is a common question with a pre-vetted answer
      const normalizedQuestion = question.toLowerCase().trim();
      
      // Look for matching common question
      const matchingQuestion = this.commonQuestions.find(q => 
        q.question.en.toLowerCase().includes(normalizedQuestion) ||
        normalizedQuestion.includes(q.question.en.toLowerCase()) ||
        (q.question.ar && q.question.ar.includes(normalizedQuestion))
      );
      
      if (matchingQuestion) {
        // We have a pre-vetted answer
        const answer = matchingQuestion.answer[settings.language as keyof typeof matchingQuestion.answer] || 
                       matchingQuestion.answer.en;
        
        const scholarly_references = matchingQuestion.sources;
        
        // For pre-vetted answers, we may not have scriptural evidence directly
        // In a real implementation, this would be more comprehensive
        
        return {
          answer,
          scholarly_references,
          related_topics: matchingQuestion.related_questions
        };
      }
      
      // If it's a misconception, use pre-vetted correction
      const matchingMisconception = this.misconceptionResponses.find(m => 
        normalizedQuestion.includes(m.misconception.en.toLowerCase()) ||
        (m.misconception.ar && normalizedQuestion.includes(m.misconception.ar))
      );
      
      if (matchingMisconception) {
        const answer = matchingMisconception.correction[settings.language as keyof typeof matchingMisconception.correction] || 
                       matchingMisconception.correction.en;
        
        return {
          answer,
          scriptural_evidence: matchingMisconception.scriptural_evidence,
          scholarly_references: matchingMisconception.sources,
          related_topics: ['misconceptions', matchingMisconception.id]
        };
      }
      
      // Check if it's related to scientific miracles
      const isScienceMiracleQuestion = normalizedQuestion.includes('scientific') && 
                                      (normalizedQuestion.includes('miracle') || 
                                       normalizedQuestion.includes('evidence') || 
                                       normalizedQuestion.includes('proof'));
      
      if (isScienceMiracleQuestion) {
        // Extract potential topic
        let topic = 'scientific miracles in islam';
        
        // Try to extract more specific topic
        const scienceKeywords = [
          'embryo', 'universe', 'astronomy', 'geology', 'mountains', 
          'sea', 'ocean', 'physics', 'iron', 'medicine', 'brain'
        ];
        
        for (const keyword of scienceKeywords) {
          if (normalizedQuestion.includes(keyword)) {
            topic = `${keyword} in quran`;
            break;
          }
        }
        
        // Get scientific miracle explanation
        const miracleExplanation = await scientificMiraclesService.generateMiracleExplanation(
          topic,
          {
            depth: settings.detailLevel === 'brief' ? 'simple' : 
                   settings.detailLevel === 'comprehensive' ? 'scholarly' : 'detailed',
            audience: settings.audienceType === 'academic' ? 'scientific' : 
                      settings.audienceType === 'interfaith' ? 'interfaith' : 'general',
            language: settings.language,
            includeReferences: settings.includeScholarly,
            includeVerses: settings.includeScriptural
          }
        );
        
        return {
          answer: miracleExplanation.explanation,
          scriptural_evidence: miracleExplanation.verses?.map(verse => ({
            text: verse.arabic,
            reference: verse.reference,
            translation: verse.translation
          })),
          scholarly_references: miracleExplanation.references?.map(ref => ({
            scholar: ref.author,
            reference: ref.source,
            type: 'scientific'
          })),
          related_topics: ['scientific_miracles', 'quran_authenticity']
        };
      }
      
      // No pre-vetted answer, use AI to generate response
      // First, check if the content is Islamic
      const islamicCheck = await islamicContentDetector.detectIslamicContent(question, settings.language);
      
      // If it's not related to Islam, generate a response that respectfully directs back to Islamic topics
      if (!islamicCheck.isIslamic && !normalizedQuestion.includes('islam') && !normalizedQuestion.includes('muslim')) {
        return {
          answer: `I'm focused on answering questions about Islamic faith, teachings, and practices. Your question appears to be about another topic. If you'd like to learn about Islam or have any questions about Islamic beliefs, I'd be happy to assist with that.`,
          related_topics: ['islam_basic', 'introduction_to_islam']
        };
      }
      
      // Build a prompt for generating a response
      let detailDescription;
      if (settings.detailLevel === 'brief') {
        detailDescription = 'concise and to the point, suitable for someone seeking a quick answer';
      } else if (settings.detailLevel === 'comprehensive') {
        detailDescription = 'comprehensive and in-depth, covering multiple perspectives and nuances';
      } else {
        detailDescription = 'balanced and informative, providing sufficient context and explanation';
      }
      
      let audienceDescription;
      if (settings.audienceType === 'seekers') {
        audienceDescription = 'someone sincerely seeking to understand Islam';
      } else if (settings.audienceType === 'academic') {
        audienceDescription = 'an academic or scholarly audience';
      } else if (settings.audienceType === 'interfaith') {
        audienceDescription = 'an interfaith dialogue context';
      } else {
        audienceDescription = 'a general audience with basic interest in Islam';
      }
      
      const systemPrompt = `You are an Islamic scholar providing accurate, thoughtful answers about Islam. 
Please provide a ${detailDescription} response to the following question from ${audienceDescription}.

The response should be:
1. Based strictly on authentic Islamic sources (Quran and authentic Hadith)
2. Reflecting mainstream Islamic understanding
3. Respectful and inviting in tone
4. Free from personal opinions or speculative interpretations
5. Academically accurate while remaining accessible

${settings.includeScriptural ? 'Include relevant Quranic verses or authentic Hadith with proper references.' : ''}
${settings.includeScholarly ? 'Include references to respected Islamic scholars where appropriate.' : ''}

Respond in ${settings.language === 'ar' ? 'Arabic' : 'English'} language.

Question: ${question}`;

      // Use appropriate AI service for generation
      let answer;
      try {
        // Try Anthropic first for better nuance on religious topics
        answer = await anthropicService.analyzeMultilingualContent(question, settings.language || 'en', systemPrompt);
      } catch (error) {
        // Fall back to OpenAI
        answer = await openaiService.enhanceTranslation(question, 'en', settings.language || 'en', true, systemPrompt);
      }
      
      // In a real implementation, we would parse the AI response into a structured format
      // Here we'll create a simplified structure
      
      // Generate relevant topics based on the question
      const relatedTopics = [];
      
      // Look at key terms in the question
      if (normalizedQuestion.includes('allah') || normalizedQuestion.includes('god')) {
        relatedTopics.push('tawhid', 'existence_of_god');
      }
      
      if (normalizedQuestion.includes('muhammad') || normalizedQuestion.includes('prophet')) {
        relatedTopics.push('prophet_muhammad', 'prophethood');
      }
      
      if (normalizedQuestion.includes('quran') || normalizedQuestion.includes('book')) {
        relatedTopics.push('quran_authenticity', 'revelation');
      }
      
      if (normalizedQuestion.includes('pray') || normalizedQuestion.includes('salah') || normalizedQuestion.includes('worship')) {
        relatedTopics.push('prayer', 'worship_in_islam');
      }
      
      if (normalizedQuestion.includes('heaven') || normalizedQuestion.includes('paradise') || 
          normalizedQuestion.includes('hell') || normalizedQuestion.includes('jannah') || 
          normalizedQuestion.includes('jahannam')) {
        relatedTopics.push('afterlife', 'day_of_judgment');
      }
      
      // Generate mock scriptural evidence and scholarly references
      // In a real implementation, these would be parsed from the AI response or retrieved from a database
      
      const scriptural_evidence = settings.includeScriptural ? [
        {
          text: 'This would contain the Arabic text of a relevant Quranic verse or Hadith',
          reference: 'This would contain the proper reference',
          translation: 'This would contain the translation'
        }
      ] : undefined;
      
      const scholarly_references = settings.includeScholarly ? [
        {
          scholar: 'This would reference a relevant scholar',
          reference: 'This would contain the work or publication',
          type: 'scholarly'
        }
      ] : undefined;
      
      return {
        answer,
        scriptural_evidence,
        scholarly_references,
        related_topics: relatedTopics.length > 0 ? relatedTopics : undefined
      };
    } catch (error) {
      console.error("Error generating faith response:", error);
      
      // Return a simple response in case of error
      return {
        answer: "I apologize, but I encountered an issue while processing your question. The question appears to be about Islamic faith, but I wasn't able to generate a complete response. Could you please rephrase your question, or ask about another aspect of Islam that interests you?"
      };
    }
  }
}

export const islamicDawahService = new IslamicDawahService();