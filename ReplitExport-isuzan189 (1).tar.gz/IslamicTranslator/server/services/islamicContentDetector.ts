import { openaiService } from "./openai";

// Service specialized in detecting and respecting Islamic content
export class IslamicContentDetector {
  // Dictionary of Islamic terms and their significance
  private islamicTerms = {
    // Names of Allah
    divineNames: [
      'الله', 'الرحمن', 'الرحيم', 'الملك', 'القدوس', 'السلام', 
      'المؤمن', 'المهيمن', 'العزيز', 'الجبار', 'المتكبر', 'الخالق',
      'البارئ', 'المصور', 'الغفار', 'القهار', 'الوهاب', 'الرزاق',
      'الفتاح', 'العليم', 'القابض', 'الباسط', 'الخافض', 'الرافع',
      'المعز', 'المذل', 'السميع', 'البصير', 'الحكم', 'العدل',
      'Allah', 'Ar-Rahman', 'Ar-Raheem', 'Al-Malik', 'Al-Quddus', 'As-Salam',
      'Al-Mu\'min', 'Al-Muhaymin', 'Al-Aziz', 'Al-Jabbar', 'Al-Mutakabbir',
      'Al-Khaliq', 'Al-Bari', 'Al-Musawwir', 'Al-Ghaffar', 'Al-Qahhar',
      'Al-Wahhab', 'Ar-Razzaq', 'Al-Fattah', 'Al-Alim', 'Al-Qabid', 'Al-Basit'
    ],
    
    // Prophets mentioned in the Quran
    prophets: [
      'محمد', 'ابراهيم', 'موسى', 'عيسى', 'نوح', 'آدم', 'يوسف', 
      'يعقوب', 'اسماعيل', 'اسحاق', 'داود', 'سليمان', 'أيوب', 'يونس',
      'هارون', 'لوط', 'إدريس', 'ذو الكفل', 'هود', 'شعيب', 'صالح',
      'زكريا', 'يحيى', 'الياس', 'اليسع', 'ذو القرنين',
      'Muhammad', 'Ibrahim', 'Musa', 'Isa', 'Nuh', 'Adam', 'Yusuf',
      'Yaqub', 'Ismail', 'Ishaq', 'Dawud', 'Sulaiman', 'Ayyub', 'Yunus',
      'Harun', 'Lut', 'Idris', 'Dhul-Kifl', 'Hud', 'Shuaib', 'Salih',
      'Zakariya', 'Yahya', 'Ilyas', 'Al-Yasa', 'Dhul-Qarnayn'
    ],
    
    // Common Islamic terms
    commonTerms: [
      'مسجد', 'صلاة', 'زكاة', 'حج', 'عمرة', 'صوم', 'رمضان', 'قرآن', 'حديث',
      'سنة', 'شريعة', 'فقه', 'عقيدة', 'توحيد', 'إيمان', 'إحسان', 'تقوى',
      'جهاد', 'هجرة', 'أذان', 'وضوء', 'تيمم', 'خطبة', 'طهارة', 'نية',
      'mosque', 'prayer', 'salah', 'zakat', 'hajj', 'umrah', 'fasting', 'sawm',
      'Ramadan', 'Quran', 'hadith', 'Sunnah', 'Shariah', 'fiqh', 'aqeedah',
      'tawhid', 'iman', 'ihsan', 'taqwa', 'jihad', 'hijrah', 'adhan', 'wudu',
      'tayammum', 'khutbah', 'taharah', 'niyyah'
    ],
    
    // Respectful phrases
    respectfulPhrases: [
      'صلى الله عليه وسلم', 'رضي الله عنه', 'رضي الله عنها', 'رحمه الله',
      'عليه السلام', 'سبحانه وتعالى', 'عز وجل', 'جل جلاله', 'تبارك وتعالى',
      'peace be upon him', 'PBUH', 'may Allah be pleased with him', 'may Allah be pleased with her',
      'may Allah have mercy on him', 'peace be upon them', 'Glorified and Exalted is He',
      'Mighty and Majestic is He', 'Blessed and Exalted is He'
    ],
    
    // Holy books
    holyBooks: [
      'القرآن', 'الكتاب', 'المصحف', 'التوراة', 'الإنجيل', 'الزبور', 'صحف',
      'Quran', 'Furqan', 'Mushaf', 'Torah', 'Injeel', 'Gospel', 'Zabur', 'Psalms', 'Suhuf'
    ],
    
    // Islamic events
    islamicEvents: [
      'العيد', 'عيد الفطر', 'عيد الأضحى', 'المولد النبوي', 'الإسراء والمعراج',
      'ليلة القدر', 'عاشوراء', 'الهجرة', 'غزوة', 'فتح مكة',
      'Eid', 'Eid al-Fitr', 'Eid al-Adha', 'Mawlid', 'Isra and Miraj',
      'Laylat al-Qadr', 'Ashura', 'Hijrah', 'ghazwa', 'Conquest of Makkah'
    ]
  };

  // Common Islamic phrases to detect in different languages
  private islamicPhrases = {
    'ar': [
      'بسم الله الرحمن الرحيم',
      'الحمد لله',
      'لا إله إلا الله',
      'الله أكبر',
      'سبحان الله',
      'استغفر الله',
      'ما شاء الله',
      'إنا لله وإنا إليه راجعون',
      'جزاك الله خيرا',
      'بارك الله فيك'
    ],
    'en': [
      'In the name of Allah',
      'All praise is due to Allah',
      'There is no god but Allah',
      'Allah is the Greatest',
      'Glory be to Allah',
      'I seek forgiveness from Allah',
      'Allah has willed it',
      'To Allah we belong and to Him we shall return',
      'May Allah reward you with goodness',
      'May Allah bless you'
    ]
  };

  // Detect if content is Islamic related
  async detectIslamicContent(text: string, language: string = 'auto'): Promise<{
    isIslamic: boolean;
    confidence: number;
    categories: string[];
    hasQuranicVerses: boolean;
    hasProphetMentions: boolean;
    requiresRespectfulHandling: boolean;
  }> {
    // Auto-detect language if not specified
    const detectedLanguage = language === 'auto' 
      ? await this.detectLanguage(text) 
      : language;
    
    let isIslamic = false;
    let confidence = 0;
    let categories: string[] = [];
    let hasQuranicVerses = false;
    let hasProphetMentions = false;
    let requiresRespectfulHandling = false;
    
    // First pass: rule-based detection
    isIslamic = this.basicDetection(text, detectedLanguage);
    
    // Check for Quranic verse patterns
    hasQuranicVerses = this.detectQuranicVerses(text, detectedLanguage);
    
    // Check for prophet mentions
    hasProphetMentions = this.detectProphetMentions(text);
    
    // Determine if content requires special respectful handling
    requiresRespectfulHandling = hasQuranicVerses || hasProphetMentions || 
      this.containsRespectfulPhrases(text);
    
    // If basic detection found something or special handling needed
    if (isIslamic || requiresRespectfulHandling) {
      confidence = 0.85;
      categories = this.determineCategories(text);
      
      return {
        isIslamic: true,
        confidence,
        categories,
        hasQuranicVerses,
        hasProphetMentions,
        requiresRespectfulHandling
      };
    }
    
    // Second pass: use AI for more nuanced detection
    try {
      const aiAnalysis = await this.aiBasedAnalysis(text, detectedLanguage);
      
      return {
        ...aiAnalysis,
        hasQuranicVerses: aiAnalysis.hasQuranicVerses || hasQuranicVerses,
        hasProphetMentions: aiAnalysis.hasProphetMentions || hasProphetMentions,
        requiresRespectfulHandling: 
          aiAnalysis.requiresRespectfulHandling || requiresRespectfulHandling
      };
    } catch (error) {
      console.error("Error in AI-based Islamic content detection:", error);
      
      // Fall back to basic detection
      return {
        isIslamic,
        confidence: 0.7,
        categories: this.determineCategories(text),
        hasQuranicVerses,
        hasProphetMentions,
        requiresRespectfulHandling
      };
    }
  }

  // Add respectful Islamic phrases where appropriate
  async enhanceWithRespectfulPhrases(text: string, language: string = 'ar'): Promise<string> {
    let enhancedText = text;
    
    // Add respectful phrase after mentions of Allah
    if (language === 'ar') {
      if (!text.includes('سبحانه وتعالى') && !text.includes('عز وجل') && 
          !text.includes('جل جلاله') && !text.includes('تبارك وتعالى')) {
        
        enhancedText = enhancedText.replace(/\bالله\b/g, 'الله سبحانه وتعالى');
      }
      
      // Add respectful phrase after mentions of Prophet Muhammad
      if (!text.includes('صلى الله عليه وسلم') && !text.includes('عليه الصلاة والسلام')) {
        enhancedText = enhancedText.replace(/\bمحمد\b/g, 'محمد صلى الله عليه وسلم');
        enhancedText = enhancedText.replace(/\bالنبي\b/g, 'النبي صلى الله عليه وسلم');
        enhancedText = enhancedText.replace(/\bالرسول\b/g, 'الرسول صلى الله عليه وسلم');
      }
      
      // Add respectful phrase after mentions of other prophets
      if (!text.includes('عليه السلام')) {
        for (const prophet of this.islamicTerms.prophets.filter(p => p !== 'محمد' && /[\u0600-\u06FF]/.test(p))) {
          const regex = new RegExp(`\\b${prophet}\\b`, 'g');
          enhancedText = enhancedText.replace(regex, `${prophet} عليه السلام`);
        }
      }
    } else if (language === 'en') {
      if (!text.includes('(Glorified and Exalted)') && !text.includes('(Mighty and Majestic)')) {
        enhancedText = enhancedText.replace(/\bAllah\b/g, 'Allah (Glorified and Exalted)');
      }
      
      // Add respectful phrase after mentions of Prophet Muhammad
      if (!text.includes('(peace be upon him)') && !text.includes('(PBUH)')) {
        enhancedText = enhancedText.replace(/\bMuhammad\b/g, 'Muhammad (peace be upon him)');
        enhancedText = enhancedText.replace(/\bThe Prophet\b/gi, 'The Prophet (peace be upon him)');
        enhancedText = enhancedText.replace(/\bThe Messenger\b/gi, 'The Messenger (peace be upon him)');
      }
      
      // Add respectful phrase after mentions of other prophets
      if (!text.includes('(peace be upon him)')) {
        for (const prophet of this.islamicTerms.prophets.filter(p => p !== 'Muhammad' && !/[\u0600-\u06FF]/.test(p))) {
          const regex = new RegExp(`\\b${prophet}\\b`, 'g');
          enhancedText = enhancedText.replace(regex, `${prophet} (peace be upon him)`);
        }
      }
    }
    
    return enhancedText;
  }

  // Verify that a translation respects Islamic terminology
  async verifyIslamicTranslation(
    sourceText: string, 
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string
  ): Promise<{
    isCompliant: boolean;
    issues: string[];
    suggestedCorrections: { original: string, suggested: string }[];
  }> {
    try {
      // Detect Islamic content in source
      const sourceAnalysis = await this.detectIslamicContent(sourceText, sourceLanguage);
      
      // Only perform deep verification if the source has Islamic content
      if (!sourceAnalysis.isIslamic) {
        return {
          isCompliant: true,
          issues: [],
          suggestedCorrections: []
        };
      }
      
      // Issues to track
      const issues: string[] = [];
      const suggestedCorrections: { original: string, suggested: string }[] = [];
      
      // Check for the most common translation issues
      if (sourceAnalysis.hasQuranicVerses) {
        // Verify Quranic content translation
        const quranicVerification = this.verifyQuranicTranslation(
          sourceText, translatedText, sourceLanguage, targetLanguage
        );
        
        if (!quranicVerification.isValid) {
          issues.push('Quranic content may not be accurately translated');
          issues.push(...quranicVerification.issues);
          suggestedCorrections.push(...quranicVerification.corrections);
        }
      }
      
      // Check for proper translation of Islamic terms
      if (targetLanguage === 'en') {
        // Check Arabic to English term translations
        if (sourceText.includes('الله') && translatedText.includes('God') && !translatedText.includes('Allah')) {
          issues.push('Islamic term "الله" should be translated as "Allah", not just "God"');
          suggestedCorrections.push({ 
            original: 'God', 
            suggested: 'Allah'
          });
        }
        
        // Other Arabic to English checks
        if (sourceText.includes('صلاة') && 
            translatedText.includes('prayer') && 
            !translatedText.includes('salah') && 
            !translatedText.includes('salat')) {
          issues.push('Consider using "salah" or "salat" alongside "prayer" for clarity');
          suggestedCorrections.push({ 
            original: 'prayer', 
            suggested: 'salah (prayer)'
          });
        }
      } else if (targetLanguage === 'ar') {
        // Check English to Arabic term translations
        if (sourceText.toLowerCase().includes('allah') && translatedText.includes('إله') && !translatedText.includes('الله')) {
          issues.push('Term "Allah" should be translated as "الله"');
          suggestedCorrections.push({ 
            original: 'إله', 
            suggested: 'الله'
          });
        }
      }
      
      // Check for respectful phrases
      if (sourceAnalysis.hasProphetMentions) {
        const respectVerification = this.verifyRespectfulPhrases(
          sourceText, translatedText, sourceLanguage, targetLanguage
        );
        
        if (!respectVerification.isValid) {
          issues.push('Respectful phrases for prophets may be missing');
          issues.push(...respectVerification.issues);
          suggestedCorrections.push(...respectVerification.corrections);
        }
      }
      
      // Use AI for deeper analysis if possible
      try {
        const aiVerification = await this.aiBasedVerification(
          sourceText, translatedText, sourceLanguage, targetLanguage
        );
        
        if (!aiVerification.isCompliant) {
          issues.push(...aiVerification.issues);
          suggestedCorrections.push(...aiVerification.suggestedCorrections);
        }
      } catch (error) {
        console.error("Error in AI-based Islamic translation verification:", error);
        // Continue with what we have if AI fails
      }
      
      return {
        isCompliant: issues.length === 0,
        issues,
        suggestedCorrections
      };
    } catch (err: any) {
      console.error("Error verifying Islamic translation:", err);
      return {
        isCompliant: true, // Default to compliant if verification fails
        issues: ["Verification error: " + (err.message || "Unknown error")],
        suggestedCorrections: []
      };
    }
  }

  // Basic rule-based detection of Islamic content
  private basicDetection(text: string, language: string): boolean {
    // Check for Islamic terms
    const allTerms = [
      ...this.islamicTerms.divineNames,
      ...this.islamicTerms.prophets,
      ...this.islamicTerms.commonTerms,
      ...this.islamicTerms.respectfulPhrases,
      ...this.islamicTerms.holyBooks,
      ...this.islamicTerms.islamicEvents
    ];
    
    // Convert text to lowercase for case-insensitive matching
    const lowerText = text.toLowerCase();
    
    // Check for terms
    for (const term of allTerms) {
      // For Arabic terms, use exact match
      if (/[\u0600-\u06FF]/.test(term)) {
        if (text.includes(term)) return true;
      } 
      // For Latin terms, use case-insensitive word boundary match
      else {
        const regex = new RegExp(`\\b${term.toLowerCase()}\\b`, 'i');
        if (regex.test(lowerText)) return true;
      }
    }
    
    // Check for common Islamic phrases
    const phrases = language === 'ar' ? this.islamicPhrases.ar : this.islamicPhrases.en;
    for (const phrase of phrases) {
      if (language === 'ar') {
        if (text.includes(phrase)) return true;
      } else {
        if (lowerText.includes(phrase.toLowerCase())) return true;
      }
    }
    
    return false;
  }

  // Detect Quranic verses
  private detectQuranicVerses(text: string, language: string): boolean {
    // Check for Arabic verses (with diacritics)
    const hasArabicDiacritics = /[\u064B-\u065F\u0670]/.test(text);
    
    // Check for Sura headers and common Quranic patterns
    if (language === 'ar') {
      const quranicPatterns = [
        'بسم الله الرحمن الرحيم',
        'قال الله تعالى',
        'قال تعالى',
        'يَا أَيُّهَا',
        'سورة',
        'آية',
        'قرآن كريم'
      ];
      
      for (const pattern of quranicPatterns) {
        if (text.includes(pattern)) return true;
      }
      
      // Surah number pattern
      const surahPattern = /سورة\s+[\u0600-\u06FF]+\s+\d+/;
      if (surahPattern.test(text)) return true;
      
      // Return true if text has diacritics and seems to be formal Arabic
      return hasArabicDiacritics && text.length > 20;
    } else {
      // English Quranic verse indicators
      const englishQuranicPatterns = [
        'Quran', 'Surah', 'Verse', 'Ayah', 'Allah says',
        'In the name of Allah', 'Verily', 'Indeed'
      ];
      
      const lowerText = text.toLowerCase();
      for (const pattern of englishQuranicPatterns) {
        if (lowerText.includes(pattern.toLowerCase())) return true;
      }
      
      // Check for verse reference pattern
      const versePattern = /\([^)]*\d+:\d+[^)]*\)/;
      return versePattern.test(text);
    }
  }

  // Detect prophet mentions
  private detectProphetMentions(text: string): boolean {
    for (const prophet of this.islamicTerms.prophets) {
      if (/[\u0600-\u06FF]/.test(prophet)) {
        // Arabic prophet name
        if (text.includes(prophet)) return true;
      } else {
        // English prophet name
        const regex = new RegExp(`\\b${prophet}\\b`, 'i');
        if (regex.test(text)) return true;
      }
    }
    
    // Check for general mentions
    const prophetPatterns = [
      'النبي', 'الرسول', 'Prophet', 'Messenger', 'Apostle'
    ];
    
    for (const pattern of prophetPatterns) {
      if (/[\u0600-\u06FF]/.test(pattern)) {
        if (text.includes(pattern)) return true;
      } else {
        const regex = new RegExp(`\\b${pattern}\\b`, 'i');
        if (regex.test(text)) return true;
      }
    }
    
    return false;
  }

  // Check if text contains respectful Islamic phrases
  private containsRespectfulPhrases(text: string): boolean {
    for (const phrase of this.islamicTerms.respectfulPhrases) {
      if (text.includes(phrase)) return true;
    }
    return false;
  }

  // Determine categories of Islamic content
  private determineCategories(text: string): string[] {
    const categories: string[] = [];
    
    // Theological content
    if (this.containsAny(text, [
      'توحيد', 'عقيدة', 'إيمان', 'الله', 'tawhid', 'aqeedah', 'iman', 'Allah'
    ])) {
      categories.push('theological');
    }
    
    // Quranic content
    if (this.containsAny(text, [
      'قرآن', 'آية', 'سورة', 'Quran', 'verse', 'surah', 'ayah'
    ])) {
      categories.push('quranic');
    }
    
    // Prophetic content
    if (this.containsAny(text, [
      'محمد', 'النبي', 'الرسول', 'حديث', 'سنة',
      'Muhammad', 'Prophet', 'Messenger', 'hadith', 'sunnah'
    ])) {
      categories.push('prophetic');
    }
    
    // Jurisprudential content
    if (this.containsAny(text, [
      'فقه', 'شريعة', 'حلال', 'حرام', 'مباح', 'مكروه', 'واجب',
      'fiqh', 'shariah', 'halal', 'haram', 'permissible', 'disliked', 'obligatory'
    ])) {
      categories.push('jurisprudential');
    }
    
    // Ethical & moral content
    if (this.containsAny(text, [
      'أخلاق', 'آداب', 'حسن الخلق', 'صدق', 'أمانة', 'ethics', 'morals', 'character', 'truthfulness', 'honesty'
    ])) {
      categories.push('ethical');
    }
    
    // If no specific category is detected
    if (categories.length === 0) {
      categories.push('general_islamic');
    }
    
    return categories;
  }

  // Check if text contains any of the keywords
  private containsAny(text: string, keywords: string[]): boolean {
    const lowerText = text.toLowerCase();
    
    for (const keyword of keywords) {
      if (/[\u0600-\u06FF]/.test(keyword)) {
        // Arabic keyword
        if (text.includes(keyword)) return true;
      } else {
        // Non-Arabic keyword
        if (lowerText.includes(keyword.toLowerCase())) return true;
      }
    }
    
    return false;
  }

  // Detect language of text
  private async detectLanguage(text: string): Promise<string> {
    // Simple heuristic for Arabic
    if (/[\u0600-\u06FF]/.test(text)) {
      return 'ar';
    }
    
    // Default to English
    return 'en';
  }

  // Verify Quranic translation
  private verifyQuranicTranslation(
    sourceText: string, 
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string
  ): {
    isValid: boolean;
    issues: string[];
    corrections: { original: string, suggested: string }[];
  } {
    // A simplified version - in a real application, this would be much more comprehensive
    const issues: string[] = [];
    const corrections: { original: string, suggested: string }[] = [];
    
    // Simple check: Allah should always be Allah
    if (targetLanguage === 'en' && sourceLanguage === 'ar') {
      if (sourceText.includes('الله') && translatedText.includes('God') && !translatedText.includes('Allah')) {
        issues.push('In Quranic translations, "الله" should be translated as "Allah"');
        corrections.push({ original: 'God', suggested: 'Allah' });
      }
    }
    
    return {
      isValid: issues.length === 0,
      issues,
      corrections
    };
  }

  // Verify respectful phrases
  private verifyRespectfulPhrases(
    sourceText: string, 
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string
  ): {
    isValid: boolean;
    issues: string[];
    corrections: { original: string, suggested: string }[];
  } {
    const issues: string[] = [];
    const corrections: { original: string, suggested: string }[] = [];
    
    // Check for Prophet Muhammad mentions
    if (sourceLanguage === 'ar' && targetLanguage === 'en') {
      if ((sourceText.includes('محمد صلى الله عليه وسلم') || 
           sourceText.includes('النبي صلى الله عليه وسلم')) && 
          translatedText.includes('Muhammad') && 
          !translatedText.includes('peace be upon him') && 
          !translatedText.includes('PBUH')) {
        
        issues.push('The phrase "صلى الله عليه وسلم" after Prophet Muhammad\'s name should be translated as "(peace be upon him)" or "(PBUH)"');
        
        corrections.push({ 
          original: 'Muhammad', 
          suggested: 'Muhammad (peace be upon him)'
        });
      }
    } else if (sourceLanguage === 'en' && targetLanguage === 'ar') {
      if ((sourceText.includes('Muhammad (peace be upon him)') || 
           sourceText.includes('Muhammad PBUH')) && 
          translatedText.includes('محمد') && 
          !translatedText.includes('صلى الله عليه وسلم')) {
        
        issues.push('The honorific "(peace be upon him)" should be translated as "صلى الله عليه وسلم" after Prophet Muhammad\'s name');
        
        corrections.push({ 
          original: 'محمد', 
          suggested: 'محمد صلى الله عليه وسلم'
        });
      }
    }
    
    return {
      isValid: issues.length === 0,
      issues,
      corrections
    };
  }

  // Use AI for more nuanced detection of Islamic content
  private async aiBasedAnalysis(text: string, language: string): Promise<{
    isIslamic: boolean;
    confidence: number;
    categories: string[];
    hasQuranicVerses: boolean;
    hasProphetMentions: boolean;
    requiresRespectfulHandling: boolean;
  }> {
    try {
      // Use OpenAI for analysis
      const analysisResult = await openaiService.analyzeCulturalContext(text, language);
      
      return {
        isIslamic: analysisResult.religiousContext && analysisResult.culturalContext.includes('Islamic'),
        confidence: 0.9,
        categories: this.determineCategories(text),
        hasQuranicVerses: this.detectQuranicVerses(text, language),
        hasProphetMentions: this.detectProphetMentions(text),
        requiresRespectfulHandling: analysisResult.religiousContext
      };
    } catch (err: any) {
      console.error("AI-based analysis error:", err);
      // Default fallback if AI analysis fails
      return {
        isIslamic: this.basicDetection(text, language),
        confidence: 0.7,
        categories: this.determineCategories(text),
        hasQuranicVerses: this.detectQuranicVerses(text, language),
        hasProphetMentions: this.detectProphetMentions(text),
        requiresRespectfulHandling: this.containsRespectfulPhrases(text)
      };
    }
  }

  // Use AI for deeper verification of Islamic translation
  private async aiBasedVerification(
    sourceText: string, 
    translatedText: string,
    sourceLanguage: string,
    targetLanguage: string
  ): Promise<{
    isCompliant: boolean;
    issues: string[];
    suggestedCorrections: { original: string, suggested: string }[];
  }> {
    try {
      // Use OpenAI for content filtering
      const filterAnalysis = await openaiService.analyzeContentForFiltering(translatedText, targetLanguage);
      
      if (filterAnalysis.containsProhibitedContent) {
        return {
          isCompliant: false,
          issues: ['The translation contains content that may not align with Islamic values'],
          suggestedCorrections: [{ 
            original: translatedText, 
            suggested: filterAnalysis.filteredText 
          }]
        };
      }
      
      return {
        isCompliant: true,
        issues: [],
        suggestedCorrections: []
      };
    } catch (err: any) {
      console.error("AI-based verification error:", err);
      // Default to compliant if verification fails
      return {
        isCompliant: true,
        issues: [],
        suggestedCorrections: []
      };
    }
  }
}

export const islamicContentDetector = new IslamicContentDetector();