import { translationRequestSchema } from "@shared/schema";
import { storage } from "../storage";
import { openaiService } from "./openai";
import { anthropicService } from "./anthropic";
import { islamicContentDetector } from "./islamicContentDetector";

// Enhanced translation service with Islamic cultural context awareness and OpenAI integration
export class TranslationService {
  // Cultural contexts and Islamic terminology dictionary
  private islamicTerms = {
    // English to Arabic terms
    en: {
      "prayer": "صلاة",
      "mosque": "مسجد",
      "hajj": "حج",
      "God": "الله",
      "prophet": "نبي",
      "Ramadan": "رمضان",
      "Quran": "القرآن",
      "mecca": "مكة",
      "halal": "حلال",
      "heaven": "الجنة",
      "hell": "النار",
      "angel": "ملاك",
      "charity": "صدقة",
      "fasting": "صيام",
      "blessing": "بركة",
      "faith": "إيمان",
      "sin": "ذنب",
      "mercy": "رحمة",
      "peace be upon him": "صلى الله عليه وسلم",
      "pbuh": "صلى الله عليه وسلم",
      "may Allah be pleased with him": "رضي الله عنه",
      "judgement day": "يوم القيامة"
    },
    // Arabic to English terms
    ar: {
      "صلاة": "prayer",
      "مسجد": "mosque",
      "حج": "hajj",
      "الله": "Allah",
      "نبي": "prophet",
      "رمضان": "Ramadan",
      "القرآن": "Quran",
      "مكة": "Mecca",
      "حلال": "halal",
      "الجنة": "Paradise",
      "النار": "Hellfire",
      "ملاك": "angel",
      "صدقة": "charity",
      "صيام": "fasting",
      "بركة": "blessing",
      "إيمان": "faith",
      "ذنب": "sin",
      "رحمة": "mercy",
      "صلى الله عليه وسلم": "peace be upon him (PBUH)",
      "رضي الله عنه": "may Allah be pleased with him",
      "يوم القيامة": "Day of Judgment"
    }
  };

  // Cultural customs awareness dictionary
  private culturalCustoms = {
    "en": {
      "boyfriend": "friend (تعديل للتوافق مع القيم الإسلامية)",
      "girlfriend": "friend (تعديل للتوافق مع القيم الإسلامية)",
      "dating": "meeting (تعديل للتوافق مع القيم الإسلامية)",
      "alcohol": "beverage (تعديل للتوافق مع القيم الإسلامية)",
      "pork": "meat (تعديل للتوافق مع القيم الإسلامية)",
      "christmas": "winter holiday (تعديل للتوافق مع القيم الإسلامية)",
      "church": "place of worship (تعديل للتوافق مع القيم الإسلامية)",
      "easter": "spring holiday (تعديل للتوافق مع القيم الإسلامية)"
    },
    "ar": {
      "صديقي": "my friend (culturally adapted)",
      "صديقتي": "my friend (culturally adapted)",
      "مواعدة": "meeting (culturally adapted)",
      "خمر": "drink (culturally adapted)",
      "لحم خنزير": "meat (culturally adapted)",
      "الكريسماس": "winter celebration (culturally adapted)",
      "كنيسة": "place of worship (culturally adapted)",
      "عيد الفصح": "spring celebration (culturally adapted)"
    }
  };

  // Translate text with Islamic cultural awareness using AI model
  async translateText(sourceText: string, sourceLanguage: string, targetLanguage: string) {
    try {
      // Validate request
      const validatedData = translationRequestSchema.parse({
        sourceText,
        sourceLanguage,
        targetLanguage
      });
      
      // Filter content based on Islamic values
      const filteredText = await this.filterContent(validatedData.sourceText, validatedData.sourceLanguage);
      
      let translatedText = '';
      let contextAnalysis;
      let dialectInfo = null;
      let usedAdvancedModel = false;
      
      // Try using Anthropic if available for advanced cultural understanding
      if (anthropicService.isAvailable()) {
        try {
          console.log("Using Anthropic service for enhanced translation");
          usedAdvancedModel = true;
          
          // Get detailed multilingual analysis with dialect detection
          const multilingualAnalysis = await anthropicService.analyzeMultilingualContent(
            filteredText,
            sourceLanguage
          );
          
          // Use the enhanced translation capabilities
          translatedText = await anthropicService.enhancedTranslation(
            filteredText,
            sourceLanguage,
            targetLanguage,
            multilingualAnalysis.religiousContext // Preserve Islamic terms if religious context detected
          );
          
          dialectInfo = multilingualAnalysis.dialectIdentification;
          contextAnalysis = {
            culturalContext: multilingualAnalysis.culturalNuances.join(", "),
            religiousContext: multilingualAnalysis.religiousContext,
            formalityLevel: multilingualAnalysis.formalityLevel
          };
        } catch (anthropicError) {
          console.error("Anthropic translation error, falling back to OpenAI:", anthropicError);
          usedAdvancedModel = false;
        }
      }
      
      // If Anthropic is not available or failed, use OpenAI
      if (!usedAdvancedModel) {
        console.log("Using OpenAI service for translation");
        
        // First analyze the cultural context to optimize translation approach
        contextAnalysis = await openaiService.analyzeCulturalContext(filteredText, sourceLanguage);
        
        // If text contains religious context, use enhanced Islamic-aware translation
        if (contextAnalysis.religiousContext) {
          console.log("Religious context detected, using specialized Islamic translation");
          translatedText = await openaiService.enhanceTranslation(
            filteredText, 
            sourceLanguage, 
            targetLanguage,
            true // Preserve Islamic terms
          );
        } else {
          // For non-religious content, still use enhanced translation but with different settings
          translatedText = await openaiService.enhanceTranslation(
            filteredText, 
            sourceLanguage, 
            targetLanguage,
            false // Regular translation but still culturally sensitive
          );
          
          // Apply Islamic terms enhancement as a second layer
          translatedText = this.enhanceWithIslamicContext(translatedText, sourceLanguage, targetLanguage);
        }
      }
      
      // Apply formality adjustments based on context analysis
      if (contextAnalysis && contextAnalysis.formalityLevel === "formal") {
        translatedText = this.adjustFormality(translatedText, targetLanguage, "formal");
      } else if (contextAnalysis && contextAnalysis.formalityLevel === "informal") {
        translatedText = this.adjustFormality(translatedText, targetLanguage, "informal");
      }
      
      // Filter the translated content if needed
      translatedText = await this.filterContent(translatedText, targetLanguage);
      
      // Run an Islamic compliance check on the final translation
      const complianceCheck = await this.checkIslamicCompliance(translatedText, targetLanguage);
      if (complianceCheck.hasNonCompliantContent) {
        console.log("Non-compliant content detected, applying corrections");
        translatedText = complianceCheck.correctedText;
      }
      
      // Update stats
      await storage.updateStats({
        textTranslations: 1,
        voiceTranslations: 0,
        imageTranslations: 0,
        totalCharacters: sourceText.length,
        languageStats: {
          [sourceLanguage]: 1,
          [targetLanguage]: 1
        }
      });
      
      // Safely extract analysis values
      const culturalContext = contextAnalysis ? contextAnalysis.culturalContext : "general";
      const religiousContext = contextAnalysis ? contextAnalysis.religiousContext : false;
      
      return { 
        translatedText,
        culturalContext,
        dialectInfo, // New information about dialect
        religiousContext,
        isIslamicCompliant: !complianceCheck.hasNonCompliantContent,
        translationEngine: usedAdvancedModel ? "advanced" : "standard" // Indicate which AI model was used
      };
    } catch (error) {
      console.error("Translation error:", error);
      // Fallback to basic translation if all AI services fail
      const basicTranslatedText = this.simulateTranslation(sourceText, sourceLanguage, targetLanguage);
      return { translatedText: basicTranslatedText };
    }
  }
  
  // Adjust formality level of the translation
  private adjustFormality(text: string, language: string, formalityLevel: "formal" | "informal"): string {
    if (language === 'ar') {
      if (formalityLevel === "formal") {
        // For Arabic, replace informal pronouns and verbs with formal ones
        return text
          .replace(/انت/g, "حضرتك")
          .replace(/انتم/g, "حضراتكم");
      } else {
        // No changes needed for informal in Arabic
        return text;
      }
    } else if (language === 'en') {
      if (formalityLevel === "formal") {
        // For English, replace contractions with full forms
        return text
          .replace(/don't/g, "do not")
          .replace(/can't/g, "cannot")
          .replace(/won't/g, "will not")
          .replace(/I'm/g, "I am")
          .replace(/you're/g, "you are")
          .replace(/they're/g, "they are")
          .replace(/we're/g, "we are")
          .replace(/it's/g, "it is");
      } else {
        // No changes needed for informal in English
        return text;
      }
    }
    
    // Default case: return unchanged
    return text;
  }
  
  // Check for Islamic compliance and correct if needed
  private async checkIslamicCompliance(text: string, language: string): Promise<{
    hasNonCompliantContent: boolean;
    correctedText: string;
    islamicContext?: {
      hasIslamicTerminology: boolean;
      enhancedWithIslamicContext: boolean;
      multipleInterpretations?: Record<string, string[]>;
    };
  }> {
    try {
      // First perform advanced Islamic content detection
      const islamicDetection = await islamicContentDetector.detectIslamicContent(text, language);
      
      // Use OpenAI to check for Islamic compliance
      const analysisResult = await openaiService.analyzeContentForFiltering(text, language);
      
      let enhancedText = text;
      let hasNonCompliantContent = analysisResult.containsProhibitedContent;
      
      // If prohibited content is detected, use the filtered version
      if (hasNonCompliantContent) {
        enhancedText = analysisResult.filteredText;
      }
      
      // If this is Islamic content, apply special handling
      if (islamicDetection.isIslamic) {
        // Add respectful Islamic phrases and honorifics where appropriate
        enhancedText = await islamicContentDetector.enhanceWithRespectfulPhrases(enhancedText, language);
        
        // Create a dictionary of terms with multiple interpretations for awareness
        const multipleInterpretations: Record<string, string[]> = {};
        
        // Examples of terms with multiple interpretations
        if (language === 'ar') {
          multipleInterpretations['البعث'] = [
            'القيامة والنشور',
            'إرسال الرسل',
            'إحياء الموتى',
            'نهضة أو حركة'
          ];
          
          multipleInterpretations['الخاتم'] = [
            'آخر الشيء ونهايته',
            'الطابع أو الختم',
            'خاتم يُلبس في الإصبع'
          ];
          
          multipleInterpretations['الولي'] = [
            'المتولي للأمر',
            'الناصر والمحب',
            'الصديق والقريب',
            'من له ولاية دينية'
          ];
        } else if (language === 'en') {
          multipleInterpretations['resurrection'] = [
            'raising of the dead on Judgment Day',
            'revival or rebirth',
            'the sending of prophets',
            'spiritual awakening'
          ];
          
          multipleInterpretations['seal'] = [
            'final or last in a series',
            'mark of authentication',
            'object used to stamp or authenticate'
          ];
          
          multipleInterpretations['guardian'] = [
            'one who protects or defends',
            'one with legal authority',
            'a close ally or friend',
            'one with spiritual authority'
          ];
        }
        
        return {
          hasNonCompliantContent,
          correctedText: enhancedText,
          islamicContext: {
            hasIslamicTerminology: true,
            enhancedWithIslamicContext: true,
            multipleInterpretations: Object.keys(multipleInterpretations).length > 0 ? 
              multipleInterpretations : undefined
          }
        };
      }
      
      // If no Islamic content detected, just return compliance status
      return {
        hasNonCompliantContent,
        correctedText: enhancedText,
        islamicContext: {
          hasIslamicTerminology: false,
          enhancedWithIslamicContext: false
        }
      };
    } catch (error) {
      console.error("Islamic compliance check error:", error);
      // If the check fails, return the original text
      return {
        hasNonCompliantContent: false,
        correctedText: text,
        islamicContext: {
          hasIslamicTerminology: false,
          enhancedWithIslamicContext: false
        }
      };
    }
  }
  
  // Enhance translation with Islamic context and terminology
  private enhanceWithIslamicContext(text: string, sourceLanguage: string, targetLanguage: string): string {
    // Get the appropriate Islamic terms dictionary based on target language
    const termsDict = targetLanguage === 'ar' ? this.islamicTerms.en : this.islamicTerms.ar;
    const customsDict = targetLanguage === 'ar' ? this.culturalCustoms.en : this.culturalCustoms.ar;
    
    let enhancedText = text;
    
    // Apply Islamic terminology enhancements
    for (const [term, translation] of Object.entries(termsDict)) {
      // Use word boundary in regex to match only complete words
      const regex = new RegExp(`\\b${term}\\b`, 'gi');
      enhancedText = enhancedText.replace(regex, translation);
    }
    
    // Apply cultural customs adaptations
    for (const [term, adaptation] of Object.entries(customsDict)) {
      const regex = new RegExp(`\\b${term}\\b`, 'gi');
      enhancedText = enhancedText.replace(regex, adaptation);
    }
    
    return enhancedText;
  }
  
  // Filter content based on Islamic values
  async filterContent(text: string, language: string) {
    // Get prohibited words for the language
    const prohibitedWords = await storage.getProhibitedWords(language);
    
    let filteredText = text;
    
    // Replace prohibited words with their replacements
    for (const word of prohibitedWords) {
      const regex = new RegExp(`\\b${word.word}\\b`, 'gi');
      filteredText = filteredText.replace(regex, word.replacement || '[تم التصفية]');
    }
    
    return filteredText;
  }
  
  // Simulate translation for development purposes
  private simulateTranslation(text: string, sourceLanguage: string, targetLanguage: string): string {
    // This is only for demonstration purposes
    // In a real app, this would be replaced with actual API calls
    
    if (sourceLanguage === 'ar' && targetLanguage === 'en') {
      // Arabic to English examples
      if (text.includes('مرحباً')) return text.replace('مرحباً', 'Hello');
      if (text.includes('كيف حالك')) return text.replace('كيف حالك', 'How are you');
      if (text.includes('شكراً')) return text.replace('شكراً', 'Thank you');
      if (text.includes('الله')) return text.replace('الله', 'Allah');
      if (text.includes('المسجد')) return text.replace('المسجد', 'the mosque');
      if (text.includes('صلاة')) return text.replace('صلاة', 'prayer');
      
      // Default simulation for Arabic to English
      return `[Translated from Arabic to English]: ${text}`;
    }
    
    if (sourceLanguage === 'en' && targetLanguage === 'ar') {
      // English to Arabic examples
      if (text.includes('Hello')) return text.replace('Hello', 'مرحباً');
      if (text.includes('How are you')) return text.replace('How are you', 'كيف حالك');
      if (text.includes('Thank you')) return text.replace('Thank you', 'شكراً');
      if (text.includes('God')) return text.replace('God', 'الله');
      if (text.includes('mosque')) return text.replace('mosque', 'المسجد');
      if (text.includes('prayer')) return text.replace('prayer', 'صلاة');
      
      // Default simulation for English to Arabic
      return `[ترجمة من الإنجليزية إلى العربية]: ${text}`;
    }
    
    // Default case for other language combinations
    return `[Translated from ${sourceLanguage} to ${targetLanguage}]: ${text}`;
  }
}

export const translationService = new TranslationService();
