import { imageToTextRequestSchema } from "@shared/schema";
import { storage } from "../storage";
import { translationService } from "./translation";
import { openaiService } from "./openai";
import { filterService } from "./filter";
import { islamicContentDetector } from "./islamicContentDetector";

// Enhanced vision service with culturally-aware image analysis
export class VisionService {
  // Types of content detected in images
  private contentTypes = {
    'TEXT': 'text',
    'HANDWRITING': 'handwriting',
    'ISLAMIC_CALLIGRAPHY': 'islamic_calligraphy',
    'BOOK_PAGE': 'book_page',
    'DOCUMENT': 'document',
    'SIGN': 'sign',
    'SOCIAL_MEDIA': 'social_media'
  };

  // Extract text from images and translate it with cultural awareness and OpenAI
  async imageToText(imageData: string, sourceLanguage: string, targetLanguage: string) {
    try {
      // Validate request
      const validatedData = imageToTextRequestSchema.parse({
        imageData,
        sourceLanguage,
        targetLanguage
      });
      
      // First, verify that image doesn't contain prohibited content
      let hasProhibitedContent = false;
      try {
        // In a real implementation, this would call a content moderation API
        // that can analyze the image directly for prohibited content
        // For now, we'll proceed with text extraction and check the extracted text
        console.log("Checking image for prohibited content");
      } catch (error) {
        console.error("Error checking image for prohibited content:", error);
      }
      
      // Use OpenAI vision to accurately extract text from the image
      let extractedText = '';
      try {
        extractedText = await openaiService.extractTextFromImage(imageData, sourceLanguage);
        console.log("Successfully extracted text using OpenAI Vision");
        
        // Now check the extracted text for prohibited content
        hasProhibitedContent = await filterService.containsProhibitedContent(extractedText, sourceLanguage);
        if (hasProhibitedContent) {
          console.log("Prohibited content detected in image text");
          return {
            extractedText: "",
            translatedText: "",
            contentType: "PROHIBITED_CONTENT",
            hasIslamicContext: false,
            quranicVerseDetected: false,
            religiousContext: false,
            isIslamicCompliant: false,
            error: "المحتوى غير متوافق مع القيم الإسلامية" // Content does not comply with Islamic values
          };
        }
      } catch (error) {
        console.error("OpenAI Vision extraction failed, falling back to basic extraction:", error);
        // Fall back to basic extraction if OpenAI fails
        const { extractedText: basicText } = this.processImage(imageData, sourceLanguage);
        extractedText = basicText;
      }
      
      // Perform Islamic content detection
      const islamicAnalysis = await islamicContentDetector.detectIslamicContent(extractedText, sourceLanguage);
      
      // Determine content type and Islamic context
      const { contentType, hasIslamicContext } = this.analyzeExtractedText(extractedText, sourceLanguage);
      
      // Apply special handling for Islamic calligraphy or Arabic script
      let enhancedText = extractedText;
      if (islamicAnalysis.isIslamic || hasIslamicContext || 
          (sourceLanguage === 'ar' && contentType === this.contentTypes.ISLAMIC_CALLIGRAPHY)) {
        console.log("Islamic context detected in image text, applying special enhancements");
        enhancedText = await islamicContentDetector.enhanceWithRespectfulPhrases(
          extractedText, sourceLanguage
        );
      }
      
      // Filter any potentially problematic content before translation
      enhancedText = await filterService.filterContent(enhancedText, sourceLanguage);
      
      // Translate the extracted text with cultural sensitivity
      const translation = await translationService.translateText(
        enhancedText,
        sourceLanguage,
        targetLanguage
      );
      
      const translatedText = translation.translatedText;
      
      // Update stats
      await storage.updateStats({
        textTranslations: 0,
        voiceTranslations: 0,
        imageTranslations: 1,
        totalCharacters: extractedText.length,
        languageStats: {
          [sourceLanguage]: 1,
          [targetLanguage]: 1
        }
      });
      
      // Check if the image contains any text that shouldn't be translated (like Quranic verses)
      const quranicVerseDetected = islamicAnalysis.hasQuranicVerses || this.detectQuranicVerses(extractedText, sourceLanguage);
      
      return {
        extractedText: enhancedText,
        translatedText,
        contentType,
        hasIslamicContext: islamicAnalysis.isIslamic || hasIslamicContext,
        quranicVerseDetected,
        religiousContext: translation.religiousContext || hasIslamicContext || islamicAnalysis.isIslamic,
        isIslamicCompliant: translation.isIslamicCompliant !== false,
        islamicCategories: islamicAnalysis.isIslamic ? islamicAnalysis.categories : undefined
      };
    } catch (error) {
      console.error("Image-to-text error:", error);
      throw new Error("Failed to extract and translate text from image");
    }
  }
  
  // Analyze extracted text to determine content type and context
  private analyzeExtractedText(text: string, language: string): {
    contentType: string;
    hasIslamicContext: boolean;
  } {
    // Determine content type
    let contentType = this.contentTypes.TEXT;
    if (language === 'ar') {
      // For Arabic, check for common patterns that might indicate content type
      if (text.includes('القرآن') || text.includes('سورة')) {
        contentType = this.contentTypes.ISLAMIC_CALLIGRAPHY;
      } else if (text.includes('صفحة') || text.includes('كتاب')) {
        contentType = this.contentTypes.BOOK_PAGE;
      } else if (text.includes('بخط اليد') || text.length < 50) {
        contentType = this.contentTypes.HANDWRITING;
      }
    } else {
      // For English and other languages
      if (text.includes('Quran') || text.includes('Allah')) {
        contentType = this.contentTypes.ISLAMIC_CALLIGRAPHY;
      } else if (text.includes('page') || text.includes('book')) {
        contentType = this.contentTypes.BOOK_PAGE;
      } else if (text.includes('handwritten') || text.length < 50) {
        contentType = this.contentTypes.HANDWRITING;
      }
    }
    
    // Detect if the content has Islamic context
    const hasIslamicContext = this.detectIslamicContext(text, language);
    
    return {
      contentType,
      hasIslamicContext
    };
  }
  
  // Detect Quranic verses to prevent incorrect translation
  private detectQuranicVerses(text: string, language: string): boolean {
    // Common Quranic verse starters in Arabic
    const quranicIndicators = [
      'بسم الله الرحمن الرحيم', 
      'قال الله تعالى',
      'يَا أَيُّهَا الَّذِينَ آمَنُوا',
      'قُلْ',
      'إِنَّ اللَّهَ',
      'وَاللَّهُ',
      'سورة'
    ];
    
    // Arabic verse patterns (with diacritics which are common in Quran)
    const hasArabicDiacritics = /[\u064B-\u065F\u0670]/.test(text); // Arabic diacritics are common in Quran
    
    // English translations of Quranic verse starters
    const englishQuranicIndicators = [
      'In the name of Allah',
      'Allah Almighty says',
      'O you who believe',
      'Say',
      'Indeed, Allah',
      'And Allah',
      'Surah'
    ];
    
    if (language === 'ar') {
      return hasArabicDiacritics || quranicIndicators.some(indicator => text.includes(indicator));
    } else {
      return englishQuranicIndicators.some(indicator => text.toLowerCase().includes(indicator.toLowerCase()));
    }
  }
  
  // Process image to extract text and detect context
  private processImage(imageData: string, language: string): { 
    extractedText: string; 
    contentType: string;
    hasIslamicContext: boolean;
  } {
    // In a real implementation, this would use computer vision APIs
    // For this demo, we'll simulate image analysis
    
    // Extract text from the image
    const extractedText = this.simulateImageTextExtraction(imageData, language);
    
    // Determine content type (would be AI-based in real implementation)
    let contentType = this.contentTypes.TEXT;
    if (language === 'ar') {
      // For Arabic, check for common patterns that might indicate content type
      if (extractedText.includes('القرآن') || extractedText.includes('سورة')) {
        contentType = this.contentTypes.ISLAMIC_CALLIGRAPHY;
      } else if (extractedText.includes('صفحة') || extractedText.includes('كتاب')) {
        contentType = this.contentTypes.BOOK_PAGE;
      } else if (extractedText.includes('بخط اليد') || extractedText.length < 50) {
        contentType = this.contentTypes.HANDWRITING;
      }
    } else {
      // For English and other languages
      if (extractedText.includes('Quran') || extractedText.includes('Allah')) {
        contentType = this.contentTypes.ISLAMIC_CALLIGRAPHY;
      } else if (extractedText.includes('page') || extractedText.includes('book')) {
        contentType = this.contentTypes.BOOK_PAGE;
      } else if (extractedText.includes('handwritten') || extractedText.length < 50) {
        contentType = this.contentTypes.HANDWRITING;
      }
    }
    
    // Detect if the content has Islamic context
    const hasIslamicContext = this.detectIslamicContext(extractedText, language);
    
    return {
      extractedText,
      contentType,
      hasIslamicContext
    };
  }
  
  // Detect if the text has Islamic context
  private detectIslamicContext(text: string, language: string): boolean {
    if (language === 'ar') {
      // Arabic Islamic indicators
      const islamicTerms = [
        'الله', 'القرآن', 'محمد', 'الإسلام', 'مسجد', 'صلاة', 'زكاة', 'حج', 
        'عمرة', 'صوم', 'رمضان', 'عيد', 'سنة', 'حديث', 'فقه', 'شريعة',
        'بسم الله', 'سبحان الله', 'الحمد لله', 'لا إله إلا الله'
      ];
      
      return islamicTerms.some(term => text.includes(term));
    } else {
      // English/other languages Islamic indicators
      const islamicTerms = [
        'Allah', 'Quran', 'Muhammad', 'Islam', 'mosque', 'prayer', 'salat', 
        'zakat', 'hajj', 'umrah', 'fasting', 'Ramadan', 'Eid', 'Sunnah', 
        'hadith', 'fiqh', 'Shariah', 'Bismillah', 'Alhamdulillah', 'La ilaha illallah'
      ];
      
      return islamicTerms.some(term => text.toLowerCase().includes(term.toLowerCase()));
    }
  }
  
  // Enhance text with Islamic context
  private enhanceWithIslamicContext(text: string, language: string): string {
    let enhancedText = text;
    
    // Add respectful phrases after mentions of prophets or Allah
    if (language === 'ar') {
      // Arabic enhancements
      if (text.includes('محمد') && !text.includes('صلى الله عليه وسلم')) {
        enhancedText = enhancedText.replace(/محمد/g, 'محمد صلى الله عليه وسلم');
      }
      if (text.includes('الله') && !text.includes('سبحانه وتعالى') && !text.includes('عز وجل')) {
        enhancedText = enhancedText.replace(/الله/g, 'الله سبحانه وتعالى');
      }
    } else {
      // English enhancements
      if (text.includes('Muhammad') && !text.includes('peace be upon him') && !text.includes('PBUH')) {
        enhancedText = enhancedText.replace(/Muhammad/gi, 'Muhammad (peace be upon him)');
      }
      if (text.includes('Allah') && !text.includes('Glorified and Exalted')) {
        enhancedText = enhancedText.replace(/Allah/gi, 'Allah (Glorified and Exalted)');
      }
    }
    
    return enhancedText;
  }
  
  // Simulate image text extraction for development purposes
  private simulateImageTextExtraction(imageData: string, language: string): string {
    // This is only for demonstration purposes
    // In a real app, this would be replaced with actual API calls
    
    if (language === 'ar') {
      return "نص تم استخراجه من الصورة باللغة العربية. يحتوي على كلمات مثل الله ومحمد والقرآن.";
    } else if (language === 'en') {
      return "Text extracted from the image in English. Contains words like Allah, Muhammad and Quran.";
    }
    
    return `This is simulated text extraction from an image for language code: ${language}`;
  }
}

export const visionService = new VisionService();
