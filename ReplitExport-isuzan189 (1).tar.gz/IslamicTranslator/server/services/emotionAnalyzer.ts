import { openaiService } from "./openai";
import { filterService } from "./filter";
import { islamicContentDetector } from "./islamicContentDetector";

// Advanced emotion and cultural sentiment analysis service
export class EmotionAnalyzerService {
  // Cultural context mapping
  private culturalContexts = {
    'middle_eastern': ['ar', 'fa', 'ur', 'he'],
    'south_asian': ['hi', 'bn', 'ta', 'ur'],
    'east_asian': ['zh', 'ja', 'ko'],
    'african': ['sw', 'ha', 'am'],
    'western': ['en', 'fr', 'de', 'es', 'it'],
    'eastern_european': ['ru', 'uk', 'pl']
  };

  // Emotion categories with cultural context awareness
  private emotionCategories = {
    'respect': {
      'ar': ['احترام', 'تقدير', 'إجلال', 'توقير', 'تبجيل'],
      'en': ['respect', 'reverence', 'esteem', 'honor', 'deference']
    },
    'joy': {
      'ar': ['سعادة', 'فرح', 'بهجة', 'سرور', 'مرح'],
      'en': ['joy', 'happiness', 'delight', 'pleasure', 'gladness']
    },
    'sadness': {
      'ar': ['حزن', 'أسى', 'كآبة', 'غم', 'اكتئاب'],
      'en': ['sadness', 'sorrow', 'grief', 'woe', 'melancholy']
    },
    'anger': {
      'ar': ['غضب', 'سخط', 'حنق', 'استياء', 'حدة'],
      'en': ['anger', 'rage', 'fury', 'wrath', 'indignation']
    },
    'fear': {
      'ar': ['خوف', 'رعب', 'فزع', 'هلع', 'ذعر'],
      'en': ['fear', 'terror', 'dread', 'horror', 'fright']
    },
    'gratitude': {
      'ar': ['شكر', 'امتنان', 'عرفان', 'تقدير'],
      'en': ['gratitude', 'thankfulness', 'appreciation', 'gratefulness']
    },
    'disgust': {
      'ar': ['اشمئزاز', 'قرف', 'نفور', 'استقذار'],
      'en': ['disgust', 'revulsion', 'abhorrence', 'aversion']
    },
    'humility': {
      'ar': ['تواضع', 'خشوع', 'وداعة', 'استكانة'],
      'en': ['humility', 'modesty', 'meekness', 'submissiveness']
    },
    'patience': {
      'ar': ['صبر', 'تحمل', 'جلد', 'مصابرة'],
      'en': ['patience', 'endurance', 'forbearance', 'perseverance']
    },
    'admiration': {
      'ar': ['إعجاب', 'تقدير', 'استحسان', 'إكبار'],
      'en': ['admiration', 'esteem', 'regard', 'respect']
    }
  };

  // Islamic emotion contexts (more nuanced categorization for religious text)
  private islamicEmotionContexts = {
    'devotion': {
      'ar': ['خشوع', 'تقوى', 'عبادة', 'إخلاص', 'إيمان'],
      'en': ['devotion', 'piety', 'worship', 'sincerity', 'faith']
    },
    'repentance': {
      'ar': ['توبة', 'استغفار', 'ندم', 'أوبة', 'إنابة'],
      'en': ['repentance', 'seeking forgiveness', 'remorse', 'contrition', 'atonement']
    },
    'gratitude_to_allah': {
      'ar': ['شكر لله', 'حمد لله', 'امتنان لله', 'عرفان لنعم الله'],
      'en': ['gratitude to Allah', 'praising Allah', 'thankfulness to Allah']
    },
    'fear_of_allah': {
      'ar': ['خشية الله', 'تقوى الله', 'خوف من الله', 'مراقبة الله'],
      'en': ['fear of Allah', 'God-consciousness', 'divine awareness', 'mindfulness of Allah']
    },
    'hope_in_allah': {
      'ar': ['رجاء الله', 'أمل في رحمة الله', 'رغبة في فضل الله'],
      'en': ['hope in Allah', 'longing for Allah\'s mercy', 'desire for Allah\'s grace']
    },
    'love_for_allah': {
      'ar': ['حب الله', 'محبة الله', 'ود لله', 'شوق إلى الله'],
      'en': ['love for Allah', 'adoration of Allah', 'yearning for Allah']
    }
  };

  // Cultural expressions with emotional significance
  private culturalExpressions = {
    'ar': {
      'الحمد لله': { emotion: 'gratitude', intensity: 0.8 },
      'ما شاء الله': { emotion: 'admiration', intensity: 0.7 },
      'استغفر الله': { emotion: 'repentance', intensity: 0.9 },
      'بارك الله فيك': { emotion: 'gratitude', intensity: 0.6 },
      'جزاك الله خيرا': { emotion: 'gratitude', intensity: 0.8 },
      'سبحان الله': { emotion: 'admiration', intensity: 0.7 },
      'أعوذ بالله': { emotion: 'fear_of_allah', intensity: 0.8 },
      'إن شاء الله': { emotion: 'hope_in_allah', intensity: 0.5 }
    },
    'en': {
      'Alhamdulillah': { emotion: 'gratitude', intensity: 0.8 },
      'Mashallah': { emotion: 'admiration', intensity: 0.7 },
      'Astaghfirullah': { emotion: 'repentance', intensity: 0.9 },
      'Barakallahu feek': { emotion: 'gratitude', intensity: 0.6 },
      'Jazak Allahu Khayran': { emotion: 'gratitude', intensity: 0.8 },
      'Subhanallah': { emotion: 'admiration', intensity: 0.7 },
      'Audhu billah': { emotion: 'fear_of_allah', intensity: 0.8 },
      'Insha Allah': { emotion: 'hope_in_allah', intensity: 0.5 }
    }
  };

  // Detect cultural context from language code
  private detectCulturalContext(language: string): string {
    for (const [context, languages] of Object.entries(this.culturalContexts)) {
      if (languages.includes(language)) {
        return context;
      }
    }
    return 'general'; // Default cultural context
  }

  // Analyze text for emotional content with cultural context
  async analyzeEmotions(
    text: string, 
    language: string,
    options: {
      includeIntensity?: boolean;
      includeExpressions?: boolean;
      includeIslamicContext?: boolean;
      detailedAnalysis?: boolean;
    } = {}
  ): Promise<{
    dominantEmotion: string;
    emotionScores: {[key: string]: number};
    culturalContext: string;
    intensity?: number;
    culturalExpressions?: {expression: string, emotion: string, intensity: number}[];
    religiousContext?: boolean;
    islamicEmotions?: {[key: string]: number};
    sentimentPolarity: number; // -1 (negative) to +1 (positive)
    confidenceScore: number;
  }> {
    try {
      // Check if text contains Islamic content
      const islamicCheck = await islamicContentDetector.detectIslamicContent(text, language);
      const isIslamic = islamicCheck.isIslamic;
      
      // Detect cultural context
      const culturalContext = this.detectCulturalContext(language);
      
      // Analyze using basic pattern matching (for demonstration)
      const basicAnalysis = this.basicEmotionAnalysis(text, language);
      
      // Map to translate basic emotions to our categories
      const emotionScores: {[key: string]: number} = {};
      for (const emotion of Object.keys(this.emotionCategories)) {
        emotionScores[emotion] = 0;
      }
      
      // If Islamic content is detected and the option is enabled, analyze Islamic emotions
      let islamicEmotions: {[key: string]: number} | undefined;
      if (isIslamic && options.includeIslamicContext) {
        islamicEmotions = {};
        for (const emotion of Object.keys(this.islamicEmotionContexts)) {
          islamicEmotions[emotion] = 0;
        }
        
        // Simple pattern matching for Islamic emotions
        for (const [emotion, terms] of Object.entries(this.islamicEmotionContexts)) {
          const langTerms = terms[language as keyof typeof terms] || terms['en'];
          for (const term of langTerms as string[]) {
            if (text.toLowerCase().includes(term.toLowerCase())) {
              if (islamicEmotions[emotion] === undefined) islamicEmotions[emotion] = 0;
              islamicEmotions[emotion] += 0.2; // Increment score for each match
            }
          }
        }
      }
      
      // Check for cultural expressions
      const culturalExpressionsFound: {expression: string, emotion: string, intensity: number}[] = [];
      if (options.includeExpressions) {
        const expressionsDict = this.culturalExpressions[language as keyof typeof this.culturalExpressions] 
                             || this.culturalExpressions['en'];
        
        for (const [expression, details] of Object.entries(expressionsDict)) {
          if (text.includes(expression)) {
            culturalExpressionsFound.push({
              expression,
              emotion: details.emotion,
              intensity: details.intensity
            });
            
            // Add to emotion scores
            if (emotionScores[details.emotion] !== undefined) {
              emotionScores[details.emotion] += details.intensity * 0.5;
            }
          }
        }
      }
      
      // Use OpenAI for sophisticated analysis
      const aiAnalysis = await this.aiEmotionAnalysis(text, language, isIslamic);
      
      // Combine basic analysis with AI analysis
      for (const [emotion, score] of Object.entries(aiAnalysis.emotions)) {
        if (emotionScores[emotion] !== undefined) {
          emotionScores[emotion] = (emotionScores[emotion] + score) / 2; // Average the scores
        } else {
          emotionScores[emotion] = score;
        }
      }
      
      // Determine dominant emotion
      let dominantEmotion = 'neutral';
      let maxScore = 0;
      for (const [emotion, score] of Object.entries(emotionScores)) {
        if (score > maxScore) {
          maxScore = score;
          dominantEmotion = emotion;
        }
      }
      
      // Calculate overall intensity if requested
      let overallIntensity = undefined;
      if (options.includeIntensity) {
        let sum = 0;
        let count = 0;
        for (const score of Object.values(emotionScores)) {
          sum += score;
          count++;
        }
        overallIntensity = count > 0 ? sum / count : 0;
      }
      
      // Build the result
      const result: {
        dominantEmotion: string;
        emotionScores: {[key: string]: number};
        culturalContext: string;
        intensity?: number;
        culturalExpressions?: {expression: string, emotion: string, intensity: number}[];
        religiousContext?: boolean;
        islamicEmotions?: {[key: string]: number};
        sentimentPolarity: number;
        confidenceScore: number;
      } = {
        dominantEmotion,
        emotionScores,
        culturalContext,
        sentimentPolarity: aiAnalysis.sentimentPolarity,
        confidenceScore: aiAnalysis.confidence
      };
      
      // Add optional fields if requested
      if (options.includeIntensity) {
        result.intensity = overallIntensity;
      }
      
      if (options.includeExpressions && culturalExpressionsFound.length > 0) {
        result.culturalExpressions = culturalExpressionsFound;
      }
      
      if (options.includeIslamicContext && isIslamic) {
        result.religiousContext = true;
        result.islamicEmotions = islamicEmotions;
      }
      
      return result;
    } catch (error) {
      console.error("Error analyzing emotions:", error);
      // Return a basic response if analysis fails
      return {
        dominantEmotion: 'neutral',
        emotionScores: { 'neutral': 1.0 },
        culturalContext: this.detectCulturalContext(language),
        sentimentPolarity: 0,
        confidenceScore: 0.1
      };
    }
  }

  // Simple basic emotion analysis with pattern matching
  private basicEmotionAnalysis(text: string, language: string): {[key: string]: number} {
    const scores: {[key: string]: number} = {};
    
    // Check for emotion keywords in the text
    for (const [emotion, terms] of Object.entries(this.emotionCategories)) {
      const langTerms = terms[language as keyof typeof terms] || terms['en'];
      scores[emotion] = 0;
      
      for (const term of langTerms as string[]) {
        if (text.toLowerCase().includes(term.toLowerCase())) {
          scores[emotion] += 0.2; // Increment score for each match
        }
      }
    }
    
    return scores;
  }

  // Use AI for more nuanced emotion analysis
  private async aiEmotionAnalysis(
    text: string, 
    language: string,
    isIslamic: boolean
  ): Promise<{
    emotions: {[key: string]: number};
    sentimentPolarity: number;
    confidence: number;
  }> {
    try {
      // Construct an appropriate prompt for the AI
      let systemPrompt = `You are an expert in cultural emotional analysis with deep knowledge of ${language}-speaking cultures. 
Analyze the following text and provide:
1. Emotions identified (anger, joy, sadness, fear, disgust, surprise, admiration, gratitude, hope, anxiety)
2. Score for each emotion (0.0 to 1.0)
3. Overall sentiment polarity (-1.0 to +1.0)
4. Confidence score (0.0 to 1.0)

Return the analysis in JSON format only.`;

      // If Islamic content is detected, add specialized guidance
      if (isIslamic) {
        systemPrompt += `\n\nThis text contains Islamic content. Additionally analyze for:
5. Religious emotional contexts (devotion, gratitude to Allah, repentance, hope in Allah, fear of Allah)
6. Respect for Islamic values and principles
7. Reverence toward religious figures`;
      }

      // Use OpenAI for the analysis
      // In a real implementation, this would have proper error handling and
      // output validation to ensure we get JSON back
      const result = await openaiService.analyzeCulturalContext(text, language);
      
      // In a real implementation, we would parse the response and extract the emotion data
      // For demonstration purposes, we'll create a simulated response
      const emotions: {[key: string]: number} = {
        "joy": 0.2,
        "sadness": 0.1,
        "anger": 0.05,
        "fear": 0.05,
        "surprise": 0.1,
        "disgust": 0.0,
        "admiration": 0.3,
        "gratitude": 0.3,
        "hope": 0.2,
        "anxiety": 0.1
      };
      
      // Adjust emotions based on whether it's Islamic content
      if (isIslamic) {
        emotions["respect"] = 0.7;
        emotions["devotion"] = 0.6;
        emotions["gratitude"] = 0.5;
      }
      
      // Derive sentiment polarity from emotions
      // Positive emotions contribute positively, negative ones negatively
      const positiveEmotions = ["joy", "admiration", "gratitude", "hope"];
      const negativeEmotions = ["sadness", "anger", "fear", "disgust", "anxiety"];
      
      let positiveScore = 0;
      let negativeScore = 0;
      
      for (const emotion of positiveEmotions) {
        if (emotions[emotion]) positiveScore += emotions[emotion];
      }
      
      for (const emotion of negativeEmotions) {
        if (emotions[emotion]) negativeScore += emotions[emotion];
      }
      
      const sentimentPolarity = Math.min(1, Math.max(-1, positiveScore - negativeScore));
      
      return {
        emotions,
        sentimentPolarity,
        confidence: 0.8
      };
    } catch (error) {
      console.error("AI emotion analysis error:", error);
      // Return a basic analysis if AI fails
      return {
        emotions: {
          "neutral": 1.0
        },
        sentimentPolarity: 0,
        confidence: 0.1
      };
    }
  }
}

export const emotionAnalyzerService = new EmotionAnalyzerService();