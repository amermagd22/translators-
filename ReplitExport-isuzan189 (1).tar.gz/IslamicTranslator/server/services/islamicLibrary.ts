/**
 * Islamic Library Service
 * Provides books, audio reading, and video translation capabilities
 * with focus on Islamic content preservation and respect
 */

import Anthropic from '@anthropic-ai/sdk';
import OpenAI from 'openai';
import { islamicContentDetector } from './islamicContentDetector';
import { contentCheckerService } from './contentChecker';
import { filterService } from './filter';

interface Book {
  id: string;
  title: string;
  author: string;
  language: string;
  category: string;
  coverImage: string;
  description: string;
  pages: number;
  audioAvailable: boolean;
  pdfUrl: string;
  audioUrl?: string;
}

interface VideoTranslation {
  id: string;
  title: string;
  originalLanguage: string;
  translations: {
    language: string;
    status: 'completed' | 'in_progress' | 'failed';
    audioUrl?: string;
    subtitlesUrl?: string;
  }[];
  thumbnailUrl: string;
  duration: number;
  uploadDate: string;
  videoUrl: string;
}

interface BookSearchFilters {
  language?: string;
  category?: string;
  query?: string;
}

interface VideoSearchFilters {
  language?: string; 
  query?: string;
  translationAvailable?: string;
}

export class IslamicLibraryService {
  private books: Book[] = [];
  private videos: VideoTranslation[] = [];
  private anthropic: Anthropic | null = null;
  private openai: OpenAI | null = null;
  
  constructor() {
    // Initialize API clients if keys are available
    if (process.env.ANTHROPIC_API_KEY) {
      this.anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    }
    
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    }
    
    // Initialize example data
    this.initializeBooks();
    this.initializeVideos();
  }
  
  private initializeBooks() {
    this.books = [
      {
        id: '1',
        title: 'فقه السنة',
        author: 'السيد سابق',
        language: 'ar',
        category: 'fiqh',
        coverImage: 'https://i.imgur.com/1234.jpg',
        description: 'كتاب شامل في الفقه الإسلامي يشرح الأحكام الشرعية بأسلوب ميسر',
        pages: 542,
        audioAvailable: true,
        pdfUrl: '/books/fiqh-sunnah.pdf',
        audioUrl: '/audio/fiqh-sunnah.mp3'
      },
      {
        id: '2',
        title: 'The Sealed Nectar',
        author: 'Safiur Rahman Mubarakpuri',
        language: 'en',
        category: 'seerah',
        coverImage: 'https://i.imgur.com/5678.jpg',
        description: 'Biography of Prophet Muhammad, awarded first prize in worldwide competition',
        pages: 472,
        audioAvailable: true,
        pdfUrl: '/books/sealed-nectar.pdf',
        audioUrl: '/audio/sealed-nectar.mp3'
      },
      {
        id: '3',
        title: 'العقيدة الإسلامية وأسسها',
        author: 'عبد الرحمن حسن حبنكة الميداني',
        language: 'ar',
        category: 'aqidah',
        coverImage: 'https://i.imgur.com/9101.jpg',
        description: 'شرح مفصل للعقيدة الإسلامية ومبادئها وأسسها',
        pages: 356,
        audioAvailable: false,
        pdfUrl: '/books/islamic-aqeedah.pdf'
      },
      {
        id: '4',
        title: "L'islam et la Science",
        author: 'Maurice Bucaille',
        language: 'fr',
        category: 'science',
        coverImage: 'https://i.imgur.com/1112.jpg',
        description: 'Étude sur la relation entre les découvertes scientifiques modernes et les textes islamiques',
        pages: 304,
        audioAvailable: true,
        pdfUrl: '/books/islam-science.pdf',
        audioUrl: '/audio/islam-science.mp3'
      },
      {
        id: '5',
        title: 'مختصر تفسير ابن كثير',
        author: 'محمد علي الصابوني',
        language: 'ar',
        category: 'quran',
        coverImage: 'https://i.imgur.com/1314.jpg',
        description: 'اختصار لتفسير ابن كثير المشهور مع الحفاظ على جوهر التفسير',
        pages: 830,
        audioAvailable: true,
        pdfUrl: '/books/mukhtasar-ibn-kathir.pdf',
        audioUrl: '/audio/mukhtasar-ibn-kathir.mp3'
      }
    ];
  }
  
  private initializeVideos() {
    this.videos = [
      {
        id: '1',
        title: 'الإعجاز العلمي في القرآن الكريم',
        originalLanguage: 'ar',
        translations: [
          { language: 'en', status: 'completed', audioUrl: '/audio/video1-en.mp3', subtitlesUrl: '/subs/video1-en.vtt' },
          { language: 'fr', status: 'completed', audioUrl: '/audio/video1-fr.mp3', subtitlesUrl: '/subs/video1-fr.vtt' },
          { language: 'es', status: 'in_progress' }
        ],
        thumbnailUrl: 'https://i.imgur.com/video1.jpg',
        duration: 1845, // 30:45 en segundos
        uploadDate: '2023-11-15',
        videoUrl: '/videos/scientific-miracles.mp4'
      },
      {
        id: '2',
        title: 'Why I Became Muslim',
        originalLanguage: 'en',
        translations: [
          { language: 'ar', status: 'completed', audioUrl: '/audio/video2-ar.mp3', subtitlesUrl: '/subs/video2-ar.vtt' },
          { language: 'fr', status: 'completed', audioUrl: '/audio/video2-fr.mp3', subtitlesUrl: '/subs/video2-fr.vtt' },
          { language: 'de', status: 'completed', audioUrl: '/audio/video2-de.mp3', subtitlesUrl: '/subs/video2-de.vtt' }
        ],
        thumbnailUrl: 'https://i.imgur.com/video2.jpg',
        duration: 1256, // 20:56 en segundos
        uploadDate: '2023-10-22',
        videoUrl: '/videos/why-i-became-muslim.mp4'
      },
      {
        id: '3',
        title: 'مناظرة حول وجود الله',
        originalLanguage: 'ar',
        translations: [
          { language: 'en', status: 'completed', audioUrl: '/audio/video3-en.mp3', subtitlesUrl: '/subs/video3-en.vtt' },
          { language: 'ru', status: 'failed' }
        ],
        thumbnailUrl: 'https://i.imgur.com/video3.jpg',
        duration: 3624, // 1:00:24 en segundos
        uploadDate: '2023-09-10',
        videoUrl: '/videos/debate-existence-of-god.mp4'
      }
    ];
  }
  
  /**
   * Get all books, optionally filtered
   */
  getBooks(filters?: BookSearchFilters): Book[] {
    let filteredBooks = [...this.books];
    
    if (!filters) {
      return filteredBooks;
    }
    
    // Filter by language
    if (filters.language && filters.language !== 'all') {
      filteredBooks = filteredBooks.filter(book => book.language === filters.language);
    }
    
    // Filter by category
    if (filters.category && filters.category !== 'all') {
      filteredBooks = filteredBooks.filter(book => book.category === filters.category);
    }
    
    // Filter by search query
    if (filters.query) {
      const query = filters.query.toLowerCase();
      filteredBooks = filteredBooks.filter(book => 
        book.title.toLowerCase().includes(query) ||
        book.author.toLowerCase().includes(query) ||
        book.description.toLowerCase().includes(query)
      );
    }
    
    return filteredBooks;
  }
  
  /**
   * Get book by ID
   */
  getBookById(id: string): Book | undefined {
    return this.books.find(book => book.id === id);
  }
  
  /**
   * Add a new book
   */
  async addBook(bookData: Omit<Book, 'id' | 'audioAvailable'>): Promise<Book> {
    // Check for prohibited content
    if (await filterService.containsProhibitedContent(bookData.description, bookData.language)) {
      throw new Error('الكتاب يحتوي على محتوى غير مناسب');
    }
    
    // Verify Islamic content respectfulness
    const verificationResult = await contentCheckerService.verifyIslamicContent(
      bookData.description,
      bookData.language,
      'book',
      true
    );
    
    if (verificationResult.issues.length > 0 && verificationResult.score < 0.7) {
      throw new Error('المحتوى لا يتوافق مع معايير الاحترام للإسلام');
    }
    
    // Generate new book ID
    const id = Date.now().toString();
    
    // Create new book object
    const newBook: Book = {
      ...bookData,
      id,
      audioAvailable: false,
      coverImage: bookData.coverImage || `https://i.imgur.com/book${id}.jpg`
    };
    
    // Add to collection
    this.books.push(newBook);
    
    return newBook;
  }
  
  /**
   * Generate audio for a book
   */
  async generateBookAudio(bookId: string): Promise<{ success: boolean, audioUrl?: string }> {
    const book = this.getBookById(bookId);
    
    if (!book) {
      throw new Error('الكتاب غير موجود');
    }
    
    // In a real implementation, this would connect to a text-to-speech API
    // Here we simulate the generation
    
    const audioUrl = `/audio/book-${bookId}-audio.mp3`;
    
    // Update book with audio availability
    const bookIndex = this.books.findIndex(b => b.id === bookId);
    if (bookIndex !== -1) {
      this.books[bookIndex] = {
        ...book,
        audioAvailable: true,
        audioUrl
      };
    }
    
    return {
      success: true,
      audioUrl
    };
  }
  
  /**
   * Get all videos, optionally filtered
   */
  getVideos(filters?: VideoSearchFilters): VideoTranslation[] {
    let filteredVideos = [...this.videos];
    
    if (!filters) {
      return filteredVideos;
    }
    
    // Filter by language (original or translation)
    if (filters.language && filters.language !== 'all') {
      filteredVideos = filteredVideos.filter(video => 
        video.originalLanguage === filters.language || 
        video.translations.some(t => t.language === filters.language)
      );
    }
    
    // Filter by search query
    if (filters.query) {
      const query = filters.query.toLowerCase();
      filteredVideos = filteredVideos.filter(video => 
        video.title.toLowerCase().includes(query)
      );
    }
    
    // Filter by translation availability
    if (filters.translationAvailable) {
      filteredVideos = filteredVideos.filter(video => 
        video.translations.some(t => 
          t.language === filters.translationAvailable && 
          t.status === 'completed'
        )
      );
    }
    
    return filteredVideos;
  }
  
  /**
   * Get video by ID
   */
  getVideoById(id: string): VideoTranslation | undefined {
    return this.videos.find(video => video.id === id);
  }
  
  /**
   * Add a new video
   */
  async addVideo(videoData: Omit<VideoTranslation, 'id' | 'translations' | 'duration'>): Promise<VideoTranslation> {
    // Check for prohibited content
    if (await filterService.containsProhibitedContent(videoData.title, videoData.originalLanguage)) {
      throw new Error('الفيديو يحتوي على عنوان غير مناسب');
    }
    
    // Generate new video ID
    const id = Date.now().toString();
    
    // Create new video object with default values
    const newVideo: VideoTranslation = {
      ...videoData,
      id,
      translations: [],
      duration: 0, // This would be detected from the actual video file
      thumbnailUrl: videoData.thumbnailUrl || `https://i.imgur.com/video${id}.jpg`
    };
    
    // Add to collection
    this.videos.push(newVideo);
    
    return newVideo;
  }
  
  /**
   * Generate translation for a video
   */
  async generateVideoTranslation(
    videoId: string, 
    targetLanguage: string
  ): Promise<{ success: boolean, translation?: VideoTranslation['translations'][0] }> {
    const video = this.getVideoById(videoId);
    
    if (!video) {
      throw new Error('الفيديو غير موجود');
    }
    
    // Check if translation already exists
    if (video.translations.some(t => t.language === targetLanguage && t.status === 'completed')) {
      throw new Error('الترجمة موجودة بالفعل');
    }
    
    // In a real implementation, this would connect to a translation and TTS API
    // Here we simulate the generation
    
    const translation: VideoTranslation['translations'][0] = {
      language: targetLanguage,
      status: 'completed',
      audioUrl: `/audio/video-${videoId}-${targetLanguage}.mp3`,
      subtitlesUrl: `/subs/video-${videoId}-${targetLanguage}.vtt`
    };
    
    // Update video with new translation
    const videoIndex = this.videos.findIndex(v => v.id === videoId);
    if (videoIndex !== -1) {
      const updatedTranslations = [...video.translations];
      
      // Remove any in-progress or failed translations for this language
      const existingIndex = updatedTranslations.findIndex(t => t.language === targetLanguage);
      if (existingIndex !== -1) {
        updatedTranslations[existingIndex] = translation;
      } else {
        updatedTranslations.push(translation);
      }
      
      this.videos[videoIndex] = {
        ...video,
        translations: updatedTranslations
      };
    }
    
    return {
      success: true,
      translation
    };
  }
  
  /**
   * Extract text from an image of a book page (OCR)
   */
  async extractTextFromImage(imageData: string, language: string): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }
    
    try {
      // In a real implementation, this would use OpenAI's vision model or another OCR service
      // to extract text from the image
      
      // Here we simulate the response
      const detectedText = 'هذا نص تم استخراجه من صورة صفحة كتاب. في التطبيق الحقيقي، سيتم استخدام تقنية التعرف الضوئي على الحروف (OCR) لاستخراج النص بدقة.';
      
      // Verify the content is appropriate
      const isProhibited = await filterService.containsProhibitedContent(detectedText, language);
      if (isProhibited) {
        throw new Error('تم اكتشاف محتوى غير لائق في النص المستخرج');
      }
      
      return detectedText;
    } catch (error) {
      console.error('Error in text extraction:', error);
      throw new Error('فشل في استخراج النص من الصورة');
    }
  }
  
  /**
   * Search for books by taking a photo of the cover (simulation)
   */
  async searchBookByImage(imageData: string): Promise<Book[]> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }
    
    try {
      // In a real implementation, this would use OpenAI's vision model or another image recognition service
      // to analyze the cover and identify the book
      
      // Here we simulate the response by returning a random selection of books
      const randomBooks = this.books
        .sort(() => 0.5 - Math.random())
        .slice(0, 2);
      
      return randomBooks;
    } catch (error) {
      console.error('Error in book image search:', error);
      throw new Error('فشل في البحث عن الكتاب باستخدام الصورة');
    }
  }
  
  /**
   * Get categories map
   */
  getBookCategories(): { id: string, name: string }[] {
    return [
      { id: 'quran', name: 'القرآن الكريم وعلومه' },
      { id: 'hadith', name: 'الحديث وعلومه' },
      { id: 'fiqh', name: 'الفقه الإسلامي' },
      { id: 'aqidah', name: 'العقيدة' },
      { id: 'seerah', name: 'السيرة النبوية' },
      { id: 'history', name: 'التاريخ الإسلامي' },
      { id: 'dawah', name: 'كتب الدعوة' },
      { id: 'comparative', name: 'مقارنة الأديان' },
      { id: 'science', name: 'الإعجاز العلمي' }
    ];
  }
  
  /**
   * Get languages map
   */
  getLanguages(): { id: string, name: string }[] {
    return [
      { id: 'ar', name: 'العربية' },
      { id: 'en', name: 'الإنجليزية' },
      { id: 'fr', name: 'الفرنسية' },
      { id: 'es', name: 'الإسبانية' },
      { id: 'de', name: 'الألمانية' },
      { id: 'ru', name: 'الروسية' },
      { id: 'zh', name: 'الصينية' },
      { id: 'ur', name: 'الأردية' },
      { id: 'tr', name: 'التركية' },
      { id: 'ms', name: 'الملايو' }
    ];
  }
}

export const islamicLibraryService = new IslamicLibraryService();