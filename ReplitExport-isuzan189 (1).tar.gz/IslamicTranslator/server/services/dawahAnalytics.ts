import { islamicDawahService } from './islamicDawah';

/**
 * Service for analyzing dawah efforts, tracking conversions,
 * and generating insights on Islamic outreach effectiveness
 */
export class DawahAnalyticsService {
  // Track detailed statistics by region and demographic
  private regionalStats: Record<string, {
    interactions: number;
    questions_answered: number;
    materials_shared: number;
    potential_converts: number;
    conversions: number;
    active_channels: Record<string, number>;
    top_topics: Record<string, number>;
    timeline: Array<{
      date: string;
      interactions: number;
      questions_answered: number;
      materials_shared: number;
      potential_converts: number;
      conversions: number;
    }>;
  }> = {};
  
  // Track topic effectiveness
  private topicEffectiveness: Record<string, {
    total_uses: number;
    questions_generated: number;
    positive_responses: number;
    conversions_influenced: number;
    average_engagement_time: number;
  }> = {};
  
  // Demographics tracking
  private demographicInsights: Record<string, {
    count: number;
    age_groups?: Record<string, number>;
    educational_background?: Record<string, number>;
    prior_faith?: Record<string, number>;
    conversion_rate: number;
    average_journey_length: number; // in days
  }> = {};
  
  // Contact journey stages distribution
  private conversionFunnelStats = {
    initial_contact: 0,
    interested: 0,
    learning: 0,
    convinced: 0,
    converted: 0,
    inactive: 0
  };
  
  constructor() {
    // Initialize common regions and demographics
    this.initializeAnalytics();
    
    // Set interval to update stats periodically
    setInterval(() => {
      this.updateStats();
    }, 1000 * 60 * 60); // Update hourly
  }
  
  /**
   * Initialize analytics data structures
   */
  private initializeAnalytics(): void {
    // Initialize common regions
    const commonRegions = [
      'north_america', 'europe', 'middle_east', 'africa', 
      'asia', 'australia', 'south_america', 'online'
    ];
    
    for (const region of commonRegions) {
      this.regionalStats[region] = {
        interactions: 0,
        questions_answered: 0,
        materials_shared: 0,
        potential_converts: 0,
        conversions: 0,
        active_channels: {},
        top_topics: {},
        timeline: []
      };
    }
    
    // Initialize common dawah topics
    const commonTopics = [
      'tawhid', 'quran_authenticity', 'scientific_miracles', 
      'prophethood', 'islamic_ethics', 'comparative_religion',
      'islamic_history', 'prayer_and_worship', 'life_purpose',
      'afterlife', 'islamic_community', 'misconceptions',
      'womens_rights', 'social_justice'
    ];
    
    for (const topic of commonTopics) {
      this.topicEffectiveness[topic] = {
        total_uses: 0,
        questions_generated: 0,
        positive_responses: 0,
        conversions_influenced: 0,
        average_engagement_time: 0
      };
    }
    
    // Initialize common demographics
    const commonDemographics = [
      'students', 'professionals', 'religious_seekers', 
      'former_christians', 'former_atheists', 'former_hindus',
      'former_buddhists', 'former_jews', 'born_muslims'
    ];
    
    for (const demographic of commonDemographics) {
      this.demographicInsights[demographic] = {
        count: 0,
        conversion_rate: 0,
        average_journey_length: 0
      };
    }
  }
  
  /**
   * Update statistics from data sources
   */
  private async updateStats(): Promise<void> {
    try {
      // Get current dawah stats
      const dawahStats = islamicDawahService.getDawahStats();
      
      // Get all contacts
      const allContacts = islamicDawahService.getContacts();
      
      // Update conversion funnel
      this.updateConversionFunnel(allContacts);
      
      // Update regional stats (simplified demo version)
      // In a real implementation, this would use actual regional data
      this.updateRegionalStats(dawahStats, allContacts);
      
      // Update topic effectiveness based on interactions
      this.updateTopicEffectiveness(allContacts);
      
      // Update demographic insights
      this.updateDemographicInsights(allContacts);
      
      console.log('Dawah analytics updated successfully');
    } catch (error) {
      console.error('Error updating dawah analytics:', error);
    }
  }
  
  /**
   * Update conversion funnel statistics
   */
  private updateConversionFunnel(contacts: any[]): void {
    // Reset counters
    this.conversionFunnelStats = {
      initial_contact: 0,
      interested: 0,
      learning: 0,
      convinced: 0,
      converted: 0,
      inactive: 0
    };
    
    // Count contacts in each stage
    for (const contact of contacts) {
      if (contact.status in this.conversionFunnelStats) {
        this.conversionFunnelStats[contact.status as keyof typeof this.conversionFunnelStats]++;
      }
    }
  }
  
  /**
   * Update regional statistics
   */
  private updateRegionalStats(dawahStats: any, contacts: any[]): void {
    // For demo purposes, distribute stats across regions
    // In a real implementation, would use actual regional data from contacts
    
    const totalInteractions = dawahStats.interactions || 0;
    const totalQuestionsAnswered = dawahStats.questions_answered || 0;
    const totalMaterialsShared = dawahStats.materials_shared || 0;
    const totalPotentialConverts = dawahStats.potential_converts || 0;
    const totalConversions = dawahStats.conversions || 0;
    
    const regions = Object.keys(this.regionalStats);
    
    // Simple distribution algorithm for demo
    for (let i = 0; i < regions.length; i++) {
      const region = regions[i];
      const regionWeight = (i + 1) / (regions.length * (regions.length + 1) / 2);
      
      this.regionalStats[region].interactions = Math.floor(totalInteractions * regionWeight);
      this.regionalStats[region].questions_answered = Math.floor(totalQuestionsAnswered * regionWeight);
      this.regionalStats[region].materials_shared = Math.floor(totalMaterialsShared * regionWeight);
      this.regionalStats[region].potential_converts = Math.floor(totalPotentialConverts * regionWeight);
      this.regionalStats[region].conversions = Math.floor(totalConversions * regionWeight);
      
      // Add timeline entry
      const today = new Date().toISOString().split('T')[0];
      
      // Update or add today's entry
      const existingEntryIndex = this.regionalStats[region].timeline.findIndex(
        entry => entry.date === today
      );
      
      if (existingEntryIndex >= 0) {
        this.regionalStats[region].timeline[existingEntryIndex] = {
          date: today,
          interactions: this.regionalStats[region].interactions,
          questions_answered: this.regionalStats[region].questions_answered,
          materials_shared: this.regionalStats[region].materials_shared,
          potential_converts: this.regionalStats[region].potential_converts,
          conversions: this.regionalStats[region].conversions
        };
      } else {
        this.regionalStats[region].timeline.push({
          date: today,
          interactions: this.regionalStats[region].interactions,
          questions_answered: this.regionalStats[region].questions_answered,
          materials_shared: this.regionalStats[region].materials_shared,
          potential_converts: this.regionalStats[region].potential_converts,
          conversions: this.regionalStats[region].conversions
        });
      }
      
      // Keep timeline to last 90 days
      if (this.regionalStats[region].timeline.length > 90) {
        this.regionalStats[region].timeline = this.regionalStats[region].timeline.slice(-90);
      }
    }
    
    // Process top topics from dawah stats
    if (dawahStats.top_questions) {
      // For each region, distribute top topics
      for (const region of regions) {
        this.regionalStats[region].top_topics = {};
        
        // Create a partial copy of the topics for each region
        const topicEntries = Object.entries(dawahStats.top_questions);
        const topicsCount = topicEntries.length;
        
        // Each region gets a random subset of topics
        const regionTopicsCount = Math.max(2, Math.floor(topicsCount * (0.3 + Math.random() * 0.7)));
        
        // Shuffle and select topics
        const shuffledTopics = [...topicEntries].sort(() => Math.random() - 0.5);
        
        for (let i = 0; i < Math.min(regionTopicsCount, topicsCount); i++) {
          const [topic, count] = shuffledTopics[i];
          const regionFactor = 0.2 + Math.random() * 0.8; // Random factor between 0.2 and 1.0
          
          this.regionalStats[region].top_topics[topic] = Math.floor(Number(count) * regionFactor);
        }
      }
    }
  }
  
  /**
   * Update topic effectiveness statistics
   */
  private updateTopicEffectiveness(contacts: any[]): void {
    // Process contacts to update topic effectiveness
    // In a real implementation, would analyze interactions to determine topic effectiveness
    
    // Reset counters for topics
    for (const topic in this.topicEffectiveness) {
      this.topicEffectiveness[topic] = {
        total_uses: 0,
        questions_generated: 0,
        positive_responses: 0,
        conversions_influenced: 0,
        average_engagement_time: 0
      };
    }
    
    // Analyze all contact interactions
    for (const contact of contacts) {
      // Skip contacts without interactions
      if (!contact.interactions || !Array.isArray(contact.interactions)) continue;
      
      // Track topics mentioned in interactions
      const mentionedTopics = new Set<string>();
      let totalEngagementTime = 0;
      let firstInteractionTime: number | null = null;
      let lastInteractionTime: number | null = null;
      
      // Process each interaction
      for (const interaction of contact.interactions) {
        // Try to identify topics
        for (const topic in this.topicEffectiveness) {
          const normalizedTopic = topic.replace(/_/g, ' ');
          
          if (interaction.topic?.toLowerCase().includes(normalizedTopic) || 
              interaction.notes?.toLowerCase().includes(normalizedTopic)) {
            
            // Count this as a topic use
            this.topicEffectiveness[topic].total_uses++;
            mentionedTopics.add(topic);
            
            // If it's a question, count it
            if (interaction.type === 'question_answered') {
              this.topicEffectiveness[topic].questions_generated++;
            }
            
            // If interaction notes indicate positive response
            if (interaction.notes?.toLowerCase().includes('positive') || 
                interaction.notes?.toLowerCase().includes('interested') ||
                interaction.notes?.toLowerCase().includes('receptive')) {
              this.topicEffectiveness[topic].positive_responses++;
            }
          }
        }
        
        // Track engagement timeline
        if (interaction.date) {
          const interactionTime = new Date(interaction.date).getTime();
          
          if (firstInteractionTime === null || interactionTime < firstInteractionTime) {
            firstInteractionTime = interactionTime;
          }
          
          if (lastInteractionTime === null || interactionTime > lastInteractionTime) {
            lastInteractionTime = interactionTime;
          }
        }
      }
      
      // Calculate engagement time
      if (firstInteractionTime !== null && lastInteractionTime !== null) {
        totalEngagementTime = (lastInteractionTime - firstInteractionTime) / (1000 * 60 * 60 * 24); // in days
      }
      
      // If contact is converted, attribute to topics
      if (contact.status === 'converted') {
        for (const topic of mentionedTopics) {
          this.topicEffectiveness[topic].conversions_influenced++;
        }
      }
      
      // Update engagement time for each topic
      if (totalEngagementTime > 0) {
        for (const topic of mentionedTopics) {
          const currentTopic = this.topicEffectiveness[topic];
          const currentTotal = currentTopic.average_engagement_time * currentTopic.total_uses;
          const newTotal = currentTotal + totalEngagementTime;
          const newAverage = newTotal / (currentTopic.total_uses || 1);
          
          this.topicEffectiveness[topic].average_engagement_time = newAverage;
        }
      }
    }
  }
  
  /**
   * Update demographic insights
   */
  private updateDemographicInsights(contacts: any[]): void {
    // Reset counters
    for (const demographic in this.demographicInsights) {
      this.demographicInsights[demographic] = {
        count: 0,
        conversion_rate: 0,
        average_journey_length: 0
      };
    }
    
    // Process contacts to update demographic insights
    for (const contact of contacts) {
      // Skip contacts without religion info for some calculations
      if (!contact.religion) continue;
      
      let demographic = 'religious_seekers'; // default
      
      // Determine demographic
      if (contact.source?.includes('student') || 
          contact.interactions?.some((i: any) => i.notes?.includes('student'))) {
        demographic = 'students';
      } else if (contact.source?.includes('professional') || 
                 contact.interactions?.some((i: any) => i.notes?.includes('professional'))) {
        demographic = 'professionals';
      } else if (contact.religion?.toLowerCase().includes('christian')) {
        demographic = 'former_christians';
      } else if (contact.religion?.toLowerCase().includes('hindu')) {
        demographic = 'former_hindus';
      } else if (contact.religion?.toLowerCase().includes('buddhist')) {
        demographic = 'former_buddhists';
      } else if (contact.religion?.toLowerCase().includes('jew')) {
        demographic = 'former_jews';
      } else if (contact.religion?.toLowerCase().includes('atheist') || 
                 contact.religion?.toLowerCase().includes('agnostic')) {
        demographic = 'former_atheists';
      } else if (contact.religion?.toLowerCase().includes('muslim')) {
        demographic = 'born_muslims';
      }
      
      // Count the contact
      this.demographicInsights[demographic].count++;
      
      // Calculate journey length if converted
      if (contact.status === 'converted' && contact.interactions && contact.interactions.length > 0) {
        const firstInteractionDate = new Date(contact.interactions[0].date);
        const conversionInteraction = contact.interactions.find(
          (i: any) => i.type === 'status_change' && i.notes?.includes('converted')
        );
        
        if (conversionInteraction) {
          const conversionDate = new Date(conversionInteraction.date);
          const journeyLength = (conversionDate.getTime() - firstInteractionDate.getTime()) / 
                              (1000 * 60 * 60 * 24); // in days
          
          const currentDemographic = this.demographicInsights[demographic];
          const currentTotal = currentDemographic.average_journey_length * currentDemographic.count;
          const newTotal = currentTotal + journeyLength;
          
          this.demographicInsights[demographic].average_journey_length = newTotal / currentDemographic.count;
        }
      }
    }
    
    // Calculate conversion rates for each demographic
    for (const demographic in this.demographicInsights) {
      const convertedContacts = contacts.filter(
        c => c.status === 'converted' && 
            ((demographic === 'students' && (c.source?.includes('student') || 
                                           c.interactions?.some((i: any) => i.notes?.includes('student')))) ||
             (demographic === 'professionals' && (c.source?.includes('professional') || 
                                                c.interactions?.some((i: any) => i.notes?.includes('professional')))) ||
             (demographic === 'former_christians' && c.religion?.toLowerCase().includes('christian')) ||
             (demographic === 'former_hindus' && c.religion?.toLowerCase().includes('hindu')) ||
             (demographic === 'former_buddhists' && c.religion?.toLowerCase().includes('buddhist')) ||
             (demographic === 'former_jews' && c.religion?.toLowerCase().includes('jew')) ||
             (demographic === 'former_atheists' && (c.religion?.toLowerCase().includes('atheist') || 
                                                   c.religion?.toLowerCase().includes('agnostic'))) ||
             (demographic === 'born_muslims' && c.religion?.toLowerCase().includes('muslim')) ||
             (demographic === 'religious_seekers' && !c.religion))
      ).length;
      
      const totalInDemographic = this.demographicInsights[demographic].count;
      
      if (totalInDemographic > 0) {
        this.demographicInsights[demographic].conversion_rate = convertedContacts / totalInDemographic;
      }
    }
  }
  
  /**
   * Get overall dawah conversion statistics
   */
  getConversionStats(): {
    conversionFunnel: typeof this.conversionFunnelStats;
    totalContacts: number;
    conversionRate: number;
    mostEffectiveTopics: Array<{
      topic: string;
      conversions: number;
      effectiveness: number;
    }>;
  } {
    // Calculate total contacts
    const totalContacts = Object.values(this.conversionFunnelStats).reduce(
      (sum, count) => sum + count, 0
    );
    
    // Calculate overall conversion rate
    const conversionRate = totalContacts > 0 
      ? this.conversionFunnelStats.converted / totalContacts
      : 0;
    
    // Get most effective topics
    const topicsEffectiveness = Object.entries(this.topicEffectiveness)
      .map(([topic, stats]) => ({
        topic,
        conversions: stats.conversions_influenced,
        effectiveness: stats.total_uses > 0 
          ? stats.conversions_influenced / stats.total_uses 
          : 0
      }))
      .sort((a, b) => b.effectiveness - a.effectiveness)
      .slice(0, 5);
    
    return {
      conversionFunnel: this.conversionFunnelStats,
      totalContacts,
      conversionRate,
      mostEffectiveTopics: topicsEffectiveness
    };
  }
  
  /**
   * Get regional dawah statistics
   */
  getRegionalStats(
    region?: string,
    timeframe: 'all' | 'week' | 'month' | 'quarter' = 'all'
  ): {
    regions: Array<{
      region: string;
      stats: {
        interactions: number;
        questions_answered: number;
        materials_shared: number;
        potential_converts: number;
        conversions: number;
        conversion_rate: number;
        top_topics: Array<{
          topic: string;
          count: number;
        }>;
      };
      timeline?: Array<{
        date: string;
        interactions: number;
        conversions: number;
      }>;
    }>;
  } {
    // Filter by region if specified
    const regionsToInclude = region ? [region] : Object.keys(this.regionalStats);
    
    // Filter timeline based on timeframe
    const now = new Date();
    let timeframeDays = 0;
    
    switch(timeframe) {
      case 'week':
        timeframeDays = 7;
        break;
      case 'month':
        timeframeDays = 30;
        break;
      case 'quarter':
        timeframeDays = 90;
        break;
      case 'all':
      default:
        timeframeDays = 3650; // ~10 years, effectively all
    }
    
    const cutoffDate = new Date();
    cutoffDate.setDate(now.getDate() - timeframeDays);
    const cutoffDateString = cutoffDate.toISOString().split('T')[0];
    
    // Build response
    const regions = regionsToInclude.map(regionName => {
      const regionData = this.regionalStats[regionName];
      
      // Skip if no data
      if (!regionData) return null;
      
      // Filter timeline
      const filteredTimeline = regionData.timeline
        .filter(entry => entry.date >= cutoffDateString)
        .map(entry => ({
          date: entry.date,
          interactions: entry.interactions,
          conversions: entry.conversions
        }));
      
      // Format top topics
      const topTopics = Object.entries(regionData.top_topics)
        .map(([topic, count]) => ({
          topic,
          count
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);
      
      // Calculate conversion rate
      const conversionRate = regionData.potential_converts > 0 
        ? regionData.conversions / regionData.potential_converts
        : 0;
      
      return {
        region: regionName,
        stats: {
          interactions: regionData.interactions,
          questions_answered: regionData.questions_answered,
          materials_shared: regionData.materials_shared,
          potential_converts: regionData.potential_converts,
          conversions: regionData.conversions,
          conversion_rate: conversionRate,
          top_topics: topTopics
        },
        timeline: filteredTimeline
      };
    }).filter(region => region !== null) as Array<{
      region: string;
      stats: {
        interactions: number;
        questions_answered: number;
        materials_shared: number;
        potential_converts: number;
        conversions: number;
        conversion_rate: number;
        top_topics: Array<{
          topic: string;
          count: number;
        }>;
      };
      timeline: Array<{
        date: string;
        interactions: number;
        conversions: number;
      }>;
    }>;
    
    return { regions };
  }
  
  /**
   * Get topic effectiveness insights
   */
  getTopicInsights(
    sortBy: 'total_uses' | 'conversion_effectiveness' | 'engagement_time' = 'conversion_effectiveness'
  ): {
    topics: Array<{
      topic: string;
      total_uses: number;
      questions_generated: number;
      positive_responses: number;
      conversions_influenced: number;
      conversion_effectiveness: number;
      average_engagement_time: number;
    }>;
  } {
    // Build and sort topic insights
    const topics = Object.entries(this.topicEffectiveness)
      .map(([topic, stats]) => ({
        topic,
        total_uses: stats.total_uses,
        questions_generated: stats.questions_generated,
        positive_responses: stats.positive_responses,
        conversions_influenced: stats.conversions_influenced,
        conversion_effectiveness: stats.total_uses > 0 
          ? stats.conversions_influenced / stats.total_uses
          : 0,
        average_engagement_time: stats.average_engagement_time
      }))
      .filter(topic => topic.total_uses > 0); // Only include used topics
    
    // Sort based on requested criterion
    switch(sortBy) {
      case 'total_uses':
        topics.sort((a, b) => b.total_uses - a.total_uses);
        break;
      case 'conversion_effectiveness':
        topics.sort((a, b) => b.conversion_effectiveness - a.conversion_effectiveness);
        break;
      case 'engagement_time':
        topics.sort((a, b) => b.average_engagement_time - a.average_engagement_time);
        break;
    }
    
    return { topics };
  }
  
  /**
   * Get demographic insights
   */
  getDemographicInsights(): {
    demographics: Array<{
      demographic: string;
      count: number;
      conversion_rate: number;
      average_journey_length: number;
    }>;
    most_responsive: string;
    fastest_conversion: string;
  } {
    // Build demographic insights
    const demographics = Object.entries(this.demographicInsights)
      .map(([demographic, stats]) => ({
        demographic,
        count: stats.count,
        conversion_rate: stats.conversion_rate,
        average_journey_length: stats.average_journey_length
      }))
      .filter(demo => demo.count > 0) // Only include demographics with data
      .sort((a, b) => b.count - a.count); // Sort by count
    
    // Find most responsive demographic (highest conversion rate)
    let most_responsive = '';
    let highest_conversion_rate = 0;
    
    // Find fastest conversion demographic (shortest journey)
    let fastest_conversion = '';
    let shortest_journey = Number.MAX_VALUE;
    
    for (const demographic of demographics) {
      if (demographic.conversion_rate > highest_conversion_rate) {
        highest_conversion_rate = demographic.conversion_rate;
        most_responsive = demographic.demographic;
      }
      
      if (demographic.average_journey_length > 0 && 
          demographic.average_journey_length < shortest_journey) {
        shortest_journey = demographic.average_journey_length;
        fastest_conversion = demographic.demographic;
      }
    }
    
    return {
      demographics,
      most_responsive,
      fastest_conversion
    };
  }
  
  /**
   * Generate a comprehensive dawah effectiveness report
   */
  generateDawahReport(): {
    summary: {
      total_interactions: number;
      total_conversions: number;
      overall_conversion_rate: number;
      active_regions: number;
      most_effective_region: string;
      most_effective_topic: string;
      most_responsive_demographic: string;
    };
    conversion_funnel: typeof this.conversionFunnelStats;
    top_regions: Array<{
      region: string;
      conversions: number;
      conversion_rate: number;
    }>;
    top_topics: Array<{
      topic: string;
      conversions: number;
      effectiveness: number;
    }>;
    top_demographics: Array<{
      demographic: string;
      conversion_rate: number;
      count: number;
    }>;
    recommendations: string[];
  } {
    try {
      // Get necessary insights
      const conversionStats = this.getConversionStats();
      const regionalStats = this.getRegionalStats();
      const topicInsights = this.getTopicInsights('conversion_effectiveness');
      const demographicInsights = this.getDemographicInsights();
      
      // Calculate total interactions and conversions
      const total_interactions = Object.values(this.regionalStats).reduce(
        (sum, region) => sum + region.interactions, 0
      );
      
      const total_conversions = Object.values(this.regionalStats).reduce(
        (sum, region) => sum + region.conversions, 0
      );
      
      // Find most effective region
      let most_effective_region = '';
      let highest_regional_conversion_rate = 0;
      
      for (const region of regionalStats.regions) {
        if (region.stats.conversion_rate > highest_regional_conversion_rate) {
          highest_regional_conversion_rate = region.stats.conversion_rate;
          most_effective_region = region.region;
        }
      }
      
      // Generate recommendations based on data
      const recommendations = this.generateRecommendations(
        conversionStats,
        regionalStats,
        topicInsights,
        demographicInsights
      );
      
      // Building the report
      return {
        summary: {
          total_interactions,
          total_conversions,
          overall_conversion_rate: conversionStats.conversionRate,
          active_regions: regionalStats.regions.length,
          most_effective_region,
          most_effective_topic: conversionStats.mostEffectiveTopics[0]?.topic || 'N/A',
          most_responsive_demographic: demographicInsights.most_responsive
        },
        conversion_funnel: conversionStats.conversionFunnel,
        top_regions: regionalStats.regions
          .slice(0, 3)
          .map(region => ({
            region: region.region,
            conversions: region.stats.conversions,
            conversion_rate: region.stats.conversion_rate
          })),
        top_topics: conversionStats.mostEffectiveTopics,
        top_demographics: demographicInsights.demographics
          .slice(0, 3)
          .map(demo => ({
            demographic: demo.demographic,
            conversion_rate: demo.conversion_rate,
            count: demo.count
          })),
        recommendations
      };
    } catch (error) {
      console.error('Error generating dawah report:', error);
      
      // Return basic report if error occurs
      return {
        summary: {
          total_interactions: 0,
          total_conversions: 0,
          overall_conversion_rate: 0,
          active_regions: 0,
          most_effective_region: 'N/A',
          most_effective_topic: 'N/A',
          most_responsive_demographic: 'N/A'
        },
        conversion_funnel: this.conversionFunnelStats,
        top_regions: [],
        top_topics: [],
        top_demographics: [],
        recommendations: [
          'Gather more data to generate accurate recommendations',
          'Ensure proper tracking of dawah interactions is in place',
          'Review analytics system settings'
        ]
      };
    }
  }
  
  /**
   * Generate data-driven recommendations for dawah improvement
   */
  private generateRecommendations(
    conversionStats: ReturnType<typeof this.getConversionStats>,
    regionalStats: ReturnType<typeof this.getRegionalStats>,
    topicInsights: ReturnType<typeof this.getTopicInsights>,
    demographicInsights: ReturnType<typeof this.getDemographicInsights>
  ): string[] {
    const recommendations: string[] = [];
    
    // Analyze conversion funnel for drop-offs
    const funnel = conversionStats.conversionFunnel;
    const totalInFunnel = Object.values(funnel).reduce((sum, count) => sum + count, 0);
    
    if (totalInFunnel > 0) {
      // Check for significant drop-offs in the funnel
      if (funnel.interested / funnel.initial_contact < 0.3) {
        recommendations.push(
          'Focus on improving initial engagement strategies to increase interest from first contacts'
        );
      }
      
      if (funnel.learning / funnel.interested < 0.5) {
        recommendations.push(
          'Enhance educational materials to better transition interested individuals to active learning'
        );
      }
      
      if (funnel.convinced / funnel.learning < 0.3) {
        recommendations.push(
          'Strengthen persuasive dialogues and address barriers to conviction more effectively'
        );
      }
      
      if (funnel.converted / funnel.convinced < 0.5) {
        recommendations.push(
          'Improve support and guidance for those who are convinced but haven\'t yet converted'
        );
      }
      
      if (funnel.inactive / totalInFunnel > 0.3) {
        recommendations.push(
          'Implement a re-engagement strategy for inactive contacts to bring them back into the dawah journey'
        );
      }
    }
    
    // Analyze topic effectiveness
    if (topicInsights.topics.length > 0) {
      // Check for underutilized effective topics
      const effectiveButUnderutilized = topicInsights.topics.find(
        topic => topic.conversion_effectiveness > 0.2 && topic.total_uses < 10
      );
      
      if (effectiveButUnderutilized) {
        recommendations.push(
          `Increase use of the "${effectiveButUnderutilized.topic.replace(/_/g, ' ')}" topic, which shows high effectiveness but is underutilized`
        );
      }
      
      // Check for topics with long engagement but low conversion
      const longEngagementLowConversion = topicInsights.topics.find(
        topic => topic.average_engagement_time > 30 && topic.conversion_effectiveness < 0.1
      );
      
      if (longEngagementLowConversion) {
        recommendations.push(
          `Refine approach to "${longEngagementLowConversion.topic.replace(/_/g, ' ')}" topic, which generates long engagement but relatively few conversions`
        );
      }
      
      // Recommend top-performing topic
      const topPerformer = topicInsights.topics[0];
      if (topPerformer) {
        recommendations.push(
          `Continue emphasis on "${topPerformer.topic.replace(/_/g, ' ')}" topic, which demonstrates the highest conversion effectiveness`
        );
      }
    }
    
    // Analyze demographic insights
    if (demographicInsights.demographics.length > 0) {
      // Identify demographics with high counts but low conversion rates
      const highCountLowConversion = demographicInsights.demographics.find(
        demo => demo.count > 20 && demo.conversion_rate < 0.1
      );
      
      if (highCountLowConversion) {
        recommendations.push(
          `Develop specialized approaches for the "${highCountLowConversion.demographic.replace(/_/g, ' ')}" demographic, which has high numbers but low conversion rates`
        );
      }
      
      // Identify fastest converting demographic for optimization
      if (demographicInsights.fastest_conversion) {
        recommendations.push(
          `Analyze and replicate successful elements from the "${demographicInsights.fastest_conversion.replace(/_/g, ' ')}" demographic's journey, which shows the fastest conversion path`
        );
      }
    }
    
    // If we don't have enough recommendations, add general ones
    if (recommendations.length < 3) {
      recommendations.push(
        'Implement systematic follow-up processes for all contacts to minimize drop-offs',
        'Develop more tailored content for specific demographics and backgrounds',
        'Create a mentorship program pairing new converts with experienced Muslims for stronger community integration'
      );
    }
    
    // Cap at 5 recommendations maximum
    return recommendations.slice(0, 5);
  }
}

export const dawahAnalyticsService = new DawahAnalyticsService();