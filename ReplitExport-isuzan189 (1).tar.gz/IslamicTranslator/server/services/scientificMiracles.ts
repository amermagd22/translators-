import { openaiService } from "./openai";
import { anthropicService } from "./anthropic";

// Service for providing scientific miracles and evidences from Quran and Sunnah
export class ScientificMiraclesService {
  // Categories of scientific miracles in Quran and Sunnah
  private miracleCategories = [
    'astronomy',
    'embryology',
    'oceanography',
    'geology',
    'zoology',
    'botany',
    'medicine',
    'physics',
    'meteorology',
    'general_science'
  ];

  // Scientific miracles from Quran with references
  private quranMiracles = [
    {
      id: 'expanding_universe',
      category: 'astronomy',
      verse: {
        arabic: 'وَالسَّمَاءَ بَنَيْنَاهَا بِأَيْدٍ وَإِنَّا لَمُوسِعُونَ',
        reference: 'الذاريات: 47'
      },
      description: 'This verse indicates that Allah is expanding the universe, which was confirmed by modern science in the 20th century when Edwin Hubble discovered that galaxies are moving away from each other.',
      scientificFact: 'The universe is constantly expanding, a fact discovered only in 1929 by Edwin Hubble.',
      modernDiscovery: {
        year: 1929,
        scientist: 'Edwin Hubble',
        discovery: 'The redshift phenomenon indicating that galaxies are moving away from each other'
      },
      references: [
        {
          author: 'Dr. Zakir Naik',
          source: 'The Quran and Modern Science',
          year: 2007
        },
        {
          author: 'Maurice Bucaille',
          source: 'The Bible, The Quran and Science',
          year: 1976
        }
      ]
    },
    {
      id: 'embryonic_development',
      category: 'embryology',
      verse: {
        arabic: 'ثُمَّ خَلَقْنَا النُّطْفَةَ عَلَقَةً فَخَلَقْنَا الْعَلَقَةَ مُضْغَةً فَخَلَقْنَا الْمُضْغَةَ عِظَامًا فَكَسَوْنَا الْعِظَامَ لَحْمًا ثُمَّ أَنشَأْنَاهُ خَلْقًا آخَرَ ۚ فَتَبَارَكَ اللَّهُ أَحْسَنُ الْخَالِقِينَ',
        reference: 'المؤمنون: 14'
      },
      description: 'This verse accurately describes the stages of embryonic development, from the drop of sperm to the stage of a chewed-like substance (mudghah), then the formation of bones, and finally covering them with flesh.',
      scientificFact: 'The detailed stages of human embryonic development were only discovered with advanced microscopy in the 20th century.',
      modernDiscovery: {
        year: 1941,
        scientist: 'Various embryologists',
        discovery: 'Detailed staging of human embryonic development'
      },
      references: [
        {
          author: 'Dr. Keith Moore',
          source: 'The Developing Human',
          year: 1982
        },
        {
          author: 'Dr. Maurice Bucaille',
          source: 'The Bible, The Quran and Science',
          year: 1976
        }
      ]
    },
    {
      id: 'deep_seas_darkness',
      category: 'oceanography',
      verse: {
        arabic: 'أَوْ كَظُلُمَاتٍ فِي بَحْرٍ لُّجِّيٍّ يَغْشَاهُ مَوْجٌ مِّن فَوْقِهِ مَوْجٌ مِّن فَوْقِهِ سَحَابٌ ۚ ظُلُمَاتٌ بَعْضُهَا فَوْقَ بَعْضٍ',
        reference: 'النور: 40'
      },
      description: 'This verse describes the darkness in deep seas and oceans, where there are waves within waves. This accurately depicts the layers of darkness in deep oceans discovered only by modern oceanography.',
      scientificFact: 'In deep seas, there are successive layers of darkness due to the absorption of light at different depths.',
      modernDiscovery: {
        year: 1930,
        scientist: 'Oceanographers with advanced equipment',
        discovery: 'Layered darkness in deep oceans due to light absorption at different wavelengths'
      },
      references: [
        {
          author: 'Dr. William Hay',
          source: 'Oceanography studies',
          year: 1985
        }
      ]
    },
    {
      id: 'mountains_as_pegs',
      category: 'geology',
      verse: {
        arabic: 'أَلَمْ نَجْعَلِ الْأَرْضَ مِهَادًا وَالْجِبَالَ أَوْتَادًا',
        reference: 'النبأ: 6-7'
      },
      description: 'The Quran describes mountains as pegs (awtad), which is scientifically accurate as mountains have deep roots beneath the surface that stabilize the earth\'s crust.',
      scientificFact: 'Mountains have deep roots beneath the surface that stabilize the earth\'s crust, acting like pegs or stakes.',
      modernDiscovery: {
        year: 1950,
        scientist: 'Geologists',
        discovery: 'The deep roots of mountains and their role in stabilizing the earth\'s crust'
      },
      references: [
        {
          author: 'Dr. Frank Press',
          source: 'Earth and Space Sciences',
          year: 1986
        }
      ]
    },
    {
      id: 'iron_sent_down',
      category: 'physics',
      verse: {
        arabic: 'وَأَنزَلْنَا الْحَدِيدَ فِيهِ بَأْسٌ شَدِيدٌ وَمَنَافِعُ لِلنَّاسِ',
        reference: 'الحديد: 25'
      },
      description: 'The Quran states that iron was "sent down", which aligns with modern understanding that iron was not formed on Earth but came from outer space through meteorites.',
      scientificFact: 'Iron is not native to Earth but was brought down to Earth from outer space through meteorites.',
      modernDiscovery: {
        year: 1970,
        scientist: 'Astrophysicists',
        discovery: 'Iron was formed in distant stars and supernovas before being transported to Earth'
      },
      references: [
        {
          author: 'Dr. Yusuf Al-Hajj Ahmad',
          source: 'Encyclopedia of Scientific Miracles in Quran and Sunnah',
          year: 2009
        }
      ]
    },
    {
      id: 'barrier_between_seas',
      category: 'oceanography',
      verse: {
        arabic: 'مَرَجَ الْبَحْرَيْنِ يَلْتَقِيَانِ بَيْنَهُمَا بَرْزَخٌ لَّا يَبْغِيَانِ',
        reference: 'الرحمن: 19-20'
      },
      description: 'The Quran mentions a barrier between two seas that meet but do not mix. This phenomenon is now known to be due to the different densities, temperatures, and salinity levels of adjacent water bodies.',
      scientificFact: 'There are barriers between different bodies of water due to differences in density, temperature, and salinity.',
      modernDiscovery: {
        year: 1960,
        scientist: 'Oceanographers',
        discovery: 'The presence of water barriers in places like the Mediterranean Sea and Atlantic Ocean junction'
      },
      references: [
        {
          author: 'Jacques Cousteau',
          source: 'Oceanographic expeditions',
          year: 1962
        }
      ]
    }
  ];

  // Prophetic miracles and scientific facts from Hadith
  private propheticMiracles = [
    {
      id: 'fly_wings_medicine',
      category: 'medicine',
      hadith: {
        arabic: 'إِذَا وَقَعَ الذُّبَابُ فِي شَرَابِ أَحَدِكُمْ فَلْيَغْمِسْهُ ثُمَّ لِيَنْزِعْهُ، فَإِنَّ فِي إِحْدَى جَنَاحَيْهِ دَاءً وَفِي الْأُخْرَى شِفَاءً',
        source: 'صحيح البخاري'
      },
      description: 'The Prophet Muhammad (peace be upon him) mentioned that if a fly falls into a drink, it should be fully immersed, as one wing carries disease and the other carries its antidote.',
      scientificFact: 'Modern research has shown that flies carry bacteria on their bodies, but they also carry antibiotics that can neutralize these bacteria.',
      modernDiscovery: {
        year: 1976,
        scientist: 'Dr. Hafiz Mughal',
        discovery: 'Flies carry antibiotics on their wings that counteract the bacteria they also carry'
      },
      references: [
        {
          author: 'Dr. Hafiz Mughal',
          source: 'Natural Antibiotics research',
          year: 1976
        }
      ]
    },
    {
      id: 'heart_consciousness',
      category: 'medicine',
      hadith: {
        arabic: 'أَلَا وَإِنَّ فِي الْجَسَدِ مُضْغَةً إِذَا صَلَحَتْ صَلَحَ الْجَسَدُ كُلُّهُ، وَإِذَا فَسَدَتْ فَسَدَ الْجَسَدُ كُلُّهُ، أَلَا وَهِيَ الْقَلْبُ',
        source: 'صحيح البخاري ومسلم'
      },
      description: 'The Prophet Muhammad (peace be upon him) described the heart as a "mudghah" (piece of flesh) that, when corrupted, corrupts the entire body.',
      scientificFact: 'Modern neurocardiology has discovered that the heart contains neural cells similar to those in the brain and can influence brain function and emotions.',
      modernDiscovery: {
        year: 1991,
        scientist: 'Dr. J. Andrew Armour',
        discovery: 'The heart has its own intrinsic nervous system, often called "the little brain in the heart"'
      },
      references: [
        {
          author: 'Dr. J. Andrew Armour',
          source: 'Neurocardiology: Anatomical and Functional Principles',
          year: 1994
        }
      ]
    },
    {
      id: 'honey_healing',
      category: 'medicine',
      hadith: {
        arabic: 'عَلَيْكُمْ بِالشِّفَاءَيْنِ: الْعَسَلِ وَالْقُرْآنِ',
        source: 'سنن ابن ماجه'
      },
      description: 'The Prophet Muhammad (peace be upon him) prescribed honey as a healing substance, calling it one of the two cures (along with the Quran).',
      scientificFact: 'Modern research confirms honey\'s antimicrobial, anti-inflammatory, and antioxidant properties.',
      modernDiscovery: {
        year: 1937,
        scientist: 'Various medical researchers',
        discovery: 'The antibacterial properties of honey and its effectiveness in treating various ailments'
      },
      references: [
        {
          author: 'Dr. Peter Molan',
          source: 'The Antibacterial Activity of Honey',
          year: 1992
        }
      ]
    }
  ];

  // Scientific books and researchers specializing in Quranic miracles
  private authorityReferences = [
    {
      author: 'Dr. Maurice Bucaille',
      credentials: 'French medical doctor, author of "The Bible, the Quran and Science"',
      specialization: 'Comparative study of scriptures and science'
    },
    {
      author: 'Dr. Keith Moore',
      credentials: 'Professor of Anatomy and Cell Biology, University of Toronto',
      specialization: 'Embryology'
    },
    {
      author: 'Dr. Zakir Naik',
      credentials: 'Medical doctor and Islamic scholar',
      specialization: 'Comparative religion and scientific miracles in Quran'
    },
    {
      author: 'Dr. Gary Miller (Abdul-Ahad Omar)',
      credentials: 'Former Christian missionary, mathematician',
      specialization: 'Mathematical analysis of the Quran'
    }
  ];

  // Get all scientific miracle categories
  getMiracleCategories(): string[] {
    return this.miracleCategories;
  }

  // Get scientific miracles by category
  getMiraclesByCategory(
    category: string,
    options: {
      limit?: number;
      includeReferences?: boolean;
      language?: string;
      detailedExplanation?: boolean;
    } = {}
  ): {
    miracles: any[];
    total: number;
  } {
    // Default options
    const defaultOptions = {
      limit: 10,
      includeReferences: true,
      language: 'ar',
      detailedExplanation: false
    };
    
    // Merge with provided options
    const settings = { ...defaultOptions, ...options };
    
    // Filter miracles by category
    let filteredMiracles = [];
    
    if (category === 'all') {
      filteredMiracles = [...this.quranMiracles, ...this.propheticMiracles];
    } else {
      const quranFiltered = this.quranMiracles.filter(m => m.category === category);
      const propheticFiltered = this.propheticMiracles.filter(m => m.category === category);
      filteredMiracles = [...quranFiltered, ...propheticFiltered];
    }
    
    // Process miracles according to options
    const processedMiracles = filteredMiracles.map(miracle => {
      // Create a copy to avoid modifying the original
      const processed = { ...miracle };
      
      // Remove references if not requested
      if (!settings.includeReferences) {
        delete processed.references;
      }
      
      // Generate detailed explanation if requested
      if (settings.detailedExplanation) {
        processed.detailedExplanation = 
          `This scientific miracle addresses ${miracle.category} concepts. ` +
          `${miracle.description} ${miracle.scientificFact} ` +
          `This was discovered by modern science in approximately ${miracle.modernDiscovery.year}, ` +
          `yet was mentioned in the Islamic texts over 1400 years ago.`;
      }
      
      return processed;
    });
    
    // Apply limit
    const limitedMiracles = processedMiracles.slice(0, settings.limit);
    
    return {
      miracles: limitedMiracles,
      total: filteredMiracles.length
    };
  }

  // Get a specific miracle by ID
  getMiracleById(
    id: string,
    options: {
      includeReferences?: boolean;
      includeRelated?: boolean;
      language?: string;
      detailedExplanation?: boolean;
    } = {}
  ): any {
    // Default options
    const defaultOptions = {
      includeReferences: true,
      includeRelated: false,
      language: 'ar',
      detailedExplanation: true
    };
    
    // Merge with provided options
    const settings = { ...defaultOptions, ...options };
    
    // Find the miracle by ID
    const quranMiracle = this.quranMiracles.find(m => m.id === id);
    const propheticMiracle = this.propheticMiracles.find(m => m.id === id);
    const miracle = quranMiracle || propheticMiracle;
    
    if (!miracle) return null;
    
    // Create a copy to avoid modifying the original
    const processed = { ...miracle };
    
    // Generate detailed explanation if requested
    if (settings.detailedExplanation) {
      processed.detailedExplanation = 
        `This scientific miracle addresses ${miracle.category} concepts. ` +
        `${miracle.description} ${miracle.scientificFact} ` +
        `This was discovered by modern science in approximately ${miracle.modernDiscovery.year}, ` +
        `yet was mentioned in the Islamic texts over 1400 years ago.`;
    }
    
    // Remove references if not requested
    if (!settings.includeReferences) {
      delete processed.references;
    }
    
    // Add related miracles if requested
    if (settings.includeRelated) {
      // Find miracles in the same category
      const relatedMiracles = [...this.quranMiracles, ...this.propheticMiracles]
        .filter(m => m.category === miracle.category && m.id !== id)
        .slice(0, 3)
        .map(m => ({
          id: m.id,
          title: m.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          category: m.category,
          source: 'quranMiracles' in m ? 'Quran' : 'Hadith'
        }));
      
      processed.relatedMiracles = relatedMiracles;
    }
    
    return processed;
  }

  // Search for scientific miracles based on keywords
  searchMiracles(
    query: string,
    options: {
      limit?: number;
      includeReferences?: boolean;
      language?: string;
    } = {}
  ): {
    results: any[];
    total: number;
  } {
    // Default options
    const defaultOptions = {
      limit: 10,
      includeReferences: false,
      language: 'ar'
    };
    
    // Merge with provided options
    const settings = { ...defaultOptions, ...options };
    
    // Normalize query
    const normalizedQuery = query.toLowerCase().trim();
    
    // Search in all miracles
    const allMiracles = [...this.quranMiracles, ...this.propheticMiracles];
    
    const matchedMiracles = allMiracles.filter(miracle => {
      // Search in multiple fields
      return (
        miracle.id.includes(normalizedQuery) ||
        miracle.category.includes(normalizedQuery) ||
        miracle.description.toLowerCase().includes(normalizedQuery) ||
        miracle.scientificFact.toLowerCase().includes(normalizedQuery) ||
        // Search in verse or hadith text if present
        (miracle.verse && miracle.verse.arabic.includes(normalizedQuery)) ||
        (miracle.hadith && miracle.hadith.arabic.includes(normalizedQuery))
      );
    });
    
    // Process miracles according to options
    const processedMiracles = matchedMiracles.map(miracle => {
      // Create a copy to avoid modifying the original
      const processed = { ...miracle };
      
      // Remove references if not requested
      if (!settings.includeReferences) {
        delete processed.references;
      }
      
      // Add source type
      processed.source = 'verse' in miracle ? 'Quran' : 'Hadith';
      
      return processed;
    });
    
    // Apply limit
    const limitedMiracles = processedMiracles.slice(0, settings.limit);
    
    return {
      results: limitedMiracles,
      total: matchedMiracles.length
    };
  }

  // Generate a response about scientific miracles using AI
  async generateMiracleExplanation(
    topic: string,
    options: {
      depth?: 'simple' | 'detailed' | 'scholarly';
      audience?: 'general' | 'scientific' | 'interfaith';
      language?: string;
      includeReferences?: boolean;
      includeVerses?: boolean;
    } = {}
  ): Promise<{
    explanation: string;
    verses?: {
      arabic: string;
      translation: string;
      reference: string;
    }[];
    scientificFacts: string[];
    references?: {
      author: string;
      source: string;
      year: number;
    }[];
  }> {
    try {
      // Default options
      const defaultOptions = {
        depth: 'detailed' as const,
        audience: 'general' as const,
        language: 'ar',
        includeReferences: true,
        includeVerses: true
      };
      
      // Merge with provided options
      const settings = { ...defaultOptions, ...options };
      
      // Find related miracles to use as context
      const normalizedTopic = topic.toLowerCase().trim();
      
      // Try to find a matching category first
      let matchingCategory = this.miracleCategories.find(category => 
        normalizedTopic.includes(category) || category.includes(normalizedTopic)
      );
      
      // If no category match, search all miracles
      let relatedMiracles = [];
      
      if (matchingCategory) {
        // Get miracles from matching category
        const categoryResults = this.getMiraclesByCategory(matchingCategory, { 
          limit: 3, 
          includeReferences: true 
        });
        relatedMiracles = categoryResults.miracles;
      } else {
        // Search all miracles
        const searchResults = this.searchMiracles(normalizedTopic, { 
          limit: 3, 
          includeReferences: true 
        });
        relatedMiracles = searchResults.results;
      }

      // If we still don't have related miracles, use a general prompt
      if (relatedMiracles.length === 0) {
        // Find closest category
        for (const category of this.miracleCategories) {
          if (normalizedTopic.includes(category.substring(0, 4)) || 
              category.includes(normalizedTopic.substring(0, 4))) {
            matchingCategory = category;
            break;
          }
        }
        
        // If we found a category, get miracles
        if (matchingCategory) {
          const categoryResults = this.getMiraclesByCategory(matchingCategory, { 
            limit: 2, 
            includeReferences: true 
          });
          relatedMiracles = categoryResults.miracles;
        } else {
          // Default to some common miracles
          relatedMiracles = [
            this.quranMiracles[0],
            this.quranMiracles[1],
            this.propheticMiracles[0]
          ];
        }
      }
      
      // Format context from related miracles
      const miraclesContext = relatedMiracles.map(miracle => {
        return `
Topic: ${miracle.category}
ID: ${miracle.id}
${miracle.verse ? `Verse: ${miracle.verse.arabic}` : `Hadith: ${miracle.hadith.arabic}`}
Reference: ${miracle.verse ? miracle.verse.reference : miracle.hadith.source}
Description: ${miracle.description}
Scientific Fact: ${miracle.scientificFact}
Modern Discovery: Discovered around ${miracle.modernDiscovery.year} by ${miracle.modernDiscovery.scientist}
        `;
      }).join('\n\n');
      
      // Build the prompt based on options
      let depthDescription = '';
      if (settings.depth === 'simple') {
        depthDescription = 'simple and easy to understand, focusing on the basic concepts';
      } else if (settings.depth === 'detailed') {
        depthDescription = 'detailed but accessible, providing good context and explanation';
      } else if (settings.depth === 'scholarly') {
        depthDescription = 'scholarly and in-depth, including technical details and comprehensive analysis';
      }
      
      let audienceDescription = '';
      if (settings.audience === 'general') {
        audienceDescription = 'general audience with basic education';
      } else if (settings.audience === 'scientific') {
        audienceDescription = 'scientifically literate audience with interest in both science and religion';
      } else if (settings.audience === 'interfaith') {
        audienceDescription = 'interfaith dialogue where the audience may include people of different faiths';
      }
      
      const systemPrompt = `You are an expert in scientific miracles in the Quran and Hadith. 
Please provide a ${depthDescription} explanation about "${topic}" for a ${audienceDescription}. 
Use the following scientific miracle examples as context, but feel free to incorporate additional relevant miracles:

${miraclesContext}

Ensure your response is factual, respectful, and avoids any speculative or controversial claims. Focus on well-established scientific facts and their relationship to Quranic verses or Hadith.

${settings.includeVerses ? 'Include relevant Quranic verses with their Arabic text, translation, and references.' : ''}
${settings.includeReferences ? 'Include scholarly references supporting these scientific interpretations.' : ''}

Format your response as a structured explanation with these components:
1. Main explanation
2. Key scientific facts
3. Quranic/Hadith evidence
4. Scholarly references if requested

Respond in ${settings.language === 'ar' ? 'Arabic' : 'English'} language.`;

      // Use appropriate AI service for generation
      let explanation;
      try {
        // Try Anthropic first for better nuance on religious topics
        const anthropicResponse = await anthropicService.analyzeMultilingualContent(topic, settings.language || 'ar', systemPrompt);
        explanation = anthropicResponse;
      } catch (error) {
        // Fall back to OpenAI
        explanation = await openaiService.enhanceTranslation(topic, 'en', settings.language || 'ar', true, systemPrompt);
      }
      
      // In a real implementation, we would parse the AI response into a structured format
      // Here we'll create a simplified structure
      
      // Extract scientific facts (simplified implementation)
      const scientificFacts = [
        'The Quran accurately described embryonic development stages 1400 years ago',
        'The expanding universe was mentioned in the Quran before its scientific discovery',
        'The barrier between fresh and salt water was described in the Quran'
      ];
      
      // Prepare verses if requested (simplified implementation)
      let verses;
      if (settings.includeVerses) {
        verses = relatedMiracles
          .filter(m => m.verse)
          .map(m => ({
            arabic: m.verse.arabic,
            translation: 'Translation would be provided here',
            reference: m.verse.reference
          }));
      }
      
      // Prepare references if requested (simplified implementation)
      let references;
      if (settings.includeReferences) {
        references = relatedMiracles
          .flatMap(m => m.references)
          .filter((ref, index, self) => 
            index === self.findIndex(r => r.author === ref.author && r.source === ref.source)
          );
      }
      
      return {
        explanation,
        verses,
        scientificFacts,
        references
      };
    } catch (error) {
      console.error("Error generating miracle explanation:", error);
      throw new Error("Failed to generate explanation");
    }
  }

  // Get authorities on scientific miracles in Quran
  getAuthorities(): any[] {
    return this.authorityReferences;
  }
}

export const scientificMiraclesService = new ScientificMiraclesService();