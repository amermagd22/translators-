import { WebClient } from '@slack/web-api';
import { anthropicService } from './anthropic';
import { openaiService } from './openai';
import { filterService } from './filter';
import { islamicContentDetector } from './islamicContentDetector';
import { islamicDawahService } from './islamicDawah';

/**
 * Service for Islamic dawah through social media management
 * Allows for automated Islamic content sharing, response generation,
 * and audience analytics across multiple platforms.
 */
export class SocialMediaManagerService {
  private slack: WebClient | null = null;
  private platforms = ['slack', 'twitter', 'facebook', 'instagram', 'telegram'];
  
  // Connect to available platform APIs
  constructor() {
    // Initialize Slack if credentials available
    if (process.env.SLACK_BOT_TOKEN) {
      this.slack = new WebClient(process.env.SLACK_BOT_TOKEN);
      console.log('Social Media Manager: Slack connection initialized');
    }
    
    // Other platform connections would be initialized here
  }
  
  /**
   * Check if a specific platform is available
   */
  isPlatformAvailable(platform: string): boolean {
    if (platform === 'slack') {
      return !!this.slack;
    }
    
    // Add more platform checks here
    return false;
  }
  
  /**
   * List all available platforms
   */
  getAvailablePlatforms(): string[] {
    return this.platforms.filter(platform => this.isPlatformAvailable(platform));
  }
  
  /**
   * Post Islamic content to a specified platform
   */
  async postContent(
    platform: string,
    content: string,
    options: {
      channelId?: string;
      contentType?: 'dawah' | 'educational' | 'news' | 'reminder';
      attachments?: any[];
      scheduledTime?: Date;
    } = {}
  ): Promise<{
    success: boolean;
    postId?: string;
    error?: string;
  }> {
    try {
      // First verify content is Islamic and appropriate
      const contentCheck = await islamicContentDetector.detectIslamicContent(content);
      
      if (!contentCheck.isIslamic) {
        return {
          success: false,
          error: 'Content is not sufficiently Islamic or does not contain Islamic themes.'
        };
      }
      
      // Check for prohibited content
      const hasProhibited = await filterService.containsProhibitedContent(content, 'auto');
      if (hasProhibited) {
        return {
          success: false,
          error: 'Content contains prohibited material according to Islamic guidelines.'
        };
      }
      
      // Add respectful phrases if needed
      let enhancedContent = content;
      if (contentCheck.containsProphetMention && !contentCheck.containsRespectfulPhrases) {
        enhancedContent = await islamicContentDetector.enhanceWithRespectfulPhrases(content);
      }
      
      // Post to appropriate platform
      switch (platform.toLowerCase()) {
        case 'slack':
          if (!this.slack) {
            return {
              success: false,
              error: 'Slack connection not available. Please provide SLACK_BOT_TOKEN.'
            };
          }
          
          const channelId = options.channelId || process.env.SLACK_CHANNEL_ID;
          if (!channelId) {
            return {
              success: false,
              error: 'No Slack channel ID provided. Please set SLACK_CHANNEL_ID environment variable or provide channelId in options.'
            };
          }
          
          const slackResponse = await this.slack.chat.postMessage({
            channel: channelId,
            text: enhancedContent,
            unfurl_links: true,
            unfurl_media: true
          });
          
          return {
            success: slackResponse.ok,
            postId: slackResponse.ts as string,
            error: slackResponse.error
          };
          
        // Other platform implementations would be added here
        default:
          return {
            success: false,
            error: `Platform ${platform} is not supported or connection not available.`
          };
      }
    } catch (error) {
      console.error('Error posting to social media:', error);
      return {
        success: false,
        error: `Failed to post content: ${error.message}`
      };
    }
  }
  
  /**
   * Get recent activity from a social media platform
   */
  async getRecentActivity(
    platform: string,
    options: {
      channelId?: string;
      limit?: number;
      includeReplies?: boolean;
    } = {}
  ): Promise<{
    success: boolean;
    messages?: any[];
    error?: string;
  }> {
    try {
      switch (platform.toLowerCase()) {
        case 'slack':
          if (!this.slack) {
            return {
              success: false,
              error: 'Slack connection not available. Please provide SLACK_BOT_TOKEN.'
            };
          }
          
          const channelId = options.channelId || process.env.SLACK_CHANNEL_ID;
          if (!channelId) {
            return {
              success: false,
              error: 'No Slack channel ID provided. Please set SLACK_CHANNEL_ID environment variable or provide channelId in options.'
            };
          }
          
          const slackHistory = await this.slack.conversations.history({
            channel: channelId,
            limit: options.limit || 20,
            include_all_metadata: true
          });
          
          return {
            success: slackHistory.ok,
            messages: slackHistory.messages as any[],
            error: slackHistory.error
          };
          
        // Other platform implementations would be added here
        default:
          return {
            success: false,
            error: `Platform ${platform} is not supported or connection not available.`
          };
      }
    } catch (error) {
      console.error('Error getting recent activity:', error);
      return {
        success: false,
        error: `Failed to get activity: ${error.message}`
      };
    }
  }
  
  /**
   * Analyze social media engagement to identify potential dawah opportunities
   */
  async analyzeDawahOpportunities(
    platform: string,
    options: {
      channelId?: string;
      messageLimit?: number;
      lookForQuestions?: boolean;
      identifyMisconceptions?: boolean;
    } = {}
  ): Promise<{
    success: boolean;
    opportunities?: Array<{
      messageId: string;
      messageText: string;
      type: 'question' | 'misconception' | 'interest';
      suggestedResponse?: string;
      confidenceScore: number;
    }>;
    error?: string;
  }> {
    try {
      // Get recent activities
      const recentActivity = await this.getRecentActivity(platform, {
        channelId: options.channelId,
        limit: options.messageLimit || 50
      });
      
      if (!recentActivity.success || !recentActivity.messages) {
        return {
          success: false,
          error: recentActivity.error || 'Failed to retrieve recent activity'
        };
      }
      
      const opportunities = [];
      
      for (const message of recentActivity.messages) {
        if (!message.text || message.bot_id) continue; // Skip empty messages or bot messages
        
        // Analyze message text
        let messageType: 'question' | 'misconception' | 'interest' | null = null;
        let confidenceScore = 0;
        let suggestedResponse: string | undefined;
        
        // Look for questions about Islam
        if (options.lookForQuestions !== false && 
            (message.text.includes('?') || 
             message.text.toLowerCase().includes('what is') ||
             message.text.toLowerCase().includes('how does') ||
             message.text.toLowerCase().includes('why do'))) {
          
          const isIslamicQuestion = await this.isIslamicQuestion(message.text);
          
          if (isIslamicQuestion.isIslamic) {
            messageType = 'question';
            confidenceScore = isIslamicQuestion.confidence;
            
            // Generate a suggested response
            try {
              const faithResponse = await islamicDawahService.generateFaithResponse(
                message.text,
                { 
                  detailLevel: 'brief',
                  includeScriptural: true
                }
              );
              
              suggestedResponse = faithResponse.answer;
            } catch (error) {
              console.error('Error generating faith response:', error);
            }
          }
        }
        
        // Look for common misconceptions about Islam
        if (options.identifyMisconceptions !== false && !messageType) {
          const possibleMisconception = await this.identifyIslamicMisconception(message.text);
          
          if (possibleMisconception.isMisconception) {
            messageType = 'misconception';
            confidenceScore = possibleMisconception.confidence;
            
            // Generate a suggested response addressing the misconception
            if (possibleMisconception.misconceptionId) {
              try {
                const misconceptionResponse = islamicDawahService.getMisconceptionResponse(
                  possibleMisconception.misconceptionId
                );
                
                if (misconceptionResponse) {
                  suggestedResponse = misconceptionResponse.correction;
                }
              } catch (error) {
                console.error('Error getting misconception response:', error);
              }
            }
          }
        }
        
        // Look for general interest in Islamic topics
        if (!messageType) {
          const interestAnalysis = await this.analyzeIslamicInterest(message.text);
          
          if (interestAnalysis.showsInterest) {
            messageType = 'interest';
            confidenceScore = interestAnalysis.confidence;
            
            // Generate a suggested response based on the interest
            try {
              suggestedResponse = await this.generateEngagingResponse(message.text);
            } catch (error) {
              console.error('Error generating engaging response:', error);
            }
          }
        }
        
        // Add to opportunities if a type was identified
        if (messageType) {
          opportunities.push({
            messageId: message.ts,
            messageText: message.text,
            type: messageType,
            suggestedResponse,
            confidenceScore
          });
        }
      }
      
      return {
        success: true,
        opportunities
      };
      
    } catch (error) {
      console.error('Error analyzing dawah opportunities:', error);
      return {
        success: false,
        error: `Failed to analyze dawah opportunities: ${error.message}`
      };
    }
  }
  
  /**
   * Generate a weekly dawah report with analytics
   */
  async generateDawahReport(platform: string, options: {
    channelId?: string;
    daysPeriod?: number;
    includeContentSuggestions?: boolean;
  } = {}): Promise<{
    success: boolean;
    report?: {
      period: {
        start: string;
        end: string;
      };
      analytics: {
        totalMessages: number;
        islamicContentPercentage: number;
        questions: number;
        topTopics: Array<{topic: string, count: number}>;
        potentialInterests: number;
      };
      contentSuggestions?: string[];
    };
    error?: string;
  }> {
    try {
      // Get recent activities
      const recentActivity = await this.getRecentActivity(platform, {
        channelId: options.channelId,
        limit: options.daysPeriod ? options.daysPeriod * 50 : 100 // Approximate limits
      });
      
      if (!recentActivity.success || !recentActivity.messages) {
        return {
          success: false,
          error: recentActivity.error || 'Failed to retrieve recent activity'
        };
      }
      
      // Analyze messages
      const messages = recentActivity.messages;
      const now = new Date();
      const startDate = new Date();
      startDate.setDate(now.getDate() - (options.daysPeriod || 7));
      
      let islamicContentCount = 0;
      let questionsCount = 0;
      let potentialInterestsCount = 0;
      const topics: Record<string, number> = {};
      
      for (const message of messages) {
        if (!message.text || message.bot_id) continue; // Skip empty messages or bot messages
        
        // Check if message is Islamic
        const islamicCheck = await islamicContentDetector.detectIslamicContent(message.text);
        if (islamicCheck.isIslamic) {
          islamicContentCount++;
          
          // Track topics
          for (const category of islamicCheck.categories || []) {
            topics[category] = (topics[category] || 0) + 1;
          }
        }
        
        // Count questions
        if (message.text.includes('?')) {
          const isIslamicQuestion = await this.isIslamicQuestion(message.text);
          if (isIslamicQuestion.isIslamic) {
            questionsCount++;
          }
        }
        
        // Count potential interests
        const interestAnalysis = await this.analyzeIslamicInterest(message.text);
        if (interestAnalysis.showsInterest) {
          potentialInterestsCount++;
        }
      }
      
      // Generate content suggestions if requested
      let contentSuggestions;
      if (options.includeContentSuggestions) {
        // Get top topics
        const topicEntries = Object.entries(topics);
        const topTopics = topicEntries.length > 0 
          ? topicEntries.sort((a, b) => b[1] - a[1]).slice(0, 3).map(entry => entry[0])
          : ['general_islam', 'islamic_practices', 'quran'];
        
        contentSuggestions = await this.generateContentSuggestions(topTopics);
      }
      
      // Sort topics for report
      const topTopicsArray = Object.entries(topics)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([topic, count]) => ({ topic, count }));
      
      const report = {
        period: {
          start: startDate.toISOString(),
          end: now.toISOString()
        },
        analytics: {
          totalMessages: messages.length,
          islamicContentPercentage: messages.length > 0 
            ? (islamicContentCount / messages.length) * 100 
            : 0,
          questions: questionsCount,
          topTopics: topTopicsArray,
          potentialInterests: potentialInterestsCount
        }
      };
      
      if (contentSuggestions) {
        return {
          success: true,
          report: { ...report, contentSuggestions }
        };
      }
      
      return {
        success: true,
        report
      };
      
    } catch (error) {
      console.error('Error generating dawah report:', error);
      return {
        success: false,
        error: `Failed to generate dawah report: ${error.message}`
      };
    }
  }
  
  /**
   * Respond to a message on social media with Islamic guidance
   */
  async respondToMessage(
    platform: string,
    messageId: string,
    responseText: string,
    options: {
      channelId?: string;
      attachments?: any[];
    } = {}
  ): Promise<{
    success: boolean;
    responseId?: string;
    error?: string;
  }> {
    try {
      // Verify the response text is appropriate
      const contentCheck = await islamicContentDetector.detectIslamicContent(responseText);
      
      if (!contentCheck.isIslamic) {
        return {
          success: false,
          error: 'Response is not sufficiently Islamic or does not contain Islamic themes.'
        };
      }
      
      // Check for prohibited content
      const hasProhibited = await filterService.containsProhibitedContent(responseText, 'auto');
      if (hasProhibited) {
        return {
          success: false,
          error: 'Response contains prohibited material according to Islamic guidelines.'
        };
      }
      
      // Add respectful phrases if needed
      let enhancedResponse = responseText;
      if (contentCheck.containsProphetMention && !contentCheck.containsRespectfulPhrases) {
        enhancedResponse = await islamicContentDetector.enhanceWithRespectfulPhrases(responseText);
      }
      
      // Post to appropriate platform
      switch (platform.toLowerCase()) {
        case 'slack':
          if (!this.slack) {
            return {
              success: false,
              error: 'Slack connection not available. Please provide SLACK_BOT_TOKEN.'
            };
          }
          
          const channelId = options.channelId || process.env.SLACK_CHANNEL_ID;
          if (!channelId) {
            return {
              success: false,
              error: 'No Slack channel ID provided. Please set SLACK_CHANNEL_ID environment variable or provide channelId in options.'
            };
          }
          
          const slackResponse = await this.slack.chat.postMessage({
            channel: channelId,
            text: enhancedResponse,
            thread_ts: messageId, // Reply in thread
            unfurl_links: true,
            unfurl_media: true
          });
          
          // Add contact to dawah tracking if success
          if (slackResponse.ok) {
            try {
              // Track interaction for dawah statistics
              await this.trackDawahInteraction(
                platform,
                messageId,
                enhancedResponse,
                'response'
              );
            } catch (innerError) {
              console.error('Error tracking dawah interaction:', innerError);
              // Continue anyway as the main operation succeeded
            }
          }
          
          return {
            success: slackResponse.ok,
            responseId: slackResponse.ts as string,
            error: slackResponse.error
          };
          
        // Other platform implementations would be added here
        default:
          return {
            success: false,
            error: `Platform ${platform} is not supported or connection not available.`
          };
      }
    } catch (error) {
      console.error('Error responding to message:', error);
      return {
        success: false,
        error: `Failed to respond: ${error.message}`
      };
    }
  }
  
  /**
   * Schedule Islamic content for posting at specific times
   */
  async scheduleContent(
    platform: string,
    content: string,
    scheduledTime: Date,
    options: {
      channelId?: string;
      contentType?: 'dawah' | 'educational' | 'news' | 'reminder';
      recurring?: 'daily' | 'weekly' | 'monthly';
    } = {}
  ): Promise<{
    success: boolean;
    scheduleId?: string;
    error?: string;
  }> {
    try {
      // Verify the content is appropriate
      const contentCheck = await islamicContentDetector.detectIslamicContent(content);
      
      if (!contentCheck.isIslamic) {
        return {
          success: false,
          error: 'Content is not sufficiently Islamic or does not contain Islamic themes.'
        };
      }
      
      // Check for prohibited content
      const hasProhibited = await filterService.containsProhibitedContent(content, 'auto');
      if (hasProhibited) {
        return {
          success: false,
          error: 'Content contains prohibited material according to Islamic guidelines.'
        };
      }
      
      // Add respectful phrases if needed
      let enhancedContent = content;
      if (contentCheck.containsProphetMention && !contentCheck.containsRespectfulPhrases) {
        enhancedContent = await islamicContentDetector.enhanceWithRespectfulPhrases(content);
      }
      
      // Schedule on appropriate platform
      switch (platform.toLowerCase()) {
        case 'slack':
          if (!this.slack) {
            return {
              success: false,
              error: 'Slack connection not available. Please provide SLACK_BOT_TOKEN.'
            };
          }
          
          const channelId = options.channelId || process.env.SLACK_CHANNEL_ID;
          if (!channelId) {
            return {
              success: false,
              error: 'No Slack channel ID provided. Please set SLACK_CHANNEL_ID environment variable or provide channelId in options.'
            };
          }
          
          // Slack has a different API for scheduling messages
          const slackSchedule = await this.slack.chat.scheduleMessage({
            channel: channelId,
            text: enhancedContent,
            post_at: Math.floor(scheduledTime.getTime() / 1000) // Convert to Unix timestamp
          });
          
          return {
            success: slackSchedule.ok,
            scheduleId: slackSchedule.scheduled_message_id as string,
            error: slackSchedule.error
          };
          
        // Other platform implementations would be added here
        default:
          return {
            success: false,
            error: `Platform ${platform} is not supported or connection not available.`
          };
      }
    } catch (error) {
      console.error('Error scheduling content:', error);
      return {
        success: false,
        error: `Failed to schedule content: ${error.message}`
      };
    }
  }
  
  /**
   * Track interaction for dawah statistics
   */
  private async trackDawahInteraction(
    platform: string,
    messageId: string,
    content: string,
    type: 'response' | 'question' | 'interest'
  ): Promise<void> {
    try {
      // Get user info from message if available
      let username = 'unknown_user';
      let source = `${platform}_${type}`;
      
      if (platform === 'slack' && this.slack) {
        try {
          // In real implementation, would retrieve user info 
          // and create a proper dawah contact record
          username = `slack_user_${messageId.split('.')[0]}`;
        } catch (error) {
          console.error('Error getting slack user info:', error);
        }
      }
      
      // Add as contact to dawah tracking
      const contactId = await islamicDawahService.addContact(
        username,
        source
      );
      
      // Add interaction based on type
      if (type === 'response') {
        await islamicDawahService.addInteraction(
          contactId,
          'question_answered',
          'faith_question',
          content.substring(0, 100) // Summary
        );
      } else if (type === 'question') {
        await islamicDawahService.addInteraction(
          contactId,
          'faith_question',
          'faith_inquiry',
          content.substring(0, 100) // Summary
        );
      } else {
        await islamicDawahService.addInteraction(
          contactId,
          'potential_interest',
          'faith_exploration',
          content.substring(0, 100) // Summary
        );
      }
    } catch (error) {
      console.error('Error tracking dawah interaction:', error);
      // Non-critical failure, log and continue
    }
  }
  
  /**
   * Check if a message contains a question about Islam
   */
  private async isIslamicQuestion(text: string): Promise<{
    isIslamic: boolean;
    confidence: number;
    questionType?: string;
  }> {
    try {
      // Basic check - must contain a question mark and some Islamic terms
      const hasQuestionMark = text.includes('?');
      const islamicCheck = await islamicContentDetector.detectIslamicContent(text);
      
      if (!hasQuestionMark) {
        return {
          isIslamic: false,
          confidence: 0
        };
      }
      
      // If already contains Islamic content, high confidence
      if (islamicCheck.isIslamic) {
        return {
          isIslamic: true,
          confidence: islamicCheck.confidence || 0.8,
          questionType: islamicCheck.categories?.[0]
        };
      }
      
      // Check for question phrases about religion
      const religiousQuestionIndicators = [
        'what does islam', 'why do muslims', 'how do muslims',
        'is it true that islam', 'does the quran', 'who is muhammad',
        'what is the purpose', 'how does islam view', 'is it allowed in islam',
        'what happens after death', 'what does god', 'who is allah'
      ];
      
      const lowerText = text.toLowerCase();
      
      for (const indicator of religiousQuestionIndicators) {
        if (lowerText.includes(indicator)) {
          return {
            isIslamic: true,
            confidence: 0.7,
            questionType: 'general_inquiry'
          };
        }
      }
      
      // Low confidence fallback
      return {
        isIslamic: false,
        confidence: 0.1
      };
    } catch (error) {
      console.error('Error checking Islamic question:', error);
      return {
        isIslamic: false,
        confidence: 0
      };
    }
  }
  
  /**
   * Identify if a message contains common misconceptions about Islam
   */
  private async identifyIslamicMisconception(text: string): Promise<{
    isMisconception: boolean;
    confidence: number;
    misconceptionId?: string;
  }> {
    try {
      // Common misconception phrases to check for
      const misconceptionPhrases = [
        { id: 'islam_violence', phrases: ['islam promotes violence', 'islam is violent', 'muslims are terrorists'] },
        { id: 'women_rights', phrases: ['islam oppresses women', 'women have no rights in islam', 'muslim women are forced'] },
        { id: 'jihad_misunderstood', phrases: ['jihad means holy war', 'muslims want jihad', 'violent jihad'] },
        { id: 'islam_science', phrases: ['islam is against science', 'muslims reject science', 'science contradicts islam'] }
      ];
      
      const lowerText = text.toLowerCase();
      
      for (const misconception of misconceptionPhrases) {
        for (const phrase of misconception.phrases) {
          if (lowerText.includes(phrase)) {
            return {
              isMisconception: true,
              confidence: 0.85,
              misconceptionId: misconception.id
            };
          }
        }
      }
      
      // More complex analysis using AI could be implemented here
      // for subtler misconceptions
      
      return {
        isMisconception: false,
        confidence: 0
      };
    } catch (error) {
      console.error('Error identifying Islamic misconception:', error);
      return {
        isMisconception: false,
        confidence: 0
      };
    }
  }
  
  /**
   * Analyze if a message shows interest in Islamic topics
   */
  private async analyzeIslamicInterest(text: string): Promise<{
    showsInterest: boolean;
    confidence: number;
    topics?: string[];
  }> {
    try {
      // Keywords indicating possible interest
      const interestKeywords = [
        'interested in islam', 'learning about islam', 'curious about',
        'want to know more', 'tell me about islam', 'islam interests me',
        'considering conversion', 'thinking about converting', 'difference between',
        'comparing religions', 'spiritual journey', 'seeking truth'
      ];
      
      const lowerText = text.toLowerCase();
      
      // Check for direct interest phrases
      for (const keyword of interestKeywords) {
        if (lowerText.includes(keyword)) {
          return {
            showsInterest: true,
            confidence: 0.9,
            topics: ['general_interest']
          };
        }
      }
      
      // Check if text contains Islamic content but not questions or misconceptions
      const islamicCheck = await islamicContentDetector.detectIslamicContent(text);
      if (islamicCheck.isIslamic && !text.includes('?')) {
        return {
          showsInterest: true,
          confidence: islamicCheck.confidence || 0.65,
          topics: islamicCheck.categories
        };
      }
      
      // Default response
      return {
        showsInterest: false,
        confidence: 0
      };
    } catch (error) {
      console.error('Error analyzing Islamic interest:', error);
      return {
        showsInterest: false,
        confidence: 0
      };
    }
  }
  
  /**
   * Generate an engaging response to encourage Islamic dialogue
   */
  private async generateEngagingResponse(text: string): Promise<string> {
    try {
      // Default template responses based on different scenarios
      const generalTemplate = 'Thank you for your interest in Islam. The topic of {TOPIC} is fascinating in Islamic teachings. Would you like to know more about specific aspects of this?';
      
      // Identify topics in the message
      const islamicCheck = await islamicContentDetector.detectIslamicContent(text);
      
      if (islamicCheck.isIslamic && islamicCheck.categories && islamicCheck.categories.length > 0) {
        const topic = islamicCheck.categories[0].replace(/_/g, ' ');
        return generalTemplate.replace('{TOPIC}', topic);
      }
      
      // If no clear Islamic content, use a more general response
      return 'Thank you for your message. If you\'re interested in learning more about Islamic teachings on this or other topics, I\'d be happy to share more information.';
    } catch (error) {
      console.error('Error generating engaging response:', error);
      return 'Thank you for your message. I\'d be happy to discuss Islamic perspectives on this topic further if you\'re interested.';
    }
  }
  
  /**
   * Generate content suggestions based on popular topics
   */
  private async generateContentSuggestions(topics: string[]): Promise<string[]> {
    try {
      // Default suggestions for common topics
      const defaultSuggestions: Record<string, string[]> = {
        'general_islam': [
          'The Five Pillars of Islam: A Foundation for Daily Life',
          'Understanding Tawhid: The Central Concept of Islamic Monotheism',
          'Islam and Modern Life: Balancing Faith and Contemporary Challenges'
        ],
        'islamic_practices': [
          'The Spiritual Benefits of Salah (Prayer) in Daily Life',
          'Ramadan: More Than Just Fasting - A Month of Spiritual Growth',
          'Zakat: How Islamic Charity Creates Social Balance'
        ],
        'quran': [
          'Exploring the Scientific Miracles in the Quran',
          'The Linguistic Beauty of the Quran: Even in Translation',
          'How the Quran Provides Guidance for Modern Ethical Dilemmas'
        ],
        'islamic_history': [
          'The Golden Age of Islamic Civilization: Contributions to Science and Medicine',
          'Stories of the Prophet Muhammad ﷺ: Lessons in Compassion and Leadership',
          'Early Muslim Scholars and Their Impact on Global Knowledge'
        ]
      };
      
      const suggestions: string[] = [];
      
      // Add suggestions based on provided topics
      for (const topic of topics) {
        const formattedTopic = topic.replace(/_/g, ' ');
        
        if (defaultSuggestions[topic]) {
          // Add from default suggestions if available
          suggestions.push(...defaultSuggestions[topic]);
        } else {
          // Generate generic suggestions if not in defaults
          suggestions.push(
            `Understanding ${formattedTopic} in Islamic Perspective`,
            `How ${formattedTopic} Relates to Islamic Teachings`,
            `Exploring ${formattedTopic}: An Islamic Approach`
          );
        }
      }
      
      // Return unique suggestions, max 5
      return [...new Set(suggestions)].slice(0, 5);
    } catch (error) {
      console.error('Error generating content suggestions:', error);
      return [
        'Understanding the Basics of Islam',
        'The Five Pillars of Islam Explained',
        'Scientific Miracles in the Quran',
        'Stories from the Life of Prophet Muhammad ﷺ',
        'Common Misconceptions about Islam Addressed'
      ];
    }
  }
}

export const socialMediaManagerService = new SocialMediaManagerService();