import { speechToTextRequestSchema, textToSpeechRequestSchema } from "@shared/schema";
import { storage } from "../storage";
import { translationService } from "./translation";
import { openaiService } from "./openai";

// Enhanced speech service with voice morphing and Islamic context recognition
export class SpeechService {
  // Voice morphing and cultural adaptation settings
  private voiceProfiles = {
    // Different voice profiles for various cultural contexts
    'standard': {
      pitch: 1.0,
      rate: 1.0,
      gender: 'NEUTRAL'
    },
    'elder': {
      pitch: 0.85,
      rate: 0.9,
      gender: 'NEUTRAL'
    },
    'scholar': {
      pitch: 0.95,
      rate: 0.95,
      gender: 'MALE'
    },
    'child': {
      pitch: 1.3,
      rate: 1.1,
      gender: 'NEUTRAL'
    },
    'reciter': {
      pitch: 0.9,
      rate: 0.85,
      gender: 'MALE'
    }
  };

  // Islamic expressions and common phrases for different languages
  private islamicExpressions = {
    'ar': {
      'greeting': 'السلام عليكم',
      'farewell': 'في أمان الله',
      'thanks': 'جزاك الله خيراً',
      'prayer': 'بارك الله فيك',
      'blessing': 'بسم الله الرحمن الرحيم'
    },
    'en': {
      'greeting': 'Assalamu alaikum',
      'farewell': 'May Allah protect you',
      'thanks': 'May Allah reward you with goodness',
      'prayer': 'May Allah bless you',
      'blessing': 'In the name of Allah, the Most Gracious, the Most Merciful'
    }
  };

  // Convert speech to text with contextual awareness and OpenAI
  async speechToText(audioData: string, sourceLanguage: string) {
    try {
      // Validate request
      const validatedData = speechToTextRequestSchema.parse({
        audioData,
        sourceLanguage
      });
      
      // In a real implementation with OpenAI Whisper integration, we would do:
      // 1. Convert the base64 audio data to a file buffer
      // 2. Make an API call to OpenAI Whisper for transcription
      // 3. Process the returned text
      
      // For now, we'll use our simulation for demo purposes
      let recognizedText = this.simulateSpeechToText(audioData, sourceLanguage);
      
      // Use OpenAI to analyze and enhance the recognized text
      try {
        // Analyze the cultural context to understand the speech better
        const contextAnalysis = await openaiService.analyzeCulturalContext(recognizedText, sourceLanguage);
        
        // If we detect religious content, apply special handling
        if (contextAnalysis.religiousContext) {
          console.log("Religious content detected in speech, applying special handling");
          
          // If the content is religious, ensure proper Islamic terminology
          recognizedText = await openaiService.enhanceTranslation(
            recognizedText,
            sourceLanguage,
            sourceLanguage, // Same language, just enhancing not translating
            true // Preserve Islamic terms
          );
        }
      } catch (error) {
        console.error("OpenAI speech enhancement error:", error);
        // Continue with basic enhancement if OpenAI call fails
      }
      
      // Enhance recognition with Islamic context (our local enhancer as backup)
      recognizedText = this.enhanceWithIslamicContext(recognizedText, sourceLanguage);
      
      // Check for Islamic compliance and filter if needed
      const complianceCheck = await openaiService.analyzeContentForFiltering(recognizedText, sourceLanguage);
      if (complianceCheck.containsProhibitedContent) {
        console.log("Non-compliant content detected in speech, applying filters");
        recognizedText = complianceCheck.filteredText;
      }
      
      // Update stats
      await storage.updateStats({
        textTranslations: 0,
        voiceTranslations: 1,
        imageTranslations: 0,
        totalCharacters: recognizedText.length,
        languageStats: {
          [sourceLanguage]: 1
        }
      });
      
      return { 
        recognizedText,
        categories: complianceCheck.containsProhibitedContent ? complianceCheck.categories : [] 
      };
    } catch (error) {
      console.error("Speech-to-text error:", error);
      throw new Error("Failed to recognize speech");
    }
  }
  
  // Convert text to speech with voice morphing and content-aware adjustments
  async textToSpeech(text: string, language: string, voiceGender = "FEMALE", voiceSpeed = 1) {
    try {
      // Validate request
      const validatedData = textToSpeechRequestSchema.parse({
        text,
        language,
        voiceGender,
        voiceSpeed
      });
      
      // Check for Islamic compliance and filter if needed
      const complianceCheck = await openaiService.analyzeContentForFiltering(validatedData.text, validatedData.language);
      let textToProcess = validatedData.text;
      
      if (complianceCheck.containsProhibitedContent) {
        console.log("Non-compliant content detected, applying filters before text-to-speech");
        textToProcess = complianceCheck.filteredText;
      }
      
      // Analyze cultural context to determine the appropriate voice modulation
      let voiceProfile = this.voiceProfiles.standard;
      try {
        const contextAnalysis = await openaiService.analyzeCulturalContext(textToProcess, language);
        
        // Use the context analysis to select an appropriate voice profile
        if (contextAnalysis.religiousContext) {
          // For religious content, use reciter or scholar profile based on formality
          if (contextAnalysis.formalityLevel === "formal") {
            voiceProfile = this.voiceProfiles.reciter;
            console.log("Using reciter voice profile for religious formal content");
          } else {
            voiceProfile = this.voiceProfiles.scholar;
            console.log("Using scholar voice profile for religious content");
          }
        } else if (contextAnalysis.formalityLevel === "informal" && textToProcess.length < 100) {
          // For short, informal content, consider child-friendly voice
          voiceProfile = this.voiceProfiles.child;
          console.log("Using child-friendly voice profile for informal content");
        } else if (contextAnalysis.formalityLevel === "formal") {
          // For formal non-religious content
          voiceProfile = this.voiceProfiles.elder;
          console.log("Using elder voice profile for formal content");
        }
      } catch (error) {
        console.error("OpenAI context analysis error:", error);
        // Fall back to basic voice profile detection
        voiceProfile = this.detectAppropriateVoiceProfile(textToProcess, language);
      }
      
      // Apply voice parameters based on profile and user preferences
      const morphedVoiceGender = voiceGender === "AUTO" ? voiceProfile.gender : voiceGender;
      const adjustedSpeed = voiceSpeed * voiceProfile.rate;
      const adjustedPitch = voiceProfile.pitch;
      
      // For Quranic content, ensure proper tajweed-friendly settings
      if (language === 'ar' && (
        textToProcess.includes('بسم الله الرحمن الرحيم') || 
        textToProcess.includes('قال الله') ||
        textToProcess.includes('سورة')
      )) {
        console.log("Quranic content detected, using special recitation settings");
        // Special settings for Quranic recitation
        voiceProfile = this.voiceProfiles.reciter;
      }
      
      // In a real implementation, this would call a text-to-speech API
      // For now, we'll return a placeholder audio data
      const audioData = this.simulateTextToSpeech(
        textToProcess, 
        language, 
        morphedVoiceGender, 
        adjustedSpeed
      );
      
      return { 
        audioData,
        voiceProfile: voiceProfile,
        contentType: complianceCheck.containsProhibitedContent ? "filtered" : "original",
        isIslamicCompliant: !complianceCheck.containsProhibitedContent
      };
    } catch (error) {
      console.error("Text-to-speech error:", error);
      throw new Error("Failed to synthesize speech");
    }
  }
  
  // Detect appropriate voice profile based on content
  private detectAppropriateVoiceProfile(text: string, language: string) {
    // Default profile
    let profile = this.voiceProfiles.standard;
    
    // Content-based voice profile detection
    if (language === 'ar' || language === 'en') {
      // Check for Quranic verses or religious content
      if (
        (language === 'ar' && (
          text.includes('قال الله') || 
          text.includes('قال تعالى') || 
          text.includes('قال رسول الله')
        )) || 
        (language === 'en' && (
          text.includes('Allah says') || 
          text.includes('The Prophet said') || 
          text.includes('In the Quran')
        ))
      ) {
        profile = this.voiceProfiles.reciter;
      }
      // Check for scholarly content
      else if (
        (language === 'ar' && (
          text.includes('قال العلماء') || 
          text.includes('في الفقه') || 
          text.includes('أجمع العلماء')
        )) || 
        (language === 'en' && (
          text.includes('scholars say') || 
          text.includes('in Islamic jurisprudence') || 
          text.includes('consensus of scholars')
        ))
      ) {
        profile = this.voiceProfiles.scholar;
      }
      // Check for children's content
      else if (
        text.length < 50 && (
          (language === 'ar' && (
            text.includes('يا أطفال') || 
            text.includes('للصغار')
          )) || 
          (language === 'en' && (
            text.includes('for kids') || 
            text.includes('children')
          ))
        )
      ) {
        profile = this.voiceProfiles.child;
      }
    }
    
    return profile;
  }
  
  // Enhance recognition with Islamic context
  private enhanceWithIslamicContext(text: string, language: string): string {
    // Get expressions for the language (default to English if not found)
    const expressions = language === 'ar' ? 
      this.islamicExpressions.ar : 
      this.islamicExpressions.en;
    
    let enhancedText = text;
    
    // Replace common greetings with Islamic expressions
    if (language === 'ar') {
      if (text.includes('مرحبا') || text.includes('أهلا')) {
        enhancedText = enhancedText.replace(/مرحبا|أهلا/gi, expressions.greeting);
      }
      if (text.includes('شكرا')) {
        enhancedText = enhancedText.replace(/شكرا/gi, expressions.thanks);
      }
    } else if (language === 'en') {
      if (text.includes('hello') || text.includes('hi')) {
        enhancedText = enhancedText.replace(/hello|hi/gi, expressions.greeting);
      }
      if (text.includes('thank you') || text.includes('thanks')) {
        enhancedText = enhancedText.replace(/thank you|thanks/gi, expressions.thanks);
      }
    }
    
    return enhancedText;
  }
  
  // Simulate speech-to-text for development purposes
  private simulateSpeechToText(audioData: string, language: string): string {
    // This is only for demonstration purposes
    // In a real app, this would be replaced with actual API calls
    
    if (language === 'ar') {
      return "مرحباً، كيف يمكنني مساعدتك اليوم؟";
    } else if (language === 'en') {
      return "Hello, how can I help you today?";
    }
    
    return `This is a simulated speech recognition for language code: ${language}`;
  }
  
  // Simulate text-to-speech for development purposes
  private simulateTextToSpeech(text: string, language: string, voiceGender: string, voiceSpeed: number): string {
    // This is only for demonstration purposes
    // In a real app, this would return actual audio data
    
    // Return a base64 placeholder
    return "data:audio/wav;base64,UExBQ0VIT0xERVJfQVVESU9fREFUQQ==";
  }
}

export const speechService = new SpeechService();
