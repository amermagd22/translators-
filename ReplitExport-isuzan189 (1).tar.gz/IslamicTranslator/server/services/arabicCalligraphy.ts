// Service for generating and styling Arabic calligraphy and Islamic designs
export class ArabicCalligraphyService {
  // Supported calligraphy styles
  private calligraphyStyles = [
    {
      id: 'naskh',
      name: 'النسخ',
      nameEn: 'Naskh',
      description: 'Clear, legible script commonly used for Quran and everyday writing',
      isQuranStyle: true,
      fontFamily: 'Amiri, serif',
      cssClass: 'naskh-style'
    },
    {
      id: 'diwani',
      name: 'الديواني',
      nameEn: 'Diwani',
      description: 'Ornate, flowing script developed during Ottoman Empire',
      isQuranStyle: false,
      fontFamily: 'Diwani, serif',
      cssClass: 'diwani-style'
    },
    {
      id: 'thuluth',
      name: 'الثلث',
      nameEn: 'Thuluth',
      description: 'Majestic script with flowing curves, often used for mosque inscriptions',
      isQuranStyle: true,
      fontFamily: 'Aref Ruqaa, serif',
      cssClass: 'thuluth-style'
    },
    {
      id: 'kufi',
      name: 'الكوفي',
      nameEn: 'Kufi',
      description: 'Geometric, angular script, one of the oldest forms',
      isQuranStyle: true,
      fontFamily: 'Reem Kufi, sans-serif',
      cssClass: 'kufi-style'
    },
    {
      id: 'maghribi',
      name: 'المغربي',
      nameEn: 'Maghribi',
      description: 'North African style with distinctive loops and curves',
      isQuranStyle: false,
      fontFamily: 'Scheherazade, serif',
      cssClass: 'maghribi-style'
    },
    {
      id: 'ruqaa',
      name: 'الرقعة',
      nameEn: 'Ruqaa',
      description: 'Practical everyday handwriting script, compact and efficient',
      isQuranStyle: false,
      fontFamily: 'Lateef, serif',
      cssClass: 'ruqaa-style'
    }
  ];

  // Islamic decorative elements for borders and backgrounds
  private decorativeElements = [
    {
      id: 'geometric',
      name: 'هندسي',
      nameEn: 'Geometric Pattern',
      description: 'Regular, repeating geometric designs',
      cssClass: 'geometric-pattern'
    },
    {
      id: 'arabesque',
      name: 'أرابيسك',
      nameEn: 'Arabesque',
      description: 'Flowing, intertwined patterns based on plants and vines',
      cssClass: 'arabesque-pattern'
    },
    {
      id: 'illumination',
      name: 'تذهيب',
      nameEn: 'Illumination',
      description: 'Gold and colors highlight important text, often for Quran',
      cssClass: 'illumination-pattern'
    },
    {
      id: 'border',
      name: 'إطار زخرفي',
      nameEn: 'Decorative Border',
      description: 'Intricate borders surrounding the main text',
      cssClass: 'decorative-border'
    }
  ];

  // Color palettes for Islamic art
  private colorPalettes = [
    {
      id: 'traditional',
      name: 'تقليدي',
      nameEn: 'Traditional',
      colors: ['#225c73', '#c33323', '#f0c75e', '#4a773b', '#7d633f']
    },
    {
      id: 'ottoman',
      name: 'عثماني',
      nameEn: 'Ottoman',
      colors: ['#11739e', '#c33a32', '#f4b842', '#39702a', '#522828']
    },
    {
      id: 'andalusian',
      name: 'أندلسي',
      nameEn: 'Andalusian',
      colors: ['#0a6f7d', '#b32e37', '#e1a01a', '#53713a', '#624a2d']
    },
    {
      id: 'persian',
      name: 'فارسي',
      nameEn: 'Persian',
      colors: ['#0f71aa', '#c93756', '#ffb546', '#5b9547', '#783a27']
    },
    {
      id: 'modern',
      name: 'عصري',
      nameEn: 'Modern',
      colors: ['#055a8c', '#bc2b3d', '#eaa822', '#3d8030', '#58473f']
    }
  ];

  // Generate CSS for the calligraphy style
  generateCalligraphyCSS(
    style: string,
    options: {
      fontSize?: string;
      fontWeight?: string;
      color?: string;
      backgroundColor?: string;
      lineHeight?: string;
      direction?: 'rtl' | 'ltr';
      textAlign?: 'right' | 'left' | 'center';
      letterSpacing?: string;
    } = {}
  ): string {
    // Find the selected style
    const styleInfo = this.calligraphyStyles.find(s => s.id === style) || this.calligraphyStyles[0];
    
    // Default options
    const defaults = {
      fontSize: '2rem',
      fontWeight: 'normal',
      color: '#000',
      backgroundColor: 'transparent',
      lineHeight: '1.5',
      direction: 'rtl' as const,
      textAlign: 'right' as const,
      letterSpacing: 'normal'
    };
    
    // Merge with provided options
    const settings = { ...defaults, ...options };
    
    // Generate CSS
    return `
.${styleInfo.cssClass} {
  font-family: ${styleInfo.fontFamily};
  font-size: ${settings.fontSize};
  font-weight: ${settings.fontWeight};
  color: ${settings.color};
  background-color: ${settings.backgroundColor};
  line-height: ${settings.lineHeight};
  direction: ${settings.direction};
  text-align: ${settings.textAlign};
  letter-spacing: ${settings.letterSpacing};
}`;
  }

  // Generate HTML for styled Arabic text
  generateStyledHTML(
    text: string,
    style: string,
    decorations: string[] = [],
    colorPalette: string = 'traditional',
    options: {
      includeBismillah?: boolean;
      includeFrame?: boolean;
      includeBackground?: boolean;
      textSize?: 'small' | 'medium' | 'large';
      alignment?: 'right' | 'center' | 'left';
    } = {}
  ): string {
    // Find the selected style
    const styleInfo = this.calligraphyStyles.find(s => s.id === style) || this.calligraphyStyles[0];
    
    // Get decorative elements
    const decorationElements = decorations.map(d => this.decorativeElements.find(de => de.id === d))
                                        .filter(Boolean);
    
    // Get color palette
    const palette = this.colorPalettes.find(p => p.id === colorPalette) || this.colorPalettes[0];
    
    // Default options
    const defaults = {
      includeBismillah: false,
      includeFrame: false,
      includeBackground: false,
      textSize: 'medium' as const,
      alignment: 'right' as const
    };
    
    // Merge with provided options
    const settings = { ...defaults, ...options };
    
    // Determine text size based on setting
    let fontSize = '2rem';
    if (settings.textSize === 'small') fontSize = '1.5rem';
    if (settings.textSize === 'large') fontSize = '3rem';
    
    // Prepare HTML
    let htmlContent = `<div class="calligraphy-container ${styleInfo.cssClass}`;
    
    // Add decoration classes
    for (const decoration of decorationElements) {
      if (decoration) htmlContent += ` ${decoration.cssClass}`;
    }
    
    // Close opening div
    htmlContent += `" style="font-family: ${styleInfo.fontFamily}; font-size: ${fontSize}; direction: rtl; text-align: ${settings.alignment}; color: ${palette.colors[0]}">`;
    
    // Add Bismillah if requested
    if (settings.includeBismillah) {
      htmlContent += `<div class="bismillah" style="margin-bottom: 1.5rem; text-align: center; color: ${palette.colors[1]}">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>`;
    }
    
    // Add frame if requested
    if (settings.includeFrame) {
      htmlContent += `<div class="frame" style="border: 3px solid ${palette.colors[2]}; padding: 2rem; border-radius: 10px;">`;
    }
    
    // Add background if requested
    if (settings.includeBackground) {
      htmlContent += `<div class="background" style="background-color: ${palette.colors[4]}20; padding: 1rem;">`;
    }
    
    // Add the main text
    htmlContent += `<div class="calligraphy-text">${text}</div>`;
    
    // Close the divs
    if (settings.includeBackground) htmlContent += `</div>`;
    if (settings.includeFrame) htmlContent += `</div>`;
    htmlContent += `</div>`;
    
    return htmlContent;
  }

  // Get available calligraphy styles
  getCalligraphyStyles(language: string = 'ar'): { id: string, name: string, description: string }[] {
    return this.calligraphyStyles.map(style => ({
      id: style.id,
      name: language === 'ar' ? style.name : style.nameEn,
      description: style.description
    }));
  }

  // Get available decorative elements
  getDecorativeElements(language: string = 'ar'): { id: string, name: string, description: string }[] {
    return this.decorativeElements.map(element => ({
      id: element.id,
      name: language === 'ar' ? element.name : element.nameEn,
      description: element.description
    }));
  }

  // Get available color palettes
  getColorPalettes(language: string = 'ar'): { id: string, name: string, colors: string[] }[] {
    return this.colorPalettes.map(palette => ({
      id: palette.id,
      name: language === 'ar' ? palette.name : palette.nameEn,
      colors: palette.colors
    }));
  }

  // Generate SVG for Arabic calligraphy
  generateSVG(
    text: string,
    style: string,
    options: {
      width?: number;
      height?: number;
      backgroundColor?: string;
      foregroundColor?: string;
      decorativeElement?: string;
      useIllumination?: boolean;
    } = {}
  ): string {
    // Default options
    const defaults = {
      width: 500,
      height: 200,
      backgroundColor: 'white',
      foregroundColor: 'black',
      decorativeElement: 'none',
      useIllumination: false
    };
    
    // Merge with provided options
    const settings = { ...defaults, ...options };
    
    // Find the selected style
    const styleInfo = this.calligraphyStyles.find(s => s.id === style) || this.calligraphyStyles[0];
    
    // Basic SVG that displays the text
    // In a real implementation, this would use sophisticated SVG generation
    // based on the actual calligraphy rules for each style
    const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${settings.width}" height="${settings.height}" viewBox="0 0 ${settings.width} ${settings.height}">
  <rect width="100%" height="100%" fill="${settings.backgroundColor}" />
  <text x="50%" y="50%" font-family="${styleInfo.fontFamily}" font-size="32" text-anchor="middle" dominant-baseline="middle" fill="${settings.foregroundColor}" direction="rtl">${text}</text>
</svg>`;
    
    return svg;
  }

  // Check if text has potentially challenging characters for calligraphy
  validateTextForCalligraphy(text: string, style: string): {
    isValid: boolean;
    issues?: string[];
    suggestions?: string[];
  } {
    // Find the selected style
    const styleInfo = this.calligraphyStyles.find(s => s.id === style) || this.calligraphyStyles[0];
    
    const issues: string[] = [];
    const suggestions: string[] = [];
    
    // Check for non-Arabic characters (simplified)
    const nonArabicRegex = /[^\u0600-\u06FF\s0-9.,،:;?!'"()[\]{}\-_+=]/g;
    const nonArabicMatches = text.match(nonArabicRegex);
    
    if (nonArabicMatches && nonArabicMatches.length > 0) {
      issues.push('Text contains non-Arabic characters that may not display correctly');
      suggestions.push('Consider using only Arabic characters for best results');
    }
    
    // Check text length
    if (text.length > 100 && (style === 'thuluth' || style === 'diwani')) {
      issues.push(`The ${styleInfo.nameEn} style works best with shorter text`);
      suggestions.push('Consider using the Naskh or Ruqaa style for longer text');
    }
    
    return {
      isValid: issues.length === 0,
      issues: issues.length > 0 ? issues : undefined,
      suggestions: suggestions.length > 0 ? suggestions : undefined
    };
  }

  // Get CSS classes for all supported styles and decorations
  getAllCSSClasses(): string {
    let css = '';
    
    // Add styles for each calligraphy type
    for (const style of this.calligraphyStyles) {
      css += this.generateCalligraphyCSS(style.id);
    }
    
    // Add styles for decorative elements
    css += `
.geometric-pattern {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path d="M0,0 L20,20 M20,0 L0,20" stroke="rgba(0,0,0,0.1)" stroke-width="1"/></svg>');
  padding: 1rem;
}

.arabesque-pattern {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><path d="M10,10 Q20,0 30,10 T10,30" stroke="rgba(0,0,0,0.1)" stroke-width="1" fill="none"/></svg>');
  padding: 1rem;
}

.illumination-pattern {
  border: 5px solid rgba(218, 165, 32, 0.3);
  box-shadow: inset 0 0 10px rgba(218, 165, 32, 0.5);
  padding: 1rem;
}

.decorative-border {
  border: 10px solid transparent;
  border-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><rect width="40" height="40" fill="none" stroke="rgba(0,0,0,0.2)" stroke-width="1"/><path d="M0,0 L40,40 M40,0 L0,40" stroke="rgba(0,0,0,0.1)" stroke-width="1"/></svg>') 10;
  padding: 1rem;
}

.calligraphy-container {
  max-width: 100%;
  margin: 1rem auto;
  line-height: 1.6;
  overflow-wrap: break-word;
}
`;
    
    return css;
  }
}

export const arabicCalligraphyService = new ArabicCalligraphyService();