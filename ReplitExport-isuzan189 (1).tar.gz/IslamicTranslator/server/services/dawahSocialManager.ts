import { openaiService } from "./openai";
import { anthropicService } from "./anthropic";
import { islamicDawahService } from "./islamicDawah";
import { islamicContentDetector } from "./islamicContentDetector";

// Service for managing Islamic dawah on social media platforms
export class DawahSocialManagerService {
  // Supported social media platforms
  private platforms = [
    'facebook',
    'twitter',
    'instagram',
    'youtube',
    'tiktok',
    'telegram',
    'whatsapp'
  ];

  // Track connected social accounts
  private connectedAccounts: {
    id: string;
    userId: number;
    platform: string;
    username: string;
    accessToken?: string;
    refreshToken?: string;
    lastSyncDate: string;
    status: 'active' | 'paused' | 'error';
  }[] = [];

  // Track dawah conversations
  private conversations: {
    id: string;
    accountId: string;
    platform: string;
    participantId: string;
    participantUsername: string;
    startDate: string;
    lastMessageDate: string;
    messages: {
      id: string;
      sender: 'bot' | 'participant';
      content: string;
      date: string;
      contentAnalysis?: {
        topic?: string;
        sentiment?: string;
        isQuestion?: boolean;
        containsMisconception?: boolean;
      };
      responseStrategy?: string;
    }[];
    status: 'active' | 'interested' | 'converted' | 'inactive';
    topics: string[];
    engagementLevel: number; // 0-10 scale
  }[] = [];

  // Track campaign statistics
  private campaignStats: {
    totalMessages: number;
    repliesGenerated: number;
    positiveInteractions: number;
    neutralInteractions: number;
    negativeInteractions: number;
    questionsAnswered: number;
    misconceptionsCorrected: number;
    potentialConverts: number;
    activePlatforms: {[key: string]: number};
    topTopics: {[key: string]: number};
    platformEngagement: {[key: string]: number};
  } = {
    totalMessages: 0,
    repliesGenerated: 0,
    positiveInteractions: 0,
    neutralInteractions: 0,
    negativeInteractions: 0,
    questionsAnswered: 0,
    misconceptionsCorrected: 0,
    potentialConverts: 0,
    activePlatforms: {},
    topTopics: {},
    platformEngagement: {}
  };

  // Response templates for different platforms
  private responseTemplates = {
    facebook: {
      greeting: 'As-salamu alaykum! Thank you for your message. {message}',
      invite: 'If you have more questions about Islam, I\'d be happy to discuss further. {question}',
      shareResource: 'You might find this resource helpful: {resource}',
      correctMisconception: 'I noticed a common misconception in your comment. Let me clarify: {correction}'
    },
    twitter: {
      greeting: 'Salam! {message}',
      invite: 'Have questions about Islam? Feel free to ask! {hashtags}',
      shareResource: 'Check this out for more info: {resource} {hashtags}',
      correctMisconception: 'Actually, {correction} #IslamFacts'
    },
    instagram: {
      greeting: 'As-salamu alaykum! 🌙 {message}',
      invite: 'Feel free to DM for more information! {emoji}',
      shareResource: 'Learn more: {resource} {hashtags}',
      correctMisconception: 'A lot of people think that, but actually: {correction} {hashtags}'
    },
    youtube: {
      greeting: 'Thank you for your comment! {message}',
      invite: 'If you\'re interested in learning more about Islam, feel free to ask questions below.',
      shareResource: 'If you\'d like to explore this topic further, check out: {resource}',
      correctMisconception: 'Just to clarify about your point: {correction}'
    }
  };

  // Pre-approved dawah content for automatic sharing
  private approvedContent = [
    {
      id: 'quran_reflection',
      title: 'Daily Quranic Reflection',
      content: 'The Quran teaches us: "{verse}" - {reference}. Reflection: {reflection}',
      category: 'inspiration',
      approved: true,
      platforms: ['facebook', 'instagram', 'twitter']
    },
    {
      id: 'islamic_fact',
      title: 'Islamic Fact of the Day',
      content: 'Did you know? {fact} #Islam #Knowledge',
      category: 'education',
      approved: true,
      platforms: ['twitter', 'facebook', 'instagram']
    },
    {
      id: 'prophet_teaching',
      title: 'Teachings of Prophet Muhammad ﷺ',
      content: 'Prophet Muhammad ﷺ said: "{hadith}" - {reference}. This teaches us the importance of {lesson}.',
      category: 'education',
      approved: true,
      platforms: ['facebook', 'instagram', 'twitter', 'youtube']
    }
  ];

  // Hashtag sets for different platforms and topics
  private hashtagSets = {
    general: ['#Islam', '#Muslims', '#Faith'],
    science: ['#ScienceInIslam', '#QuranAndScience', '#IslamicScience'],
    history: ['#IslamicHistory', '#MuslimHeritage', '#IslamicCivilization'],
    spirituality: ['#IslamicSpirituality', '#Faith', '#Iman'],
    dawah: ['#LearnIslam', '#DiscoverIslam', '#IslamQA']
  };

  // Connect a social media account
  connectAccount(
    userId: number,
    platform: string,
    username: string,
    accessToken?: string,
    refreshToken?: string
  ): string {
    // Validate platform
    if (!this.platforms.includes(platform)) {
      throw new Error(`Unsupported platform: ${platform}`);
    }
    
    // Generate ID
    const id = `account_${Date.now()}`;
    
    // Add to connected accounts
    this.connectedAccounts.push({
      id,
      userId,
      platform,
      username,
      accessToken,
      refreshToken,
      lastSyncDate: new Date().toISOString(),
      status: 'active'
    });
    
    // Update statistics
    this.campaignStats.activePlatforms[platform] = (this.campaignStats.activePlatforms[platform] || 0) + 1;
    
    return id;
  }

  // Disconnect a social media account
  disconnectAccount(accountId: string): boolean {
    const accountIndex = this.connectedAccounts.findIndex(account => account.id === accountId);
    
    if (accountIndex === -1) {
      return false;
    }
    
    // Update statistics
    const platform = this.connectedAccounts[accountIndex].platform;
    this.campaignStats.activePlatforms[platform]--;
    
    // Remove account
    this.connectedAccounts.splice(accountIndex, 1);
    
    return true;
  }

  // Get all connected accounts for a user
  getConnectedAccounts(userId: number): any[] {
    return this.connectedAccounts.filter(account => account.userId === userId);
  }

  // Create a new conversation
  createConversation(
    accountId: string,
    participantId: string,
    participantUsername: string,
    initialMessage: string
  ): string {
    // Find account
    const account = this.connectedAccounts.find(acc => acc.id === accountId);
    if (!account) {
      throw new Error(`Account not found: ${accountId}`);
    }
    
    // Generate conversation ID
    const id = `conversation_${Date.now()}`;
    
    // Create conversation
    this.conversations.push({
      id,
      accountId,
      platform: account.platform,
      participantId,
      participantUsername,
      startDate: new Date().toISOString(),
      lastMessageDate: new Date().toISOString(),
      messages: [
        {
          id: `message_${Date.now()}`,
          sender: 'participant',
          content: initialMessage,
          date: new Date().toISOString()
        }
      ],
      status: 'active',
      topics: [],
      engagementLevel: 3 // Initial engagement level
    });
    
    // Update statistics
    this.campaignStats.totalMessages++;
    this.campaignStats.platformEngagement[account.platform] = (this.campaignStats.platformEngagement[account.platform] || 0) + 1;
    
    return id;
  }

  // Add a message to an existing conversation
  async addMessage(
    conversationId: string,
    content: string,
    sender: 'bot' | 'participant'
  ): Promise<string> {
    // Find conversation
    const conversationIndex = this.conversations.findIndex(convo => convo.id === conversationId);
    
    if (conversationIndex === -1) {
      throw new Error(`Conversation not found: ${conversationId}`);
    }
    
    // Generate message ID
    const id = `message_${Date.now()}`;
    
    // Content analysis (for participant messages)
    let contentAnalysis;
    if (sender === 'participant') {
      contentAnalysis = await this.analyzeMessage(content);
      
      // Update conversation topics based on analysis
      if (contentAnalysis.topic && !this.conversations[conversationIndex].topics.includes(contentAnalysis.topic)) {
        this.conversations[conversationIndex].topics.push(contentAnalysis.topic);
      }
      
      // Update statistics based on sentiment
      if (contentAnalysis.sentiment === 'positive') {
        this.campaignStats.positiveInteractions++;
      } else if (contentAnalysis.sentiment === 'negative') {
        this.campaignStats.negativeInteractions++;
      } else {
        this.campaignStats.neutralInteractions++;
      }
      
      // Update more statistics
      if (contentAnalysis.isQuestion) {
        this.campaignStats.questionsAnswered++;
      }
      
      if (contentAnalysis.containsMisconception) {
        this.campaignStats.misconceptionsCorrected++;
      }
      
      // Update top topics
      if (contentAnalysis.topic) {
        this.campaignStats.topTopics[contentAnalysis.topic] = (this.campaignStats.topTopics[contentAnalysis.topic] || 0) + 1;
      }
    }
    
    // Add message to conversation
    this.conversations[conversationIndex].messages.push({
      id,
      sender,
      content,
      date: new Date().toISOString(),
      contentAnalysis,
      responseStrategy: sender === 'bot' ? this.determineResponseStrategy(content) : undefined
    });
    
    // Update last message date
    this.conversations[conversationIndex].lastMessageDate = new Date().toISOString();
    
    // Update engagement level if participant message
    if (sender === 'participant') {
      // Simple engagement level update based on message frequency and length
      const messages = this.conversations[conversationIndex].messages;
      const participantMessages = messages.filter(m => m.sender === 'participant');
      
      // Calculate time between messages (engagement indicator)
      if (participantMessages.length > 1) {
        const prevMessageDate = new Date(participantMessages[participantMessages.length - 2].date);
        const currentMessageDate = new Date();
        const hoursBetween = (currentMessageDate.getTime() - prevMessageDate.getTime()) / (1000 * 60 * 60);
        
        // Adjust engagement level
        let newEngagementLevel = this.conversations[conversationIndex].engagementLevel;
        
        // Quick response increases engagement
        if (hoursBetween < 24) {
          newEngagementLevel += 1;
        } else if (hoursBetween > 72) {
          newEngagementLevel -= 1;
        }
        
        // Longer message indicates more engagement
        if (content.length > 100) {
          newEngagementLevel += 1;
        }
        
        // Asking questions shows engagement
        if (contentAnalysis?.isQuestion) {
          newEngagementLevel += 2;
        }
        
        // Positive sentiment increases engagement
        if (contentAnalysis?.sentiment === 'positive') {
          newEngagementLevel += 1;
        }
        
        // Cap engagement level
        this.conversations[conversationIndex].engagementLevel = Math.min(Math.max(newEngagementLevel, 0), 10);
        
        // Check if potential convert
        if (this.conversations[conversationIndex].engagementLevel >= 7) {
          this.conversations[conversationIndex].status = 'interested';
          this.campaignStats.potentialConverts++;
        }
      }
    } else {
      // Bot message
      this.campaignStats.repliesGenerated++;
    }
    
    // Update total messages
    this.campaignStats.totalMessages++;
    
    return id;
  }

  // Get a conversation by ID
  getConversation(conversationId: string): any {
    return this.conversations.find(convo => convo.id === conversationId);
  }

  // Get all conversations for an account
  getConversationsForAccount(accountId: string): any[] {
    return this.conversations.filter(convo => convo.accountId === accountId);
  }

  // Get active conversations with high engagement (potential converts)
  getPotentialConverts(): any[] {
    return this.conversations.filter(convo => 
      convo.status === 'interested' && convo.engagementLevel >= 7
    );
  }

  // Get campaign statistics
  getCampaignStats(): any {
    return this.campaignStats;
  }

  // Analyze a message for content, sentiment, and intent
  private async analyzeMessage(content: string): Promise<{
    topic?: string;
    sentiment?: 'positive' | 'neutral' | 'negative';
    isQuestion?: boolean;
    containsMisconception?: boolean;
    intentScore?: {
      learning: number;
      debating: number;
      curious: number;
      hostile: number;
    };
  }> {
    try {
      // Check if contains question
      const isQuestion = content.includes('?') || 
                        /^(what|why|how|where|when|who|is|are|does|do|can|could)/i.test(content);
      
      // Check for Islamic content
      const islamicCheck = await islamicContentDetector.detectIslamicContent(content, 'en');
      
      // Simplified topic detection
      let topic;
      
      const topicKeywords = {
        'beliefs': ['god', 'allah', 'belief', 'faith', 'iman', 'tawhid'],
        'practices': ['prayer', 'salah', 'fast', 'ramadan', 'zakat', 'hajj', 'pilgrimage'],
        'quran': ['quran', 'verse', 'surah', 'ayah', 'scripture'],
        'prophet': ['muhammad', 'prophet', 'messenger', 'sunnah', 'hadith'],
        'afterlife': ['heaven', 'paradise', 'jannah', 'hell', 'jahannam', 'judgement', 'day'],
        'science': ['science', 'scientific', 'evidence', 'proof', 'miracle'],
        'misconceptions': ['terrorist', 'oppress', 'women', 'jihad', 'violence', 'extremist', 'radical']
      };
      
      const contentLower = content.toLowerCase();
      
      for (const [topicName, keywords] of Object.entries(topicKeywords)) {
        if (keywords.some(keyword => contentLower.includes(keyword))) {
          topic = topicName;
          break;
        }
      }
      
      // Simplified misconception detection
      const misconceptionKeywords = [
        'terrorist', 'terrorism', 'oppress', 'oppression', 'women oppression',
        'force', 'forced', 'violent', 'violence', 'sword', 'kill', 'suicide',
        'extremist', 'radical', 'backward', 'medieval', 'outdated'
      ];
      
      const containsMisconception = misconceptionKeywords.some(keyword => contentLower.includes(keyword));
      
      // Simplified sentiment analysis
      let sentiment: 'positive' | 'neutral' | 'negative' = 'neutral';
      
      const positiveWords = [
        'good', 'great', 'excellent', 'amazing', 'wonderful', 'beautiful', 
        'peace', 'love', 'respect', 'thank', 'thanks', 'appreciate', 'interested',
        'helpful', 'enlightening', 'fascinating', 'inspiring'
      ];
      
      const negativeWords = [
        'bad', 'terrible', 'awful', 'wrong', 'evil', 'hate', 'dislike', 'stupid',
        'silly', 'ridiculous', 'absurd', 'nonsense', 'false', 'lie', 'incorrect',
        'angry', 'upset', 'offended', 'offensive'
      ];
      
      const positiveCount = positiveWords.filter(word => contentLower.includes(word)).length;
      const negativeCount = negativeWords.filter(word => contentLower.includes(word)).length;
      
      if (positiveCount > negativeCount) {
        sentiment = 'positive';
      } else if (negativeCount > positiveCount) {
        sentiment = 'negative';
      }
      
      // Simple intent scoring
      const intentScore = {
        learning: 0,
        debating: 0,
        curious: 0,
        hostile: 0
      };
      
      // Learning intent indicators
      const learningWords = ['learn', 'understand', 'explain', 'clarify', 'help me', 'guidance'];
      learningWords.forEach(word => {
        if (contentLower.includes(word)) intentScore.learning += 1;
      });
      
      // Debating intent indicators
      const debatingWords = ['argue', 'debate', 'disagree', 'prove', 'evidence', 'wrong'];
      debatingWords.forEach(word => {
        if (contentLower.includes(word)) intentScore.debating += 1;
      });
      
      // Curious intent indicators
      const curiousWords = ['curious', 'interest', 'wonder', 'question', 'how come', 'why do'];
      curiousWords.forEach(word => {
        if (contentLower.includes(word)) intentScore.curious += 1;
      });
      
      // Hostile intent indicators
      const hostileWords = ['stupid', 'ridiculous', 'pathetic', 'ignorant', 'backward', 'brainwashed'];
      hostileWords.forEach(word => {
        if (contentLower.includes(word)) intentScore.hostile += 1;
      });
      
      // Boost question-related intent
      if (isQuestion) {
        intentScore.curious += 2;
        intentScore.learning += 1;
      }
      
      return {
        topic,
        sentiment,
        isQuestion,
        containsMisconception,
        intentScore
      };
    } catch (error) {
      console.error("Error analyzing message:", error);
      return {
        isQuestion: content.includes('?')
      };
    }
  }

  // Determine the response strategy for a bot message
  private determineResponseStrategy(content: string): string {
    const contentLower = content.toLowerCase();
    
    if (contentLower.includes('misconception') || contentLower.includes('clarify')) {
      return 'correct_misconception';
    }
    
    if (contentLower.includes('quran') || contentLower.includes('verse')) {
      return 'share_scripture';
    }
    
    if (contentLower.includes('learn more') || contentLower.includes('resource')) {
      return 'share_resource';
    }
    
    if (contentLower.match(/\?$/) || contentLower.includes('question for you')) {
      return 'ask_question';
    }
    
    if (contentLower.includes('thank') || contentLower.includes('appreciate')) {
      return 'express_gratitude';
    }
    
    return 'general_engagement';
  }

  // Generate a reply to a message using AI
  async generateReply(
    conversationId: string,
    options: {
      tone?: 'friendly' | 'scholarly' | 'conversational';
      includeInvitation?: boolean;
      includeScripture?: boolean;
    } = {}
  ): Promise<string> {
    try {
      // Default options
      const defaultOptions = {
        tone: 'conversational' as const,
        includeInvitation: true,
        includeScripture: true
      };
      
      // Merge with provided options
      const settings = { ...defaultOptions, ...options };
      
      // Get conversation
      const conversation = this.conversations.find(convo => convo.id === conversationId);
      if (!conversation) {
        throw new Error(`Conversation not found: ${conversationId}`);
      }
      
      // Get platform
      const account = this.connectedAccounts.find(acc => acc.id === conversation.accountId);
      if (!account) {
        throw new Error(`Account not found: ${conversation.accountId}`);
      }
      
      const platform = account.platform;
      
      // Get messages
      const messages = conversation.messages;
      if (messages.length === 0) {
        throw new Error(`No messages in conversation: ${conversationId}`);
      }
      
      // Get last message (should be from participant)
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.sender !== 'participant') {
        throw new Error(`Last message in conversation ${conversationId} is not from participant`);
      }
      
      // Get conversation history (up to 5 previous messages)
      const recentMessages = messages.slice(-Math.min(6, messages.length));
      
      // Format conversation history
      const conversationHistory = recentMessages.map(msg => 
        `${msg.sender === 'participant' ? 'Person' : 'You'}: ${msg.content}`
      ).join('\n\n');
      
      // Get content analysis of last message
      const contentAnalysis = lastMessage.contentAnalysis;
      
      // Get appropriate social media response using islamicDawahService
      const response = await islamicDawahService.generateSocialMediaResponse(
        lastMessage.content,
        platform as any,
        {
          tone: settings.tone,
          length: platform === 'twitter' ? 'brief' : 'detailed',
          includeInvitation: settings.includeInvitation,
          language: 'en' // Default to English, could be customized
        }
      );
      
      // Add the reply to the conversation
      const messageId = await this.addMessage(conversationId, response.response, 'bot');
      
      return response.response;
    } catch (error) {
      console.error("Error generating reply:", error);
      
      // Return a simple response in case of error
      return "Thank you for your message. I appreciate the conversation. If you'd like to learn more about Islam, please feel free to ask any questions.";
    }
  }

  // Generate pre-approved content for posting
  async generateDawahContent(
    type: 'quran_reflection' | 'islamic_fact' | 'prophet_teaching',
    platform: string,
    options: {
      topic?: string;
      language?: string;
      includeHashtags?: boolean;
    } = {}
  ): Promise<{
    content: string;
    imageDescription?: string;
    hashtags?: string[];
  }> {
    try {
      // Default options
      const defaultOptions = {
        topic: 'general',
        language: 'en',
        includeHashtags: true
      };
      
      // Merge with provided options
      const settings = { ...defaultOptions, ...options };
      
      // Find content template
      const contentTemplate = this.approvedContent.find(content => content.id === type);
      if (!contentTemplate) {
        throw new Error(`Content type not found: ${type}`);
      }
      
      // Check if platform is supported
      if (!contentTemplate.platforms.includes(platform)) {
        throw new Error(`Platform ${platform} not supported for content type ${type}`);
      }
      
      // Generate content based on type
      let content = '';
      let imageDescription;
      let hashtags: string[] = [];
      
      if (settings.includeHashtags) {
        // Add general hashtags
        hashtags = [...this.hashtagSets.general];
        
        // Add topic-specific hashtags
        if (settings.topic === 'science') {
          hashtags = [...hashtags, ...this.hashtagSets.science];
        } else if (settings.topic === 'history') {
          hashtags = [...hashtags, ...this.hashtagSets.history];
        } else if (settings.topic === 'spirituality') {
          hashtags = [...hashtags, ...this.hashtagSets.spirituality];
        } else if (settings.topic === 'dawah') {
          hashtags = [...hashtags, ...this.hashtagSets.dawah];
        }
        
        // Limit hashtags based on platform
        if (platform === 'twitter') {
          hashtags = hashtags.slice(0, 3); // Fewer hashtags for Twitter
        } else if (platform === 'instagram') {
          hashtags = hashtags.slice(0, 10); // More hashtags for Instagram
        } else {
          hashtags = hashtags.slice(0, 5); // Moderate for other platforms
        }
      }
      
      // Generate content using OpenAI or Anthropic
      // In this implementation, we'll simulate content generation
      
      switch (type) {
        case 'quran_reflection':
          // In a real implementation, this would use a database of Quran verses
          const quranVerses = [
            {
              verse: "And We have certainly made the Qur'an easy for remembrance, so is there any who will remember?",
              reference: "Quran 54:17",
              reflection: "This verse reminds us that the Quran is accessible to all who sincerely seek its guidance."
            },
            {
              verse: "Indeed, Allah orders justice and good conduct and giving to relatives and forbids immorality and bad conduct and oppression.",
              reference: "Quran 16:90",
              reflection: "Islam emphasizes ethical conduct and social responsibility as core tenets of faith."
            },
            {
              verse: "And it is He who created the night and the day and the sun and the moon; all [heavenly bodies] in an orbit are swimming.",
              reference: "Quran 21:33",
              reflection: "The Quran described celestial motion with remarkable accuracy, showing its divine origin."
            }
          ];
          
          const selectedVerse = quranVerses[Math.floor(Math.random() * quranVerses.length)];
          
          content = contentTemplate.content
            .replace('{verse}', selectedVerse.verse)
            .replace('{reference}', selectedVerse.reference)
            .replace('{reflection}', selectedVerse.reflection);
          
          imageDescription = `Beautiful calligraphy of the verse "${selectedVerse.reference}"`;
          break;
          
        case 'islamic_fact':
          // In a real implementation, this would use a database of Islamic facts
          const islamicFacts = [
            "The world's oldest continuously functioning university, University of Al Qarawiyyin in Fez, Morocco, was founded by a Muslim woman, Fatima al-Fihri, in 859 CE.",
            "Muslim scholars made crucial advancements in algebra, with the word 'algebra' itself coming from the Arabic word 'al-jabr' from the title of a book by the mathematician al-Khwarizmi.",
            "The concept of hospitals as we know them today originated in the Islamic world, with the first hospitals established in Baghdad in the 9th century.",
            "The Islamic Golden Age saw Muslim scientists develop the scientific method centuries before the European Renaissance."
          ];
          
          const selectedFact = islamicFacts[Math.floor(Math.random() * islamicFacts.length)];
          
          content = contentTemplate.content
            .replace('{fact}', selectedFact);
          
          imageDescription = `Informative graphic about Islamic contributions to ${selectedFact.includes('hospital') ? 'medicine' : selectedFact.includes('algebra') ? 'mathematics' : 'civilization'}`;
          break;
          
        case 'prophet_teaching':
          // In a real implementation, this would use a database of authenticated hadith
          const prophetTeachings = [
            {
              hadith: "The strong person is not the one who can wrestle someone else down. The strong person is the one who can control himself when he is angry.",
              reference: "Sahih al-Bukhari",
              lesson: "emotional intelligence and self-control"
            },
            {
              hadith: "He who is not merciful to others, will not be treated mercifully.",
              reference: "Sahih al-Bukhari",
              lesson: "compassion and empathy towards all creation"
            },
            {
              hadith: "Whoever believes in Allah and the Last Day should say something good or keep silent.",
              reference: "Sahih al-Bukhari and Muslim",
              lesson: "mindful speech and conscious communication"
            }
          ];
          
          const selectedTeaching = prophetTeachings[Math.floor(Math.random() * prophetTeachings.length)];
          
          content = contentTemplate.content
            .replace('{hadith}', selectedTeaching.hadith)
            .replace('{reference}', selectedTeaching.reference)
            .replace('{lesson}', selectedTeaching.lesson);
          
          imageDescription = `Inspirational quote design featuring the hadith about ${selectedTeaching.lesson}`;
          break;
      }
      
      // Add hashtags to content if requested
      if (settings.includeHashtags && hashtags.length > 0) {
        const hashtagString = hashtags.join(' ');
        
        // Add hashtags based on platform conventions
        if (platform === 'twitter' || platform === 'instagram') {
          content = `${content}\n\n${hashtagString}`;
        } else if (platform === 'facebook') {
          content = `${content}\n\n${hashtagString}`;
        } else {
          content = `${content}\n\n${hashtagString}`;
        }
      }
      
      // Return the content, image description, and hashtags
      return {
        content,
        imageDescription,
        hashtags
      };
    } catch (error) {
      console.error("Error generating dawah content:", error);
      
      // Return simple content in case of error
      return {
        content: "Islam teaches us the importance of kindness, compassion, and seeking knowledge. May we all strive to embody these values in our daily lives.",
        hashtags: ["#Islam", "#Faith", "#Reflection"]
      };
    }
  }

  // Monitor social media for dawah opportunities (mentions, comments, etc.)
  async monitorSocialMedia(
    accountId: string,
    options: {
      keywords?: string[];
      respondAutomatically?: boolean;
      maxResponses?: number;
    } = {}
  ): Promise<{
    newMentions: number;
    newComments: number;
    responsesSent: number;
    potentialOpportunities: {
      platform: string;
      type: string;
      content: string;
      author: string;
      link: string;
      recommendedAction: string;
    }[];
  }> {
    // Default options
    const defaultOptions = {
      keywords: ['islam', 'muslim', 'quran', 'muhammad', 'allah', 'ramadan', 'islamic'],
      respondAutomatically: false,
      maxResponses: 5
    };
    
    // Merge with provided options
    const settings = { ...defaultOptions, ...options };
    
    // Find account
    const account = this.connectedAccounts.find(acc => acc.id === accountId);
    if (!account) {
      throw new Error(`Account not found: ${accountId}`);
    }
    
    // In a real implementation, this would connect to social media APIs
    // For simulation, we'll return mock data
    
    // Simulate found mentions, comments, etc.
    const simulatedOpportunities = [
      {
        platform: account.platform,
        type: 'mention',
        content: 'Can someone explain what Muslims believe about Jesus? @' + account.username,
        author: 'curious_seeker',
        link: 'https://' + account.platform + '.com/status/12345',
        recommendedAction: 'respond_with_information'
      },
      {
        platform: account.platform,
        type: 'comment',
        content: 'I heard Islam forces women to cover up and oppresses them. Is that true?',
        author: 'question_asker',
        link: 'https://' + account.platform + '.com/status/67890',
        recommendedAction: 'correct_misconception'
      },
      {
        platform: account.platform,
        type: 'direct_message',
        content: 'Hi, I\'ve been reading about Islam and I have some questions. Can you help?',
        author: 'potential_convert',
        link: 'https://' + account.platform + '.com/messages',
        recommendedAction: 'engage_immediately'
      }
    ];
    
    // Filter to only include opportunities with specified keywords
    const filteredOpportunities = simulatedOpportunities.filter(opp => 
      settings.keywords.some(keyword => opp.content.toLowerCase().includes(keyword.toLowerCase()))
    );
    
    // Automatic responses if enabled
    let responsesSent = 0;
    
    if (settings.respondAutomatically && filteredOpportunities.length > 0) {
      // In a real implementation, this would send actual responses via social media APIs
      
      // Limit responses to maxResponses
      const opportunitiesToRespond = filteredOpportunities.slice(0, settings.maxResponses);
      
      for (const opportunity of opportunitiesToRespond) {
        try {
          // Generate appropriate response using islamicDawahService
          const response = await islamicDawahService.generateSocialMediaResponse(
            opportunity.content,
            account.platform as any,
            {
              tone: 'friendly',
              length: account.platform === 'twitter' ? 'brief' : 'detailed',
              includeInvitation: true,
              language: 'en' // Default to English
            }
          );
          
          // In a real implementation, this would send the response via social media API
          
          // Create new conversation for tracking
          const conversationId = this.createConversation(
            accountId,
            opportunity.author,
            opportunity.author,
            opportunity.content
          );
          
          // Add response to conversation
          await this.addMessage(conversationId, response.response, 'bot');
          
          responsesSent++;
        } catch (error) {
          console.error(`Error responding to opportunity from ${opportunity.author}:`, error);
        }
      }
    }
    
    // Return metrics and potential opportunities
    return {
      newMentions: filteredOpportunities.filter(o => o.type === 'mention').length,
      newComments: filteredOpportunities.filter(o => o.type === 'comment').length,
      responsesSent,
      potentialOpportunities: filteredOpportunities
    };
  }

  // Schedule social media posts
  schedulePost(
    accountId: string,
    content: string,
    scheduleDate: string,
    options: {
      mediaUrl?: string;
      mediaType?: 'image' | 'video';
      campaignId?: string;
    } = {}
  ): string {
    // Find account
    const account = this.connectedAccounts.find(acc => acc.id === accountId);
    if (!account) {
      throw new Error(`Account not found: ${accountId}`);
    }
    
    // Generate post ID
    const id = `post_${Date.now()}`;
    
    // In a real implementation, this would schedule the post via social media API
    
    // Return post ID
    return id;
  }

  // Generate engagement report
  generateEngagementReport(userId: number): {
    totalConversations: number;
    activeConversations: number;
    potentialConverts: number;
    averageEngagementLevel: number;
    topPerformingContent: any[];
    platformPerformance: {[key: string]: {
      conversations: number;
      averageEngagement: number;
    }};
    recentConversations: any[];
    recommendedActions: string[];
  } {
    // Get all accounts for user
    const userAccounts = this.connectedAccounts.filter(account => account.userId === userId);
    
    // Get all conversations for these accounts
    const conversations = [];
    for (const account of userAccounts) {
      const accountConversations = this.getConversationsForAccount(account.id);
      conversations.push(...accountConversations);
    }
    
    // Calculate metrics
    const activeConversations = conversations.filter(c => 
      c.status === 'active' || c.status === 'interested'
    );
    
    const potentialConverts = conversations.filter(c => 
      c.status === 'interested' && c.engagementLevel >= 7
    );
    
    const totalEngagement = conversations.reduce((sum, c) => sum + c.engagementLevel, 0);
    const averageEngagementLevel = conversations.length > 0 ? 
      totalEngagement / conversations.length : 0;
    
    // Calculate platform performance
    const platformPerformance: {[key: string]: {
      conversations: number;
      averageEngagement: number;
    }} = {};
    
    for (const account of userAccounts) {
      const accountConversations = this.getConversationsForAccount(account.id);
      
      if (accountConversations.length > 0) {
        const totalPlatformEngagement = accountConversations.reduce((sum, c) => sum + c.engagementLevel, 0);
        
        platformPerformance[account.platform] = {
          conversations: accountConversations.length,
          averageEngagement: totalPlatformEngagement / accountConversations.length
        };
      }
    }
    
    // Get recent conversations (last 5)
    const recentConversations = [...conversations]
      .sort((a, b) => new Date(b.lastMessageDate).getTime() - new Date(a.lastMessageDate).getTime())
      .slice(0, 5);
    
    // Generate recommended actions
    const recommendedActions = [];
    
    if (potentialConverts.length > 0) {
      recommendedActions.push(`Follow up with ${potentialConverts.length} potential converts who have shown high interest`);
    }
    
    if (activeConversations.length === 0 && userAccounts.length > 0) {
      recommendedActions.push("Create engaging content to start new conversations");
    }
    
    if (Object.keys(platformPerformance).length > 0) {
      // Find best and worst performing platforms
      let bestPlatform = '';
      let worstPlatform = '';
      let bestEngagement = 0;
      let worstEngagement = 10;
      
      for (const [platform, performance] of Object.entries(platformPerformance)) {
        if (performance.averageEngagement > bestEngagement) {
          bestEngagement = performance.averageEngagement;
          bestPlatform = platform;
        }
        
        if (performance.averageEngagement < worstEngagement) {
          worstEngagement = performance.averageEngagement;
          worstPlatform = platform;
        }
      }
      
      if (bestPlatform) {
        recommendedActions.push(`Focus more on ${bestPlatform} where you're getting the best engagement`);
      }
      
      if (worstPlatform && worstPlatform !== bestPlatform) {
        recommendedActions.push(`Improve your approach on ${worstPlatform} where engagement is lower`);
      }
    }
    
    return {
      totalConversations: conversations.length,
      activeConversations: activeConversations.length,
      potentialConverts: potentialConverts.length,
      averageEngagementLevel,
      topPerformingContent: [], // Would be populated in a real implementation
      platformPerformance,
      recentConversations: recentConversations.map(c => ({
        id: c.id,
        platform: c.platform,
        participant: c.participantUsername,
        lastMessageDate: c.lastMessageDate,
        engagementLevel: c.engagementLevel,
        status: c.status,
        messageCount: c.messages.length
      })),
      recommendedActions
    };
  }
}

export const dawahSocialManagerService = new DawahSocialManagerService();