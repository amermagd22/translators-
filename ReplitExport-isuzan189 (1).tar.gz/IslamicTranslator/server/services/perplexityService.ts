/**
 * Perplexity AI Service
 * Provides Islamic-focused question answering and knowledge search capabilities
 */

import axios from 'axios';

export class PerplexityService {
  private apiKey: string | undefined;

  constructor() {
    this.apiKey = process.env.PERPLEXITY_API_KEY;
  }

  /**
   * Checks if the Perplexity API key is available
   */
  isAvailable(): boolean {
    return !!this.apiKey;
  }

  /**
   * Answers Islamic questions with appropriate context and sources
   * @param question The Islamic question to answer
   * @param language The language code for the response
   * @returns Answer with citations and sources
   */
  async answerIslamicQuestion(question: string, language = 'en'): Promise<{
    answer: string;
    citations: string[];
  }> {
    if (!this.isAvailable()) {
      throw new Error('Perplexity API key not available');
    }

    try {
      const systemPrompt = language === 'ar' 
        ? 'أنت مساعد إسلامي متخصص. قدم إجابات دقيقة مدعومة بالمصادر الإسلامية المعتمدة مثل القرآن والسنة وكتب العلماء المعتبرين. تحدث بأدب واحترام، واستشهد بالمصادر حيثما أمكن.'
        : 'You are an Islamic specialist assistant. Provide accurate answers supported by authentic Islamic sources such as the Quran, Sunnah, and respected scholarly works. Speak with respect and dignity, and cite sources whenever possible.';

      const response = await axios.post(
        'https://api.perplexity.ai/chat/completions',
        {
          model: 'llama-3.1-sonar-small-128k-online',
          messages: [
            {
              role: 'system',
              content: systemPrompt
            },
            {
              role: 'user',
              content: question
            }
          ],
          temperature: 0.2,
          top_p: 0.9,
          max_tokens: 1000,
          search_domain_filter: ['islamic-websites.com', 'quran.com', 'sunnah.com'],
          return_related_questions: false,
          search_recency_filter: 'month',
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return {
        answer: response.data.choices[0].message.content,
        citations: response.data.citations || []
      };
    } catch (error: any) {
      console.error('Error with Perplexity API:', error);
      throw new Error(`Failed to get answer from Perplexity: ${error.message}`);
    }
  }

  /**
   * Searches for Islamic knowledge with specific focus areas
   * @param query The search query
   * @param focusArea Specific Islamic focus area (e.g. 'quran', 'hadith', 'fiqh')
   * @param language The language code for the response
   * @returns Structured search results with citations
   */
  async searchIslamicKnowledge(
    query: string, 
    focusArea: 'quran' | 'hadith' | 'fiqh' | 'general' = 'general',
    language = 'en'
  ): Promise<{
    results: string;
    citations: string[];
  }> {
    if (!this.isAvailable()) {
      throw new Error('Perplexity API key not available');
    }

    try {
      // Customize prompt based on focus area
      let focusPrompt = '';
      if (focusArea === 'quran') {
        focusPrompt = language === 'ar' 
          ? 'ركز بحثك على آيات القرآن الكريم وتفسيراتها المعتمدة. استشهد بأرقام السور والآيات.'
          : 'Focus your search on Quranic verses and their authentic interpretations. Cite surah and verse numbers.';
      } else if (focusArea === 'hadith') {
        focusPrompt = language === 'ar'
          ? 'ركز بحثك على الأحاديث النبوية الصحيحة. اذكر درجة صحة الحديث ومصدره.'
          : 'Focus your search on authentic Prophetic traditions. Mention hadith authenticity and source.';
      } else if (focusArea === 'fiqh') {
        focusPrompt = language === 'ar'
          ? 'ركز بحثك على مسائل الفقه الإسلامي. اذكر آراء المذاهب المختلفة مع الأدلة.'
          : 'Focus your search on Islamic jurisprudence. Mention different school opinions with their evidences.';
      }

      const systemPrompt = language === 'ar'
        ? `أنت باحث إسلامي متخصص يقوم بالبحث بدقة في المصادر الإسلامية الموثوقة. ${focusPrompt} قدم إجابات مدعومة بالمصادر والمراجع.`
        : `You are a specialized Islamic researcher conducting precise searches in trusted Islamic sources. ${focusPrompt} Provide answers supported by sources and references.`;

      const response = await axios.post(
        'https://api.perplexity.ai/chat/completions',
        {
          model: 'llama-3.1-sonar-small-128k-online',
          messages: [
            {
              role: 'system',
              content: systemPrompt
            },
            {
              role: 'user',
              content: query
            }
          ],
          temperature: 0.1,
          top_p: 0.9,
          max_tokens: 1500,
          search_domain_filter: ['islamic-websites.com', 'quran.com', 'sunnah.com'],
          return_related_questions: false,
          search_recency_filter: 'month',
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return {
        results: response.data.choices[0].message.content,
        citations: response.data.citations || []
      };
    } catch (error: any) {
      console.error('Error with Perplexity API:', error);
      throw new Error(`Failed to search Islamic knowledge with Perplexity: ${error.message}`);
    }
  }

  /**
   * Validates Islamic content for authenticity and correctness
   * @param content The content to validate
   * @param language The language code
   * @returns Validation result with corrections and sources
   */
  async validateIslamicContent(
    content: string,
    language = 'en'
  ): Promise<{
    isAuthentic: boolean;
    corrections: string;
    authenticityScore: number;
    sources: string[];
  }> {
    if (!this.isAvailable()) {
      throw new Error('Perplexity API key not available');
    }

    try {
      const systemPrompt = language === 'ar'
        ? 'أنت مدقق محتوى إسلامي. مهمتك هي التحقق من صحة المعلومات الإسلامية والتأكد من موافقتها للقرآن والسنة الصحيحة وإجماع العلماء المعتبرين. قم بتحديد أي أخطاء أو انحرافات وتصحيحها مع ذكر المصادر. قدم النتائج في تنسيق JSON يحتوي على: isAuthentic (boolean)، corrections (string)، authenticityScore (number من 0 إلى 100)، sources (مصفوفة من المصادر).'
        : 'You are an Islamic content validator. Your task is to verify the authenticity of Islamic information and ensure it aligns with the Quran, authentic Sunnah, and consensus of respected scholars. Identify any errors or deviations and correct them with sources. Provide results in JSON format containing: isAuthentic (boolean), corrections (string), authenticityScore (number from 0 to 100), sources (array of sources).';

      const response = await axios.post(
        'https://api.perplexity.ai/chat/completions',
        {
          model: 'llama-3.1-sonar-small-128k-online',
          messages: [
            {
              role: 'system',
              content: systemPrompt
            },
            {
              role: 'user',
              content: content
            }
          ],
          temperature: 0.1,
          top_p: 0.9,
          max_tokens: 1500,
          response_format: { type: "json_object" },
          search_domain_filter: ['islamic-websites.com', 'quran.com', 'sunnah.com'],
          return_related_questions: false,
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      // Parse the JSON response
      const validationResult = JSON.parse(response.data.choices[0].message.content);
      
      return {
        isAuthentic: validationResult.isAuthentic || false,
        corrections: validationResult.corrections || '',
        authenticityScore: validationResult.authenticityScore || 0,
        sources: validationResult.sources || []
      };
    } catch (error: any) {
      console.error('Error with Perplexity API:', error);
      throw new Error(`Failed to validate Islamic content with Perplexity: ${error.message}`);
    }
  }
}

export const perplexityService = new PerplexityService();