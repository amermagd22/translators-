import { anthropicService } from './anthropic';
import { openaiService } from './openai';
import { filterService } from './filter';
import { islamicContentDetector } from './islamicContentDetector';
import { islamicDawahService } from './islamicDawah';
import { quranTranslatorService } from './quranTranslator';
import { scientificMiraclesService } from './scientificMiracles';

/**
 * AI-powered Islamic Dawah Assistant Service
 * Provides intelligent Islamic conversation capabilities, answers to faith questions,
 * and guided dialogue for dawah (Islamic outreach)
 */
export class AIDawahAssistantService {
  private dawahConversations: Record<string, {
    userId: string;
    conversationId: string;
    history: Array<{
      role: 'system' | 'user' | 'assistant';
      content: string;
      timestamp: number;
    }>;
    language: string;
    faithTopic?: string;
    userBackground?: {
      religion?: string;
      interests?: string[];
      objections?: string[];
      knowledgeLevel?: 'beginner' | 'intermediate' | 'advanced';
    };
  }> = {};
  
  /**
   * Initialize a new dawah conversation
   */
  createConversation(userId: string, language: string = 'en', initialContext?: {
    faithTopic?: string;
    userBackground?: {
      religion?: string;
      interests?: string[];
      objections?: string[];
      knowledgeLevel?: 'beginner' | 'intermediate' | 'advanced';
    }
  }): string {
    // Generate unique conversation ID
    const conversationId = `dawah_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    
    // Set up system message based on context
    let systemMessage = `You are a knowledgeable Islamic dawah assistant providing accurate, respectful information about Islam. 
Your goal is to invite people to understand Islam by addressing their questions and concerns with wisdom and beautiful preaching.

Guidelines:
1. Always base your answers on authentic Islamic sources (Quran and Sunnah)
2. Represent mainstream Islamic views without sectarian bias
3. Be respectful and kind, following the Quranic advice: "Invite to the way of your Lord with wisdom and good instruction" (16:125)
4. When mentioning Prophet Muhammad, follow his name with the respectful phrase "peace be upon him" (or ﷺ)
5. Provide evidence from the Quran and authentic hadith when appropriate
6. Avoid speculation on matters not clearly addressed in Islamic sources
7. Aim to clear misconceptions with patience and evidence
8. Don't use pressure or coercion - respect the Quranic principle "There is no compulsion in religion" (2:256)`;

    // Add specific guidance based on faith topic if provided
    if (initialContext?.faithTopic) {
      systemMessage += `\n\nThis conversation will focus particularly on the topic of ${initialContext.faithTopic}. 
Provide especially thorough and clear information on this subject.`;
    }
    
    // Add guidance based on user background if provided
    if (initialContext?.userBackground) {
      systemMessage += '\n\nUser background context:';
      
      if (initialContext.userBackground.religion) {
        systemMessage += `\n- User has a background in ${initialContext.userBackground.religion}`;
      }
      
      if (initialContext.userBackground.knowledgeLevel) {
        systemMessage += `\n- User has a ${initialContext.userBackground.knowledgeLevel} level of knowledge about Islam`;
      }
      
      if (initialContext.userBackground.interests && initialContext.userBackground.interests.length > 0) {
        systemMessage += `\n- User has expressed interest in: ${initialContext.userBackground.interests.join(', ')}`;
      }
      
      if (initialContext.userBackground.objections && initialContext.userBackground.objections.length > 0) {
        systemMessage += `\n- User has expressed concerns about: ${initialContext.userBackground.objections.join(', ')}`;
      }
    }
    
    // Initialize the conversation
    this.dawahConversations[conversationId] = {
      userId,
      conversationId,
      history: [{
        role: 'system',
        content: systemMessage,
        timestamp: Date.now()
      }],
      language,
      faithTopic: initialContext?.faithTopic,
      userBackground: initialContext?.userBackground
    };
    
    return conversationId;
  }
  
  /**
   * Process a message in a dawah conversation
   */
  async processMessage(
    conversationId: string,
    userMessage: string
  ): Promise<{
    response: string;
    suggestedFollowups?: string[];
    scriptural_references?: Array<{
      text: string;
      reference: string;
      translation?: string;
    }>;
    detected_topics?: string[];
  }> {
    try {
      // Check if conversation exists
      if (!this.dawahConversations[conversationId]) {
        throw new Error(`Conversation with ID ${conversationId} not found`);
      }
      
      const conversation = this.dawahConversations[conversationId];
      
      // Check if message is appropriate
      const hasProhibited = await filterService.containsProhibitedContent(userMessage, 'auto');
      if (hasProhibited) {
        return {
          response: "I apologize, but I cannot respond to messages containing inappropriate content. Please ensure your question adheres to Islamic ethical guidelines.",
          detected_topics: ['prohibited_content']
        };
      }
      
      // Detect Islamic content in the message
      const islamicCheck = await islamicContentDetector.detectIslamicContent(userMessage);
      
      // Add message to history
      conversation.history.push({
        role: 'user',
        content: userMessage,
        timestamp: Date.now()
      });
      
      // If the user is asking about Quranic verses, use specialized service
      if (userMessage.toLowerCase().includes('quran') || 
          userMessage.toLowerCase().includes('verse') || 
          userMessage.toLowerCase().includes('surah') ||
          userMessage.toLowerCase().includes('ayah')) {
          
        const quranCheck = await quranTranslatorService.detectQuranicContent(userMessage, conversation.language);
        
        if (quranCheck.containsQuranicReference) {
          const response = await this.handleQuranicQuestion(userMessage, conversation.language);
          
          conversation.history.push({
            role: 'assistant',
            content: response.response,
            timestamp: Date.now()
          });
          
          return response;
        }
      }
      
      // If the user is asking about scientific miracles, use specialized service
      if (userMessage.toLowerCase().includes('scientific') || 
          userMessage.toLowerCase().includes('science') || 
          userMessage.toLowerCase().includes('miracle') ||
          userMessage.toLowerCase().includes('evidence')) {
          
        const response = await this.handleScientificQuestion(userMessage, conversation.language);
        
        conversation.history.push({
          role: 'assistant',
          content: response.response,
          timestamp: Date.now()
        });
        
        return response;
      }
      
      // For other Islamic questions, use the IslamicDawahService
      if (islamicCheck.isIslamic || 
          userMessage.toLowerCase().includes('islam') || 
          userMessage.toLowerCase().includes('muslim') ||
          userMessage.toLowerCase().includes('allah') ||
          userMessage.toLowerCase().includes('god') ||
          userMessage.toLowerCase().includes('prayer') ||
          userMessage.toLowerCase().includes('prophet') ||
          userMessage.toLowerCase().includes('worship')) {
          
        const faithResponse = await islamicDawahService.generateFaithResponse(
          userMessage,
          {
            language: conversation.language,
            detailLevel: 'detailed',
            includeScriptural: true,
            includeScholarly: true,
            audienceType: conversation.userBackground?.knowledgeLevel === 'advanced' ? 'academic' : 
                          conversation.userBackground?.knowledgeLevel === 'beginner' ? 'seekers' : 'general'
          }
        );
        
        conversation.history.push({
          role: 'assistant',
          content: faithResponse.answer,
          timestamp: Date.now()
        });
        
        const suggestedFollowups = await this.generateFollowupQuestions(
          userMessage, 
          faithResponse.answer,
          faithResponse.related_topics || []
        );
        
        return {
          response: faithResponse.answer,
          suggestedFollowups,
          scriptural_references: faithResponse.scriptural_evidence,
          detected_topics: faithResponse.related_topics
        };
      }
      
      // For non-Islamic questions, redirect gently to Islamic topics
      const response = await this.generateGenericResponse(userMessage, conversation);
      
      conversation.history.push({
        role: 'assistant',
        content: response.response,
        timestamp: Date.now()
      });
      
      return response;
    } catch (error) {
      console.error('Error processing dawah message:', error);
      return {
        response: "I apologize, but I encountered an issue processing your message. Please try asking your question again, perhaps phrasing it differently.",
      };
    }
  }
  
  /**
   * Get conversation history
   */
  getConversationHistory(conversationId: string): {
    conversation?: {
      history: Array<{
        role: 'system' | 'user' | 'assistant';
        content: string;
        timestamp: number;
      }>;
      language: string;
      faithTopic?: string;
    };
    error?: string;
  } {
    if (!this.dawahConversations[conversationId]) {
      return {
        error: `Conversation with ID ${conversationId} not found`
      };
    }
    
    const conversation = this.dawahConversations[conversationId];
    
    return {
      conversation: {
        history: conversation.history.filter(msg => msg.role !== 'system'), // Exclude system messages
        language: conversation.language,
        faithTopic: conversation.faithTopic
      }
    };
  }
  
  /**
   * Get all conversations for a user
   */
  getUserConversations(userId: string): {
    conversations: Array<{
      conversationId: string;
      lastMessageTime: number;
      messageCount: number;
      faithTopic?: string;
    }>;
  } {
    const userConversations = Object.values(this.dawahConversations)
      .filter(conv => conv.userId === userId)
      .map(conv => ({
        conversationId: conv.conversationId,
        lastMessageTime: conv.history[conv.history.length - 1]?.timestamp || 0,
        messageCount: conv.history.filter(msg => msg.role !== 'system').length,
        faithTopic: conv.faithTopic
      }))
      .sort((a, b) => b.lastMessageTime - a.lastMessageTime); // Sort by most recent
    
    return {
      conversations: userConversations
    };
  }
  
  /**
   * Handle questions about Quranic verses
   */
  private async handleQuranicQuestion(
    question: string,
    language: string
  ): Promise<{
    response: string;
    suggestedFollowups?: string[];
    scriptural_references?: Array<{
      text: string;
      reference: string;
      translation?: string;
    }>;
    detected_topics?: string[];
  }> {
    try {
      // Detect Quranic content in the question
      const quranCheck = await quranTranslatorService.detectQuranicContent(question, language);
      
      // If specific verses are mentioned
      if (quranCheck.containsQuranicReference && quranCheck.verses && quranCheck.verses.length > 0) {
        const verses = quranCheck.verses;
        
        // Formulate a response about these specific verses
        const verseReferences = verses.map(v => v.reference).join(', ');
        
        // Translate the verses if needed
        const translatedVerses = await quranTranslatorService.translateQuranicText(
          verses.map(v => v.text).join('\n'),
          'ar',
          language,
          {
            preserveArabicTerms: true,
            includeExplanation: true
          }
        );
        
        // Check if asking for interpretation
        const isAskingForInterpretation = question.toLowerCase().includes('mean') || 
                                         question.toLowerCase().includes('interpretati') ||
                                         question.toLowerCase().includes('explain') ||
                                         question.toLowerCase().includes('understand');
        
        let response;
        if (isAskingForInterpretation) {
          response = `The verse(s) you mentioned (${verseReferences}) are profound in their meaning. Here is the translation and explanation:\n\n${translatedVerses.translatedText}\n\n${translatedVerses.explanation || ''}`;
        } else {
          response = `Here are the verse(s) you mentioned (${verseReferences}):\n\n${translatedVerses.translatedText}`;
        }
        
        // Create scriptural references
        const scriptural_references = verses.map(verse => ({
          text: verse.text,
          reference: verse.reference,
          translation: language === 'ar' ? undefined : translatedVerses.translatedText
        }));
        
        // Generate follow-up questions
        const suggestedFollowups = [
          `What is the context in which ${verseReferences} was revealed?`,
          `How do scholars interpret ${verseReferences}?`,
          `Are there other verses related to this topic?`,
          `How can I apply the lessons from ${verseReferences} in my daily life?`
        ];
        
        return {
          response,
          suggestedFollowups,
          scriptural_references,
          detected_topics: ['quran', 'tafsir', 'quranic_verses']
        };
      } 
      
      // If asking about the Quran generally
      const generalQuranResponse = await islamicDawahService.generateFaithResponse(
        question,
        {
          language,
          detailLevel: 'detailed',
          includeScriptural: true,
          includeScholarly: true,
          audienceType: 'general'
        }
      );
      
      const suggestedFollowups = await this.generateFollowupQuestions(
        question, 
        generalQuranResponse.answer,
        ['quran', 'revelation', 'tafsir']
      );
      
      return {
        response: generalQuranResponse.answer,
        suggestedFollowups,
        scriptural_references: generalQuranResponse.scriptural_evidence,
        detected_topics: ['quran', 'revelation', ...generalQuranResponse.related_topics || []]
      };
    } catch (error) {
      console.error('Error handling Quranic question:', error);
      return {
        response: "I apologize, but I encountered an issue understanding your question about the Quran. Please try asking it in a different way, perhaps specifying the verse or topic more clearly.",
        detected_topics: ['quran']
      };
    }
  }
  
  /**
   * Handle questions about scientific miracles and evidence
   */
  private async handleScientificQuestion(
    question: string,
    language: string
  ): Promise<{
    response: string;
    suggestedFollowups?: string[];
    scriptural_references?: Array<{
      text: string;
      reference: string;
      translation?: string;
    }>;
    detected_topics?: string[];
  }> {
    try {
      // Extract likely scientific topic
      let topic = 'scientific miracles in islam';
      
      // Try to extract more specific topic
      const scienceKeywords = [
        'embryo', 'universe', 'astronomy', 'geology', 'mountains', 
        'sea', 'ocean', 'physics', 'iron', 'medicine', 'brain'
      ];
      
      for (const keyword of scienceKeywords) {
        if (question.toLowerCase().includes(keyword)) {
          topic = `${keyword} in quran`;
          break;
        }
      }
      
      // Get scientific miracle explanation
      const miracleExplanation = await scientificMiraclesService.generateMiracleExplanation(
        topic,
        {
          depth: 'detailed',
          audience: 'general',
          language,
          includeReferences: true,
          includeVerses: true
        }
      );
      
      // Create scriptural references
      const scriptural_references = miracleExplanation.verses?.map(verse => ({
        text: verse.arabic,
        reference: verse.reference,
        translation: verse.translation
      }));
      
      // Generate follow-up questions
      const suggestedFollowups = [
        `Are there other scientific miracles related to ${topic.split(' ')[0]}?`,
        `When were these scientific facts discovered by modern science?`,
        `How do scientists view these Quranic descriptions?`,
        `Are there any scholars who specialize in explaining these scientific descriptions?`
      ];
      
      return {
        response: miracleExplanation.explanation,
        suggestedFollowups,
        scriptural_references,
        detected_topics: ['scientific_miracles', 'quran', 'science_and_islam']
      };
    } catch (error) {
      console.error('Error handling scientific question:', error);
      return {
        response: "The Quran contains many descriptions of natural phenomena that align with modern scientific discoveries, despite being revealed over 1400 years ago. These include accurate descriptions of embryonic development, the expanding universe, the protective atmosphere, the water cycle, and many others. These scientific accuracies are considered by many as evidence of the divine origin of the Quran, as such knowledge wasn't available at the time of revelation.",
        detected_topics: ['scientific_miracles', 'quran']
      };
    }
  }
  
  /**
   * Generate a response for non-Islamic questions, gently redirecting to Islamic topics
   */
  private async generateGenericResponse(
    question: string,
    conversation: {
      history: Array<{
        role: 'system' | 'user' | 'assistant';
        content: string;
        timestamp: number;
      }>;
      language: string;
    }
  ): Promise<{
    response: string;
    suggestedFollowups?: string[];
    detected_topics?: string[];
  }> {
    try {
      // Prepare conversation history for AI context
      const recentMessages = conversation.history
        .filter(msg => msg.role !== 'system')
        .slice(-4) // Take last 4 messages for context
        .map(msg => ({
          role: msg.role as 'user' | 'assistant', 
          content: msg.content
        }));
      
      // Create redirect prompt
      const redirectPrompt = `The user asked: "${question}"

This appears to be a question not directly related to Islam. I need to respectfully acknowledge their question while gently redirecting the conversation toward Islamic topics. 

Please generate a respectful response that:
1. Briefly acknowledges their question
2. Explains that I'm specifically designed to discuss Islamic topics
3. Offers to discuss related Islamic perspectives or topics instead
4. Suggests 2-3 Islamic topics that might interest them based on the nature of their question

The response should be conversational, friendly, and respectful - never dismissive of their original question.`;

      // Use appropriate AI service
      let response: string;
      
      if (anthropicService.isAvailable()) {
        const anthropicResponse = await anthropicService.analyzeMultilingualContent(
          redirectPrompt,
          conversation.language || 'en',
          undefined,
          recentMessages
        );
        response = anthropicResponse;
      } else {
        const openaiResponse = await openaiService.enhanceTranslation(
          redirectPrompt,
          'en',
          conversation.language || 'en',
          true,
          undefined,
          recentMessages
        );
        response = openaiResponse;
      }
      
      // Generate suggested Islamic topics for follow-up
      const suggestedFollowups = [
        "What are the core beliefs of Islam?",
        "How does Islam view [topic related to original question]?",
        "What does the Quran say about [subject related to original question]?"
      ];
      
      return {
        response,
        suggestedFollowups,
        detected_topics: ['non_islamic_query', 'redirection']
      };
    } catch (error) {
      console.error('Error generating generic response:', error);
      return {
        response: "I appreciate your question, though it seems to be outside my focus area. I'm specifically designed to discuss Islamic topics and answer questions about Islam. I'd be happy to discuss any aspects of Islamic faith, practices, history, or teachings if you're interested.",
        detected_topics: ['non_islamic_query']
      };
    }
  }
  
  /**
   * Generate follow-up questions based on the conversation
   */
  private async generateFollowupQuestions(
    userQuestion: string,
    assistantResponse: string,
    topics: string[]
  ): Promise<string[]> {
    try {
      // Create a unique set of topics
      const uniqueTopics = new Set(topics);
      
      // Default follow-up questions based on common topics
      const defaultFollowups: Record<string, string[]> = {
        'quran': [
          "How was the Quran preserved over the centuries?",
          "What makes the Quran unique compared to other religious texts?",
          "How should I begin studying the Quran?"
        ],
        'prophethood': [
          "What are some examples of Prophet Muhammad's (ﷺ) character?",
          "How did Prophet Muhammad (ﷺ) treat people of other faiths?",
          "What are the most important teachings of Prophet Muhammad (ﷺ)?"
        ],
        'islamic_practices': [
          "What is the spiritual significance of the five daily prayers?",
          "How does fasting in Ramadan benefit the individual and community?",
          "What is the purpose of the Hajj pilgrimage?"
        ],
        'faith': [
          "How does Islam view the relationship between faith and reason?",
          "What does Islam teach about God's attributes?",
          "How does Islam guide believers through times of doubt?"
        ],
        'scientific_miracles': [
          "What other scientific facts are mentioned in the Quran?",
          "How do Islamic scholars approach scientific interpretations of the Quran?",
          "When were these scientific facts discovered by modern science?"
        ]
      };
      
      // If we have topics with default follow-ups, use them
      const selectedFollowups: string[] = [];
      
      for (const topic of uniqueTopics) {
        if (defaultFollowups[topic]) {
          // Add a random question from this topic's defaults
          const randomIndex = Math.floor(Math.random() * defaultFollowups[topic].length);
          selectedFollowups.push(defaultFollowups[topic][randomIndex]);
          
          // If we have enough, stop
          if (selectedFollowups.length >= 3) break;
        }
      }
      
      // If we don't have enough, use generic follow-ups
      if (selectedFollowups.length < 3) {
        const genericFollowups = [
          "Can you tell me more about the core beliefs in Islam?",
          "How does Islam guide daily life and decision-making?",
          "What are some common misconceptions about Islam?",
          "How has Islam contributed to science and civilization?",
          "What does Islam teach about relationships with non-Muslims?"
        ];
        
        // Add generic questions until we have 3
        while (selectedFollowups.length < 3) {
          const randomIndex = Math.floor(Math.random() * genericFollowups.length);
          const followup = genericFollowups[randomIndex];
          
          // Add if not already present
          if (!selectedFollowups.includes(followup)) {
            selectedFollowups.push(followup);
          }
          
          // Avoid infinite loop if we run out of questions
          if (selectedFollowups.length >= genericFollowups.length) break;
        }
      }
      
      return selectedFollowups;
    } catch (error) {
      console.error('Error generating follow-up questions:', error);
      return [
        "Can you tell me more about this topic from an Islamic perspective?",
        "What does the Quran say about this subject?",
        "How does this relate to the teachings of Prophet Muhammad (ﷺ)?"
      ];
    }
  }
}

export const aiDawahAssistantService = new AIDawahAssistantService();